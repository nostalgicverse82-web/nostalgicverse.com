#pragma once
#include <Arduino.h>
#include <RTClib.h>

// ============================================================================
// RTCService — thin wrapper around the DS1307. Boots gracefully (and
// honestly) if the module is missing: the rest of the system must never
// pretend a sensor is present when `isAvailable()` is false.
// ============================================================================

class RTCService {
 public:
  bool begin() {
    available_ = rtc_.begin();
    if (available_ && !rtc_.isrunning()) {
      // lost power — fall back to compile time once, then let the user
      // correct it from Settings > Clock in a future revision.
      rtc_.adjust(DateTime(F(__DATE__), F(__TIME__)));
    }
    return available_;
  }

  bool isAvailable() const { return available_; }

  DateTime now() {
    if (!available_) return DateTime((uint32_t)0);
    return rtc_.now();
  }

 private:
  RTC_DS1307 rtc_;
  bool available_ = false;
};

extern RTCService Clock;
