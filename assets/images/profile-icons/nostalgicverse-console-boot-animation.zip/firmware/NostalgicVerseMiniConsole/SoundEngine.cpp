#include "SoundEngine.h"

SoundEngine Sound;

void SoundEngine::begin(uint8_t pin) {
  pin_ = pin;
  pinMode(pin_, OUTPUT);
  clear();
}

void SoundEngine::beep(uint16_t freq, uint16_t durationMs, uint32_t delayMs) {
  if (!enabled_) return;
  for (auto &slot : queue_) {
    if (!slot.active) {
      uint32_t now = millis();
      slot.active = true;
      slot.freq = freq;
      slot.startAt = now + delayMs;
      slot.endAt = slot.startAt + durationMs;
      return;
    }
  }
  // queue full — drop the note silently rather than blocking or crashing
}

void SoundEngine::playMelody(const NVNote *notes, uint8_t count, uint32_t startDelayMs) {
  uint32_t t = startDelayMs;
  for (uint8_t i = 0; i < count; i++) {
    if (notes[i].freq > 0) beep(notes[i].freq, notes[i].durationMs, t);
    t += notes[i].durationMs + 20; // small gap between notes
  }
}

void SoundEngine::playSignature(uint32_t delayMs) {
  static const NVNote sig[] = {
      {523, 100}, // C5
      {659, 100}, // E5
      {988, 220}, // B5
  };
  playMelody(sig, 3, delayMs);
}

void SoundEngine::clear() {
  for (auto &slot : queue_) slot.active = false;
  stopTone();
}

void SoundEngine::stopTone() {
  if (toneActive_) {
    noTone(pin_);
    toneActive_ = false;
  }
}

void SoundEngine::update() {
  if (!enabled_ || pin_ == 255) return;
  uint32_t now = millis();

  // find the earliest active note that should be sounding right now
  int8_t playingIdx = -1;
  uint32_t earliestStart = UINT32_MAX;
  for (uint8_t i = 0; i < kQueueSize; i++) {
    QueuedNote &q = queue_[i];
    if (!q.active) continue;
    if (now >= q.endAt) {
      q.active = false; // expired
      continue;
    }
    if (now >= q.startAt && q.startAt < earliestStart) {
      earliestStart = q.startAt;
      playingIdx = i;
    }
  }

  if (playingIdx >= 0) {
    QueuedNote &q = queue_[playingIdx];
    if (q.freq > 0) {
      tone(pin_, q.freq);
      toneActive_ = true;
    } else {
      stopTone();
    }
  } else {
    stopTone();
  }
}
