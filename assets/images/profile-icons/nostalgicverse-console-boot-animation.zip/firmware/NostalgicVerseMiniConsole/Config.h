#pragma once
// ============================================================================
// NostalgicVerse Mini Console — Hardware Configuration
// ESP32 NodeMCU-32S · 128x64 SSD1306 OLED · DS1307 RTC · 4x4 keypad · buzzer
// ============================================================================

// ---- I2C (OLED + DS1307 share the bus) ------------------------------------
#define NV_I2C_SDA 21
#define NV_I2C_SCL 22

// ---- OLED -------------------------------------------------------------
#define NV_OLED_W 128
#define NV_OLED_H 64
#define NV_OLED_ADDR 0x3C
#define NV_OLED_RESET -1

// ---- Buzzer (passive, single pin, driven with ledcWriteTone / tone()) -----
#define NV_BUZZER_PIN 25

// ---- 4x4 membrane keypad ----------------------------------------------
// Rows are OUTPUT, columns are INPUT_PULLUP. Adjust to your wiring.
#define NV_KEYPAD_ROW_PINS \
  { 13, 12, 14, 27 }
#define NV_KEYPAD_COL_PINS \
  { 26, 33, 32, 15 }

// ---- Feature flags ------------------------------------------------------
#define NV_ENABLE_WIFI 1
#define NV_ENABLE_BLUETOOTH 1
#define NV_ENABLE_SD 0 // future microSD expansion

// ---- Persisted settings defaults ----------------------------------------
#define NV_DEFAULT_STARTUP_ANIM true
#define NV_DEFAULT_SOUND_ON true
