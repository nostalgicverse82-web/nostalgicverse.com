#pragma once
// ============================================================================
// Single source of truth for which "screen"/subsystem currently owns the
// display + input. The whole OS is one big state machine switched in loop().
// ============================================================================

enum class SystemState : uint8_t {
  BOOT_INTRO = 0,
  MAIN_MENU,
  GAME_LIBRARY,
  ARCADE,
  MUSIC_PLAYER,
  CLOCK,
  UTILITIES,
  ACHIEVEMENTS,
  STATISTICS,
  DEVICES,
  WIFI,
  SAVE_DATA,
  SETTINGS,
  GAME_PIXEL_QUEST,
  GAME_ALIEN_SIEGE,
  DEV_DIAGNOSTICS, // hidden developer-mode state
};

// Unified input frame — populated identically whether the source is the
// physical keypad, the WiFi mobile-controller web page, or a paired BLE
// gamepad. Games and menus only ever read from this struct.
struct InputFrame {
  bool up = false, down = false, left = false, right = false;
  bool a = false, b = false, start = false, select = false;
  bool justUp = false, justDown = false, justLeft = false, justRight = false;
  bool justA = false, justB = false, justStart = false, justSelect = false;
};

enum class InputSource : uint8_t { KEYPAD, MOBILE_WIFI, BLUETOOTH };
