#pragma once
#include <Arduino.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "ParticleSystem.h"
#include "RTCService.h"
#include "SoundEngine.h"
#include "SystemState.h"

// ============================================================================
// BootIntro — the ~15 second cinematic boot sequence, built as a pure
// millis()-driven timeline. Mirrors `bootTimeline.ts` / `BootIntro.tsx` from
// the companion web prototype 1:1 so the feel is identical on real hardware.
//
//   VOID -> SIGNAL -> CORE -> DIAG -> RTC -> UNIVERSE -> CONNECT -> RACE
//        -> LOGO -> FINAL (holds on "PRESS START")
//
// No delay() is used anywhere. Call update() every loop() iteration; it
// returns true exactly once, the frame the user should be handed off to
// MAIN_MENU.
// ============================================================================

namespace NVBootTimeline {
constexpr uint32_t VOID_END = 850;
constexpr uint32_t SIGNAL_END = 1750;
constexpr uint32_t CORE_END = 2950;
constexpr uint32_t DIAG_END = 4250;
constexpr uint32_t RTC_END = 5550;
constexpr uint32_t UNIVERSE_END = 7200;
constexpr uint32_t CONNECT_END = 8600;
constexpr uint32_t RACE_END = 10600;
constexpr uint32_t LOGO_END = 11300;
constexpr uint32_t FINAL_START = 11300;
}  // namespace NVBootTimeline

struct HardwareStatus {
  bool display = true;
  bool input = true;
  bool audio = true;
  bool rtc = false;
  bool wifi = false;
  bool bluetooth = false;
  bool save = true; // NVS / Preferences available
};

class BootIntro {
 public:
  void begin(Adafruit_SSD1306 *gfx, const HardwareStatus &hw, bool soundOn);
  // Returns true the frame it finishes (user pressed START, or held long
  // enough post-FINAL and pressed A/START).
  bool update(const InputFrame &input);

 private:
  void scheduleAudio();
  void render(uint32_t elapsed);

  void phaseVoid(uint32_t l);
  void phaseSignal(uint32_t l);
  void phaseCore(uint32_t l);
  void phaseDiag(uint32_t l);
  void phaseRtc(uint32_t l);
  void phaseUniverse(uint32_t l);
  void phaseConnect(uint32_t l);
  void phaseRace(uint32_t l);
  void phaseLogo(uint32_t l);
  void phaseFinal(uint32_t l);

  void buildLogoTargets();
  bool once(uint8_t id);

  Adafruit_SSD1306 *gfx_ = nullptr;
  HardwareStatus hw_;
  uint32_t startMs_ = 0;
  uint32_t lastMs_ = 0;
  bool firedFlags_[48] = {false};
  bool logoBuilt_ = false;
  bool finished_ = false;
  DateTime capturedTime_;
  bool timeCaptured_ = false;

  static constexpr uint8_t kMaxLogoPoints = 160;
  float logoX_[kMaxLogoPoints];
  float logoY_[kMaxLogoPoints];
  uint8_t logoCount_ = 0;

  ParticlePool<200> particles_;
};
