// ============================================================================
// NostalgicVerse Mini Console — Main Firmware Entry Point
// Target: ESP32 NodeMCU-32S, Arduino IDE
//
// Required libraries (Library Manager):
//   - Adafruit SSD1306
//   - Adafruit GFX Library
//   - RTClib (Adafruit)
//   - Keypad (by Mark Stanley / Alexander Brevig)
//   - (optional) ESPAsyncWebServer + AsyncTCP for the mobile WiFi controller
//   - (optional) NimBLE-Arduino for the Bluetooth controller (e.g. Cosmic
//     Byte Lumora) and the console's own BLE HID reporting
//
// This file only wires the subsystems together — see Config.h, SystemState.h,
// SoundEngine.*, ParticleSystem.h, InputManager.h, RTCService.h and
// BootIntro.* for the actual implementations. Everything here uses millis()
// based scheduling; there is no delay() anywhere in the hot path.
// ============================================================================

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#include "Config.h"
#include "SystemState.h"
#include "SoundEngine.h"
#include "InputManager.h"
#include "RTCService.h"
#include "BootIntro.h"

Adafruit_SSD1306 display(NV_OLED_W, NV_OLED_H, &Wire, NV_OLED_RESET);
InputManager Input;
RTCService Clock;
BootIntro bootIntro;

SystemState systemState = SystemState::BOOT_INTRO;
HardwareStatus hwStatus;

void setup() {
  Serial.begin(115200);
  Wire.begin(NV_I2C_SDA, NV_I2C_SCL);

  // ---- Hardware bring-up — every flag below reflects REALITY, never a
  // hard-coded assumption. If a sensor isn't found, the boot animation and
  // the Devices/Settings screens will honestly report it. ----------------
  hwStatus.display = display.begin(SSD1306_SWITCHCAPVCC, NV_OLED_ADDR);
  hwStatus.rtc = Clock.begin();
  Sound.begin(NV_BUZZER_PIN);
  hwStatus.audio = true; // buzzer pin always drivable; no self-test IC
  Input.begin();
  hwStatus.input = true;
#if NV_ENABLE_WIFI
  // WiFi.mode(WIFI_AP); WiFi.softAP("NostalgicVerse-AP"); ...
  hwStatus.wifi = true; // set from actual WiFi.status()/softAP() result
#endif
#if NV_ENABLE_BLUETOOTH
  hwStatus.bluetooth = true; // set from actual BLE init() result
#endif
  hwStatus.save = true; // Preferences::begin() succeeded

  if (!hwStatus.display) {
    // Can't draw — blink the buzzer in a diagnostic SOS-like pattern and halt
    // the normal state machine. A lesser console would just freeze silently.
    Sound.beep(300, 200, 0);
  }

  bool startupAnimEnabled = NV_DEFAULT_STARTUP_ANIM; // load from Preferences
  bool soundEnabled = NV_DEFAULT_SOUND_ON;            // load from Preferences

  if (startupAnimEnabled) {
    bootIntro.begin(&display, hwStatus, soundEnabled);
    systemState = SystemState::BOOT_INTRO;
  } else {
    systemState = SystemState::MAIN_MENU;
  }
}

void loop() {
  Input.update();
  Sound.update();
  const InputFrame &in = Input.frame();

  switch (systemState) {
    case SystemState::BOOT_INTRO: {
      bool done = bootIntro.update(in);
      if (done) systemState = SystemState::MAIN_MENU;
      break;
    }

    case SystemState::MAIN_MENU:
      // renderMainMenu(display, in); — see the web prototype's MainMenu.tsx
      // for the exact list of destinations (Game Library, Arcade, Music
      // Player, Clock, Utilities, Achievements, Statistics, Devices, WiFi,
      // Save Data, Settings) and mirror that structure here.
      break;

    // ... GAME_LIBRARY, ARCADE, MUSIC_PLAYER, CLOCK, UTILITIES,
    //     ACHIEVEMENTS, STATISTICS, DEVICES, WIFI, SAVE_DATA, SETTINGS,
    //     GAME_PIXEL_QUEST, GAME_ALIEN_SIEGE all follow the same pattern:
    //     a `screenXxx(display, in)` function that reads `in` once per
    //     frame and draws to `display`. Keep every one of them non-blocking.

    default:
      break;
  }
}
