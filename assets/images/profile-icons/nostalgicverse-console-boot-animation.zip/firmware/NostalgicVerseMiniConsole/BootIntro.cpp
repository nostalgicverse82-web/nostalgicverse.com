#include "BootIntro.h"
using namespace NVBootTimeline;

static const uint16_t NV_WHITE = SSD1306_WHITE;
static const uint16_t NV_BLACK = SSD1306_BLACK;

void BootIntro::begin(Adafruit_SSD1306 *gfx, const HardwareStatus &hw, bool soundOn) {
  gfx_ = gfx;
  hw_ = hw;
  startMs_ = millis();
  lastMs_ = startMs_;
  finished_ = false;
  logoBuilt_ = false;
  timeCaptured_ = false;
  memset(firedFlags_, 0, sizeof(firedFlags_));
  particles_.clear();
  Sound.setEnabled(soundOn);
  if (soundOn) scheduleAudio();
}

bool BootIntro::once(uint8_t id) {
  if (firedFlags_[id]) return false;
  firedFlags_[id] = true;
  return true;
}

void BootIntro::scheduleAudio() {
  // VOID clicks
  Sound.beep(1900, 25, 150);
  Sound.beep(1900, 25, 340);
  Sound.beep(1900, 25, 520);
  Sound.beep(1900, 25, 680);
  // SIGNAL sweep + snap (approximate a sweep with a couple of rising tones)
  Sound.beep(300, 120, 900);
  Sound.beep(700, 120, 1020);
  Sound.beep(1200, 150, 1140);
  Sound.beep(90, 90, SIGNAL_END - 60); // snap thump
  // CORE ticks
  Sound.beep(820, 45, VOID_END + 300);
  Sound.beep(1000, 45, VOID_END + 500);
  Sound.beep(1400, 180, VOID_END + 720);
  // DIAG confirmations
  for (uint8_t i = 0; i < 7; i++) Sound.beep(900 + i * 70, 45, DIAG_END - 1200 + i * 150);
  Sound.beep(1600, 120, DIAG_END - 140);
  // RTC clicks
  for (uint8_t i = 0; i < 8; i++) Sound.beep(1900, 20, RTC_END - 1300 + i * 70);
  // RACE countdown
  Sound.beep(700, 120, RACE_END - 1500 + 60);
  Sound.beep(700, 120, RACE_END - 1500 + 420);
  Sound.beep(700, 120, RACE_END - 1500 + 780);
  Sound.beep(1400, 280, RACE_END - 1500 + 1140);
  Sound.beep(150, 200, RACE_END - 140);
  // LOGO reveal + signature
  Sound.beep(120, 220, LOGO_END - 600 + 80);
  Sound.playSignature(LOGO_END - 600 + 260);
}

bool BootIntro::update(const InputFrame &input) {
  uint32_t elapsed = millis() - startMs_;
  Sound.update();
  render(elapsed);

  if (elapsed >= FINAL_START + 400) {
    if (input.justA || input.justStart) finished_ = true;
  }
  return finished_;
}

void BootIntro::render(uint32_t elapsed) {
  float dt = (millis() - lastMs_) / 1000.0f;
  lastMs_ = millis();
  particles_.update(dt);

  gfx_->clearDisplay();
  gfx_->setTextColor(NV_WHITE);

  if (elapsed < VOID_END) phaseVoid(elapsed);
  else if (elapsed < SIGNAL_END) phaseSignal(elapsed - VOID_END);
  else if (elapsed < CORE_END) phaseCore(elapsed - SIGNAL_END);
  else if (elapsed < DIAG_END) phaseDiag(elapsed - CORE_END);
  else if (elapsed < RTC_END) phaseRtc(elapsed - DIAG_END);
  else if (elapsed < UNIVERSE_END) phaseUniverse(elapsed - RTC_END);
  else if (elapsed < CONNECT_END) phaseConnect(elapsed - UNIVERSE_END);
  else if (elapsed < RACE_END) phaseRace(elapsed - CONNECT_END);
  else if (elapsed < LOGO_END) phaseLogo(elapsed - RACE_END);
  else phaseFinal(elapsed - LOGO_END);

  particles_.draw(*gfx_, NV_WHITE);
  gfx_->display();
}

// ---------------------------------------------------------------- VOID -----
void BootIntro::phaseVoid(uint32_t l) {
  struct Dot { uint32_t t; int16_t x, y; };
  static const Dot dots[] = {{150, 64, 30}, {340, 71, 26}, {520, 58, 33}, {680, 67, 36}};
  for (auto &d : dots) {
    if (l >= d.t) gfx_->drawPixel(d.x, d.y, NV_WHITE);
  }
  if (l > 760) {
    gfx_->setCursor(58, 44);
    gfx_->setTextSize(1);
    gfx_->print("...");
  }
}

// -------------------------------------------------------------- SIGNAL -----
void BootIntro::phaseSignal(uint32_t l) {
  const uint32_t snapAt = 650;
  if (l < snapAt) {
    float t = (float)l / snapAt;
    float w = (1 - (1 - t) * (1 - t) * (1 - t)) * 128;
    gfx_->drawFastHLine(64 - w / 2, 30, max(1.0f, w), NV_WHITE);
  } else if (once(1)) {
    for (uint8_t i = 0; i < 40; i++) {
      float ang = (TWO_PI * i) / 40.0f;
      particles_.spawn(64, 30, cosf(ang) * 24, sinf(ang) * 24, 900);
    }
  }
}

// ---------------------------------------------------------------- CORE -----
void BootIntro::phaseCore(uint32_t l) {
  if (once(2)) {
    for (auto &p : particles_.pool_) {
      if (p.active) { p.tx = 64; p.ty = 30; }
    }
  }
  float energy = 0;
  const uint32_t pulses[] = {120, 320, 560};
  for (auto pt : pulses) if (l >= pt) energy += expf(-(l - pt) / 130.0f);
  int r = 2 + (int)(energy * 3);
  gfx_->fillCircle(64, 30, r, NV_WHITE);
  if (l > 600) {
    float rp = min(1.0f, (l - 600) / 420.0f);
    gfx_->drawCircle(64, 30, (int)(rp * 70), NV_WHITE);
  }
}

// ---------------------------------------------------------------- DIAG -----
void BootIntro::phaseDiag(uint32_t l) {
  const char *labels[] = {"CORE", "DISPLAY", "INPUT", "AUDIO", "RTC", "WIFI", "BT", "SAVE"};
  bool ok[] = {true, hw_.display, hw_.input, hw_.audio, hw_.rtc, hw_.wifi, hw_.bluetooth, hw_.save};
  const uint32_t dur = DIAG_END - CORE_END;
  if (l > dur - 260) {
    gfx_->setTextSize(1);
    gfx_->setCursor(44, 24);
    gfx_->print("SYSTEM");
    gfx_->setCursor(46, 36);
    gfx_->print("READY");
    return;
  }
  gfx_->setTextSize(1);
  for (uint8_t i = 0; i < 8; i++) {
    uint8_t col = i < 4 ? 0 : 1;
    uint8_t row = i % 4;
    int16_t x = 6 + col * 64;
    int16_t y = 6 + row * 14;
    float p = (l - i * 110) / 260.0f;
    if (p <= 0) continue;
    p = min(1.0f, p);
    gfx_->setCursor(x, y);
    gfx_->print(labels[i]);
    gfx_->drawRect(x, y + 8, 26, 3, NV_WHITE);
    gfx_->fillRect(x, y + 8, (int)(26 * p), 3, NV_WHITE);
    if (p >= 1.0f) {
      gfx_->setCursor(x + 30, y);
      gfx_->print(ok[i] ? "OK" : "!");
    }
  }
}

// ----------------------------------------------------------------- RTC -----
void BootIntro::phaseRtc(uint32_t l) {
  if (!timeCaptured_) {
    capturedTime_ = Clock.now();
    timeCaptured_ = true;
  }
  gfx_->setTextSize(1);
  if (l < 250) {
    gfx_->setCursor(54, 20);
    gfx_->print("RTC");
    gfx_->setCursor(44, 34);
    gfx_->print("SYNC");
    return;
  }
  char buf[16];
  if (hw_.rtc) {
    snprintf(buf, sizeof(buf), "%02d:%02d:%02d", capturedTime_.hour(), capturedTime_.minute(), capturedTime_.second());
  } else {
    snprintf(buf, sizeof(buf), "RTC !");
  }
  gfx_->setTextSize(2);
  gfx_->setCursor(20, 24);
  gfx_->print(buf);
}

// ------------------------------------------------------------ UNIVERSE -----
void BootIntro::phaseUniverse(uint32_t l) {
  const uint32_t sceneLen = (UNIVERSE_END - RTC_END) / 4;
  uint8_t idx = min((uint32_t)3, l / sceneLen);
  float lt = (float)(l - idx * sceneLen) / sceneLen;
  const char *names[] = {"PIXEL QUEST", "FQ RACING", "ALIEN SIEGE", "ARCADE CORE"};
  gfx_->setTextSize(1);
  gfx_->setCursor(2, 2);
  gfx_->print(names[idx]);

  if (idx == 0) {
    gfx_->drawFastHLine(0, 50, 128, NV_WHITE);
    float jump = sinf(min(1.0f, lt * 1.6f) * PI);
    gfx_->fillRect(28, 50 - (int)(jump * 18) - 4, 4, 4, NV_WHITE);
  } else if (idx == 1) {
    for (uint8_t i = 0; i < 4; i++) {
      int y = ((int)(i * 14 + lt * 60)) % 64;
      gfx_->fillRect(60 - 6, y, 12, 1, NV_WHITE);
    }
  } else if (idx == 2) {
    gfx_->fillRect(12, 28, 6, 4, NV_WHITE);
    gfx_->fillRect(18 + (int)(lt * 85), 30, 3, 1, NV_WHITE);
  } else {
    gfx_->drawRect(54, 22, 20, 16, NV_WHITE);
    gfx_->setCursor(50, 44);
    gfx_->print("READY");
  }
}

// ------------------------------------------------------------- CONNECT -----
void BootIntro::phaseConnect(uint32_t l) {
  gfx_->setTextSize(1);
  if (l < 450) {
    gfx_->drawRect(10, 40, 12, 12, NV_WHITE);  // keypad
    gfx_->drawRoundRect(60, 6, 10, 16, 2, NV_WHITE); // phone
    gfx_->drawRoundRect(104, 40, 16, 10, 3, NV_WHITE); // controller
    if (l > 430) {
      gfx_->setCursor(36, 54);
      gfx_->print("INPUT READY");
    }
  } else if (l < 820) {
    gfx_->drawCircle(64, 40, 10, NV_WHITE);
    gfx_->drawCircle(64, 40, 18, NV_WHITE);
    if (l > 780) {
      gfx_->setCursor(30, 54);
      gfx_->print(hw_.wifi ? "WIFI READY" : "WIFI OFFLINE");
    }
  } else {
    gfx_->fillTriangle(60, 20, 68, 44, 60, 44, NV_WHITE);
    if (l > 1150) {
      gfx_->setCursor(38, 54);
      gfx_->print(hw_.bluetooth ? "BT READY" : "BT N/A");
    }
  }
}

// ---------------------------------------------------------------- RACE -----
void BootIntro::phaseRace(uint32_t l) {
  gfx_->drawLine(0, 64, 58, 14, NV_WHITE);
  gfx_->drawLine(128, 64, 70, 14, NV_WHITE);
  if (l < 1140) {
    gfx_->fillRect(59, 45, 10, 5, NV_WHITE);
    gfx_->setTextSize(2);
    gfx_->setCursor(60, 24);
    gfx_->print(l < 380 ? "3" : l < 760 ? "2" : "1");
  } else if (l < 1180) {
    gfx_->setTextSize(2);
    gfx_->setCursor(52, 24);
    gfx_->print("GO");
  } else {
    float p = min(1.0f, (l - 1180) / 400.0f);
    int carX = 64 + (int)(p * 120);
    gfx_->fillRect(carX, 45, 10, 5, NV_WHITE);
    if (once(10)) {
      for (uint8_t i = 0; i < 30; i++) {
        particles_.spawn(random(60, 128), 45 + random(-4, 4), random(60, 160), random(-10, 10), 500);
      }
    }
  }
}

// ---------------------------------------------------------------- LOGO -----
void BootIntro::buildLogoTargets() {
  // A hand-mapped low-res dot representation of "NOSTALGICVERSE" — real
  // firmware could instead rasterize a small bitmap font at boot and sample
  // its lit pixels, exactly like the web prototype's sampleTextPoints().
  logoCount_ = 0;
  gfx_->setTextSize(1);
  // We approximate by letting GFX report nothing; instead we space points
  // evenly under a 128px-wide title band as a stylised "data mosaic" burst.
  for (uint8_t i = 0; i < kMaxLogoPoints; i++) {
    logoX_[i] = 10 + (i % 40) * 2.6f;
    logoY_[i] = 24 + (i / 40) * 5.0f;
  }
  logoCount_ = kMaxLogoPoints;
  logoBuilt_ = true;
}

void BootIntro::phaseLogo(uint32_t l) {
  if (!logoBuilt_) buildLogoTargets();
  if (l < 80) return;
  if (once(20)) {
    particles_.assemble(logoX_, logoY_, logoCount_);
  }
}

// --------------------------------------------------------------- FINAL -----
void BootIntro::phaseFinal(uint32_t l) {
  if (particles_.activeCount() < 10 && once(21)) {
    particles_.assemble(logoX_, logoY_, logoCount_);
  }
  gfx_->setTextSize(1);
  gfx_->setCursor(30, 2);
  gfx_->print("NOSTALGICVERSE");
  if (l > 180) {
    gfx_->setCursor(36, 46);
    gfx_->print("MINI CONSOLE");
  }
  if (l > 360) {
    gfx_->setCursor(30, 54);
    gfx_->print(hw_.rtc ? "RTC OK" : "RTC !");
  }
  if (l > 500 && ((l / 480) % 2 == 0)) {
    gfx_->setCursor(32, 64 - 8);
    gfx_->print("PRESS START");
  }
}
