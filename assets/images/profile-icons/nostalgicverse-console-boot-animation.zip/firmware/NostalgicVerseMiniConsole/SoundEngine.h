#pragma once
#include <Arduino.h>

// ============================================================================
// SoundEngine — fully non-blocking buzzer "chiptune" driver.
//
// IMPORTANT: nothing in here ever calls delay(). A fixed-size queue of notes
// is scheduled with absolute millis() timestamps and serviced from update(),
// which must be called every loop() iteration.
// ============================================================================

struct NVNote {
  uint16_t freq; // Hz, 0 = rest
  uint16_t durationMs;
};

class SoundEngine {
 public:
  static constexpr uint8_t kQueueSize = 48;

  void begin(uint8_t pin);
  void setEnabled(bool on) { enabled_ = on; if (!on) stopTone(); }
  bool isEnabled() const { return enabled_; }

  // Queue a single tone `delayMs` from now (relative to time of call).
  void beep(uint16_t freq, uint16_t durationMs, uint32_t delayMs = 0);

  // Queue a whole melody, each note chained after the previous one.
  void playMelody(const NVNote *notes, uint8_t count, uint32_t startDelayMs = 0);

  // The recognizable 3-note signature — reused for boot / achievements /
  // victories / game launches.
  void playSignature(uint32_t delayMs = 0);

  void clear();          // drop everything queued/playing
  void update();         // call every loop()

 private:
  struct QueuedNote {
    bool active = false;
    uint16_t freq;
    uint32_t startAt;
    uint32_t endAt;
  };

  void stopTone();

  uint8_t pin_ = 255;
  bool enabled_ = true;
  bool toneActive_ = false;
  QueuedNote queue_[kQueueSize];
};

extern SoundEngine Sound;
