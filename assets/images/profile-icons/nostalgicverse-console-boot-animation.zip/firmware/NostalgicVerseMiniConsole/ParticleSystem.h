#pragma once
#include <Arduino.h>
#include <Adafruit_GFX.h>

// ============================================================================
// Fixed-size particle pool for the 128x64 OLED. No heap allocation — every
// particle lives in a pre-allocated array for the lifetime of the program,
// which is required to keep the ESP32's boot animation deterministic and
// safe from fragmentation.
// ============================================================================

struct Particle {
  bool active = false;
  float x = 0, y = 0;
  float vx = 0, vy = 0;
  float tx = NAN, ty = NAN; // optional "assemble" target
  float life = 0, maxLife = 1;
};

template <uint8_t N>
class ParticlePool {
 public:
  void clear() {
    for (auto &p : pool_) p.active = false;
  }

  Particle *spawn(float x, float y, float vx, float vy, float life) {
    for (auto &p : pool_) {
      if (!p.active) {
        p = Particle{};
        p.active = true;
        p.x = x;
        p.y = y;
        p.vx = vx;
        p.vy = vy;
        p.life = life;
        p.maxLife = life;
        return &p;
      }
    }
    return nullptr; // pool exhausted — caller should degrade gracefully
  }

  // Force the whole pool to converge on `targets[0..count)` — used for the
  // "particles assemble into the logo" beat.
  void assemble(const float *txs, const float *tys, uint8_t count) {
    for (uint8_t i = 0; i < N; i++) {
      if (i >= count) {
        pool_[i].active = false;
        continue;
      }
      Particle &p = pool_[i];
      if (!p.active) {
        p.x = random(0, 128);
        p.y = random(0, 64);
      }
      p.active = true;
      p.tx = txs[i];
      p.ty = tys[i];
      p.life = p.maxLife = 9999;
    }
  }

  void update(float dtSeconds, float drag = 0.98f) {
    for (auto &p : pool_) {
      if (!p.active) continue;
      p.life -= dtSeconds * 1000.0f;
      if (p.life <= 0) {
        p.active = false;
        continue;
      }
      if (!isnan(p.tx)) {
        p.x += (p.tx - p.x) * min(1.0f, dtSeconds * 6.0f);
        p.y += (p.ty - p.y) * min(1.0f, dtSeconds * 6.0f);
      } else {
        p.x += p.vx * dtSeconds;
        p.y += p.vy * dtSeconds;
        p.vx *= drag;
        p.vy *= drag;
      }
    }
  }

  void draw(Adafruit_GFX &gfx, uint16_t color) const {
    for (auto &p : pool_) {
      if (p.active) gfx.drawPixel((int16_t)p.x, (int16_t)p.y, color);
    }
  }

  uint8_t activeCount() const {
    uint8_t n = 0;
    for (auto &p : pool_) if (p.active) n++;
    return n;
  }

  Particle pool_[N];
};
