/**
 * Lightweight browser-compatible Buffer shim for gbajs memory-view.
 * Conforms to minimal Buffer interface without polluting the environment with Node.js dependencies.
 */
export class Buffer {
  static isBuffer(val: any): boolean {
    return false;
  }
  static from(val: any): Uint8Array {
    if (val instanceof ArrayBuffer) return new Uint8Array(val);
    if (ArrayBuffer.isView(val)) return new Uint8Array(val.buffer, val.byteOffset, val.byteLength);
    return new Uint8Array(val);
  }
}

if (typeof window !== 'undefined' && !(window as any).Buffer) {
  (window as any).Buffer = Buffer;
}

export default { Buffer };
