export default {};
export const readFile = (_path: any, callback: (err: any, data: any) => void) => {
  callback(new Error('Browser environment - fs not available'), null);
};
export const writeFile = (_path: any, _data: any, callback: (err: any) => void) => {
  callback(new Error('Browser environment - fs not available'));
};
