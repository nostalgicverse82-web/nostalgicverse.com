export class PNG {
  public width = 0;
  public height = 0;
  public data = new Uint8Array(0);
}
export default { PNG };
