import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { 
  GameItem, 
  ConsoleId, 
  SaveStateItem, 
  GraphicsSettings, 
  AudioSettings, 
  PerformanceProfileConfig, 
  MediaCaptureItem,
  UIMode,
  ConsoleOSSection,
  ControllerDevice,
  ToastItem
} from '../types/emulator';
import { 
  MOCK_GAMES, 
  MOCK_CONSOLES, 
  MOCK_SAVE_STATES, 
  MOCK_CONTROLLERS, 
  MOCK_MEDIA 
} from '../data/mockData';
import { soundFx } from '../services/soundFx';
import { controllerManager } from '../core/input/ControllerManager';
import { NormalizedButton, NormalizedGamepadState, InputMode } from '../core/input/types';
import { wallpaperManager, WallpaperItem, WallpaperSettings } from '../core/wallpaper/WallpaperManager';
import { consoleCoreManager, EmulationRuntimeState } from '../core/emulator/ConsoleCoreManager';

interface ConsoleOSContextType {
  // UI & Operating System Mode
  uiMode: UIMode;
  setUIMode: (mode: UIMode) => void;
  activeSection: ConsoleOSSection;
  setActiveSection: (section: ConsoleOSSection) => void;
  inputMode: InputMode;
  
  // Games & Focused State
  games: GameItem[];
  filteredGames: GameItem[];
  focusedGameIndex: number;
  setFocusedGameIndex: (index: number) => void;
  focusedGame: GameItem;
  activeRunningGame: GameItem | null;
  selectedGameForDetails: GameItem | null;
  setSelectedGameForDetails: (game: GameItem | null) => void;
  selectedConsole: string;
  setSelectedConsole: (filter: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  toggleFavorite: (gameId: string) => void;
  importRomGame: (game: GameItem, rawData?: Uint8Array) => void;

  // Modals & Navigation
  isDetailsModalOpen: boolean;
  openGameDetails: (game: GameItem) => void;
  closeGameDetails: () => void;
  isSettingsOpen: boolean;
  openSettings: () => void;
  closeSettings: () => void;
  isSaveStatesOpen: boolean;
  openSaveStates: () => void;
  closeSaveStates: () => void;
  isScannerOpen: boolean;
  openScanner: () => void;
  closeScanner: () => void;
  isControllerMapperOpen: boolean;
  openControllerMapper: () => void;
  closeControllerMapper: () => void;
  quickMenuOpen: boolean;
  setQuickMenuOpen: (open: boolean) => void;

  // Controller, Audio, & HUD
  controllers: ControllerDevice[];
  activeGamepadState: NormalizedGamepadState | null;
  isControllerConnected: boolean;
  setIsControllerConnected: (connected: boolean) => void;
  activeControllerButton: string | null;
  soundMuted: boolean;
  toggleSoundMute: () => void;
  isFullscreen: boolean;
  toggleFullscreen: () => void;
  timeString: string;
  batteryLevel: number;
  isMuted: boolean;
  setIsMuted: (muted: boolean) => void;
  soundVolume: number;
  setSoundVolume: (vol: number) => void;
  accentColor: string;
  setAccentColor: (color: string) => void;

  // Wallpapers
  activeWallpaper: WallpaperItem;
  wallpaperSettings: WallpaperSettings;
  updateWallpaperSettings: (settings: Partial<WallpaperSettings>) => void;
  uploadCustomWallpaper: (file: File) => Promise<void>;

  // Emulation Gameplay Runtime State
  runtimeState: EmulationRuntimeState;
  runtimeError: string | null;
  isPaused: boolean;
  setIsPaused: (paused: boolean) => void;
  isFastForward: boolean;
  setIsFastForward: (ff: boolean) => void;
  toggleFastForward: () => void;
  isRewind: boolean;
  setIsRewind: (rewind: boolean) => void;
  isRecording: boolean;
  toggleRecording: () => void;
  launchGame: (game: GameItem, resume?: boolean, romBytes?: Uint8Array) => void;
  pauseGame: () => void;
  resumeGame: () => void;
  exitGame: () => void;

  // Saves & Media
  saveStates: SaveStateItem[];
  createSaveState: (gameIdOrSlot?: string | number, slotNumber?: number) => void;
  loadSaveState: (stateOrId: SaveStateItem | string) => void;
  deleteSaveState: (id: string) => void;
  mediaItems: MediaCaptureItem[];
  captureScreenshot: () => void;

  // Hardware Configurations
  graphicsSettings: GraphicsSettings;
  setGraphicsSettings: React.Dispatch<React.SetStateAction<GraphicsSettings>>;
  audioSettings: AudioSettings;
  setAudioSettings: React.Dispatch<React.SetStateAction<AudioSettings>>;
  performanceConfig: PerformanceProfileConfig;
  setPerformanceConfig: React.Dispatch<React.SetStateAction<PerformanceProfileConfig>>;
  touchLayout: string;
  optimizeRuntime: () => void;

  // Toasts
  toasts: ToastItem[];
  addToast: (message: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
  removeToast: (id: string) => void;
}

const defaultGraphics: GraphicsSettings = {
  renderer: 'vulkan',
  internalResolution: '3x',
  textureFiltering: 'nearest',
  textureScaling: 'off',
  antiAliasing: 'off',
  vsync: true,
  framePacing: 'smooth',
  shaderCache: true,
  crtFilter: false,
  scanlines: false,
  widescreenHack: false,
  integerScaling: true,
  bloom: false,
  colorCorrection: true,
  sharpening: 0
};

const defaultAudio: AudioSettings = {
  backend: 'aaudio',
  volume: 85,
  latency: 'low',
  audioStretching: true,
  timeStretching: true,
  channels: 'stereo',
  mute: false
};

const defaultPerformance: PerformanceProfileConfig = {
  profile: 'balanced',
  adaptivePerformance: true,
  dynamicResolution: false,
  thermalProtection: true,
  backgroundJit: true,
  targetFps: 60
};

const ConsoleOSContext = createContext<ConsoleOSContextType | undefined>(undefined);

export const ConsoleOSProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [uiMode, setUIModeState] = useState<UIMode>(() => {
    if (typeof window !== 'undefined') {
      if (window.innerWidth < 640) return 'MOBILE_PORTRAIT';
      if (window.innerWidth < 1024 && window.innerHeight < 600) return 'MOBILE_LANDSCAPE';
    }
    return 'DESKTOP_CONSOLE';
  });

  const [activeSection, setActiveSection] = useState<ConsoleOSSection>('for-you');
  const [games, setGames] = useState<GameItem[]>(MOCK_GAMES);
  const [focusedGameIndex, setFocusedGameIndexState] = useState<number>(0);
  const [activeRunningGame, setActiveRunningGame] = useState<GameItem | null>(null);
  const [selectedGameForDetails, setSelectedGameForDetails] = useState<GameItem | null>(null);
  const [selectedConsole, setSelectedConsole] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [accentColor, setAccentColor] = useState<string>('cyan');
  const [batteryLevel, setBatteryLevel] = useState<number>(94);
  const [touchLayout, setTouchLayout] = useState<string>('standard-ergonomic');
  const [inputMode, setInputMode] = useState<InputMode>('mouse');

  // Modals
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isSaveStatesOpen, setIsSaveStatesOpen] = useState<boolean>(false);
  const [isScannerOpen, setIsScannerOpen] = useState<boolean>(false);
  const [isControllerMapperOpen, setIsControllerMapperOpen] = useState<boolean>(false);
  const [quickMenuOpen, setQuickMenuOpen] = useState<boolean>(false);

  // Controller State
  const [controllers, setControllers] = useState<ControllerDevice[]>(MOCK_CONTROLLERS);
  const [activeGamepadState, setActiveGamepadState] = useState<NormalizedGamepadState | null>(null);
  const [isControllerConnected, setIsControllerConnected] = useState<boolean>(false);
  const [activeControllerButton, setActiveControllerButton] = useState<string | null>(null);

  // Audio & Clock
  const [soundMuted, setSoundMuted] = useState<boolean>(false);
  const [soundVolume, setSoundVolume] = useState<number>(85);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [timeString, setTimeString] = useState<string>('');

  // Emulation State Machine
  const [runtimeState, setRuntimeState] = useState<EmulationRuntimeState>('LAUNCHER');
  const [runtimeError, setRuntimeError] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isFastForward, setIsFastForward] = useState<boolean>(false);
  const [isRewind, setIsRewind] = useState<boolean>(false);
  const [isRecording, setIsRecording] = useState<boolean>(false);

  // Saves & Media
  const [saveStates, setSaveStates] = useState<SaveStateItem[]>(MOCK_SAVE_STATES);
  const [mediaItems, setMediaItems] = useState<MediaCaptureItem[]>(MOCK_MEDIA);
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  // Wallpaper System
  const [wallpaperSettings, setWallpaperSettings] = useState<WallpaperSettings>(wallpaperManager.getSettings());

  // Settings
  const [graphicsSettings, setGraphicsSettings] = useState<GraphicsSettings>(defaultGraphics);
  const [audioSettings, setAudioSettings] = useState<AudioSettings>(defaultAudio);
  const [performanceConfig, setPerformanceConfig] = useState<PerformanceProfileConfig>(defaultPerformance);

  const importedRomsCache = useRef<Map<string, Uint8Array>>(new Map());
  const selectStartTimeRef = useRef<number | null>(null);

  const addToast = (message: string, type: 'info' | 'success' | 'warning' | 'error' = 'info') => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    setToasts(prev => [...prev.slice(-2), { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3200);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const filteredGames = games.filter(g => {
    const matchesConsole = selectedConsole === 'all' || g.consoleId === selectedConsole;
    const matchesSearch = !searchQuery || g.title.toLowerCase().includes(searchQuery.toLowerCase()) || g.genre.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesConsole && matchesSearch;
  });

  const focusedGame = filteredGames[focusedGameIndex] || filteredGames[0] || games[0];

  const activeWallpaper = wallpaperManager.getActiveWallpaperForGame(
    focusedGame?.id,
    focusedGame?.title,
    focusedGame?.bannerGradient
  );

  const setFocusedGameIndex = (index: number) => {
    if (index >= 0 && index < filteredGames.length) {
      soundFx.playFocus();
      setFocusedGameIndexState(index);
    }
  };

  const setUIMode = (mode: UIMode) => {
    soundFx.playSelect();
    setUIModeState(mode);
  };

  const updateWallpaperSettings = (newSettings: Partial<WallpaperSettings>) => {
    wallpaperManager.updateSettings(newSettings);
    setWallpaperSettings(wallpaperManager.getSettings());
    addToast('Wallpaper configuration applied', 'info');
  };

  const uploadCustomWallpaper = async (file: File) => {
    try {
      const url = URL.createObjectURL(file);
      const isVideo = file.type.startsWith('video/') || file.name.endsWith('.mp4') || file.name.endsWith('.webm');
      
      const newWallpaper: WallpaperItem = {
        id: `custom-wp-${Date.now()}`,
        name: file.name.replace(/\.[^/.]+$/, ''),
        filename: file.name,
        type: isVideo ? 'video' : 'static',
        videoUrl: isVideo ? url : undefined,
        customUrl: !isVideo ? url : undefined,
        themeColor: '#06b6d4',
        gradient: 'from-cyan-950/90 via-slate-900/90 to-[#05070c]'
      };

      wallpaperManager.addUploadedWallpaper(newWallpaper);
      setWallpaperSettings(wallpaperManager.getSettings());
      addToast(`Uploaded ${isVideo ? 'Live Video' : 'Static'} Wallpaper: ${file.name}`, 'success');
    } catch {
      addToast('Failed to upload wallpaper file', 'error');
    }
  };

  const importRomGame = (game: GameItem, rawData?: Uint8Array) => {
    if (rawData) {
      importedRomsCache.current.set(game.id, rawData);
    }
    setGames(prev => [game, ...prev.filter(g => g.id !== game.id)]);
    setSelectedConsole(game.consoleId);
    setFocusedGameIndexState(0);
    addToast(`Imported ${game.title} into ${game.consoleId.toUpperCase()} Library`, 'success');
  };

  // State change observer on core manager
  useEffect(() => {
    consoleCoreManager.onStateChange((state, err) => {
      setRuntimeState(state);
      const errMsg = typeof err === 'string' ? err : err?.reason || null;
      setRuntimeError(errMsg);
      if (state === 'PAUSED') {
        setIsPaused(true);
        setQuickMenuOpen(true);
      } else if (state === 'RUNNING') {
        setIsPaused(false);
        setQuickMenuOpen(false);
      } else if (state === 'ERROR' && errMsg) {
        addToast(errMsg, 'error');
      }
    });
  }, []);

  // Controller Manager Lifecycle & Polling
  useEffect(() => {
    controllerManager.start();

    const unsubMode = controllerManager.onInputModeChange((mode) => {
      setInputMode(mode);
    });

    const unsubState = controllerManager.onStateUpdate((state) => {
      setActiveGamepadState(state);
      const isConn = Boolean(state && state.connected);
      if (isConn !== isControllerConnected) {
        setIsControllerConnected(isConn);
        if (isConn) {
          soundFx.playSelect();
          addToast(`🎮 Controller Connected: ${state?.id || 'Gamepad'}`, 'success');
        }
      }

      // If in active gameplay:
      if (uiMode === 'GAMEPLAY' && state) {
        // Check SELECT + START simultaneous combination for Quick Menu!
        const selectPressed = state.buttons.SELECT.pressed;
        const startPressed = state.buttons.START.pressed;

        if (selectPressed && startPressed) {
          if (!selectStartTimeRef.current) {
            selectStartTimeRef.current = performance.now();
          } else if (performance.now() - selectStartTimeRef.current > 220) {
            // Trigger Quick Menu
            selectStartTimeRef.current = null;
            if (isPaused) {
              resumeGame();
            } else {
              pauseGame();
            }
            return;
          }
        } else {
          selectStartTimeRef.current = null;
        }

        // Bridge raw physical inputs to emulator core
        consoleCoreManager.setControllerState(0, {
          A: state.buttons.A.pressed,
          B: state.buttons.B.pressed,
          X: state.buttons.X.pressed,
          Y: state.buttons.Y.pressed,
          UP: state.buttons.UP.pressed,
          DOWN: state.buttons.DOWN.pressed,
          LEFT: state.buttons.LEFT.pressed,
          RIGHT: state.buttons.RIGHT.pressed,
          L1: state.buttons.L1.pressed,
          R1: state.buttons.R1.pressed,
          L2: state.buttons.L2.pressed,
          R2: state.buttons.R2.pressed,
          START: state.buttons.START.pressed,
          SELECT: state.buttons.SELECT.pressed,
          HOME: state.buttons.HOME.pressed
        });
      }
    });

    // Navigation (D-Pad & Analog Stick)
    controllerManager.onNavigation((nav) => {
      if (uiMode === 'GAMEPLAY') return;

      if (nav.direction === 'RIGHT') {
        setActiveControllerButton('DPAD_RIGHT');
        setFocusedGameIndex((focusedGameIndex + 1) % (filteredGames.length || 1));
      } else if (nav.direction === 'LEFT') {
        setActiveControllerButton('DPAD_LEFT');
        setFocusedGameIndex((focusedGameIndex - 1 + (filteredGames.length || 1)) % (filteredGames.length || 1));
      } else if (nav.direction === 'UP') {
        setActiveControllerButton('DPAD_UP');
        setActiveSection('for-you');
      } else if (nav.direction === 'DOWN') {
        setActiveControllerButton('DPAD_DOWN');
      }
      setTimeout(() => setActiveControllerButton(null), 150);
    });

    // Button Presses
    controllerManager.onButtonPress((btn) => {
      setActiveControllerButton(`BTN_${btn}`);

      if (uiMode === 'GAMEPLAY') {
        if (btn === 'HOME') {
          soundFx.playSelect();
          if (isPaused) {
            resumeGame();
          } else {
            pauseGame();
          }
        }
        return;
      }

      if (btn === 'B') {
        if (isDetailsModalOpen || isSettingsOpen || isSaveStatesOpen || isScannerOpen || isControllerMapperOpen) {
          soundFx.playBack();
          setIsDetailsModalOpen(false);
          setIsSettingsOpen(false);
          setIsSaveStatesOpen(false);
          setIsScannerOpen(false);
          setIsControllerMapperOpen(false);
        }
      } else if (btn === 'A' || btn === 'START') {
        if (focusedGame && !isDetailsModalOpen && !isSettingsOpen && !isScannerOpen) {
          launchGame(focusedGame);
        }
      } else if (btn === 'SELECT') {
        if (focusedGame) openGameDetails(focusedGame);
      } else if (btn === 'X') {
        if (focusedGame) openGameDetails(focusedGame);
      } else if (btn === 'Y') {
        openScanner();
      } else if (btn === 'L1') {
        const sections: ConsoleOSSection[] = ['for-you', 'library', 'consoles'];
        const idx = sections.indexOf(activeSection);
        setActiveSection(sections[(idx - 1 + sections.length) % sections.length]);
      } else if (btn === 'R1') {
        const sections: ConsoleOSSection[] = ['for-you', 'library', 'consoles'];
        const idx = sections.indexOf(activeSection);
        setActiveSection(sections[(idx + 1) % sections.length]);
      }

      setTimeout(() => setActiveControllerButton(null), 180);
    });

    // 500ms SELECT + START Pause shortcut (Section 19)
    controllerManager.onSelectStartHold(() => {
      if (uiMode === 'GAMEPLAY') {
        soundFx.playSelect();
        if (isPaused) {
          resumeGame();
        } else {
          pauseGame();
        }
      }
    });

    return () => {
      unsubMode();
      unsubState();
      controllerManager.stop();
    };
  }, [uiMode, focusedGameIndex, filteredGames, focusedGame, activeSection, isDetailsModalOpen, isSettingsOpen, isSaveStatesOpen, isScannerOpen, isPaused]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (uiMode === 'GAMEPLAY') {
        if (e.key === 'Escape' || e.key === 'Tab') {
          e.preventDefault();
          soundFx.playSelect();
          if (isPaused) {
            resumeGame();
          } else {
            pauseGame();
          }
        }
        return;
      }

      if (isDetailsModalOpen || isSettingsOpen || isSaveStatesOpen || isScannerOpen || isControllerMapperOpen) {
        if (e.key === 'Escape') {
          e.preventDefault();
          soundFx.playBack();
          setIsDetailsModalOpen(false);
          setIsSettingsOpen(false);
          setIsSaveStatesOpen(false);
          setIsScannerOpen(false);
          setIsControllerMapperOpen(false);
        }
        return;
      }

      switch (e.key) {
        case 'ArrowRight':
          e.preventDefault();
          setActiveControllerButton('DPAD_RIGHT');
          setFocusedGameIndex((focusedGameIndex + 1) % (filteredGames.length || 1));
          break;
        case 'ArrowLeft':
          e.preventDefault();
          setActiveControllerButton('DPAD_LEFT');
          setFocusedGameIndex((focusedGameIndex - 1 + (filteredGames.length || 1)) % (filteredGames.length || 1));
          break;
        case 'Enter':
        case ' ':
          e.preventDefault();
          setActiveControllerButton('BTN_A');
          if (focusedGame) launchGame(focusedGame);
          break;
        case 'x':
        case 'X':
          e.preventDefault();
          setActiveControllerButton('BTN_X');
          if (focusedGame) openGameDetails(focusedGame);
          break;
        case 'y':
        case 'Y':
          e.preventDefault();
          openScanner();
          break;
      }

      setTimeout(() => setActiveControllerButton(null), 180);
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [uiMode, focusedGameIndex, filteredGames, focusedGame, isDetailsModalOpen, isSettingsOpen, isSaveStatesOpen, isScannerOpen, isPaused]);

  // Clock ticker
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeString(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  const toggleFavorite = (gameId: string) => {
    soundFx.playSelect();
    setGames(prev => prev.map(g => g.id === gameId ? { ...g, isFavorite: !g.isFavorite } : g));
    const g = games.find(g => g.id === gameId);
    if (g) {
      addToast(`${g.title} ${!g.isFavorite ? 'added to' : 'removed from'} favorites`, 'info');
    }
  };

  const toggleSoundMute = () => {
    const next = !soundMuted;
    setSoundMuted(next);
    soundFx.setMuted(next);
    addToast(`Audio ${next ? 'Muted' : 'Unmuted'}`, 'info');
  };

  const toggleFullscreen = () => {
    if (typeof document === 'undefined') return;
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  // REAL GAME LAUNCHING & EMULATOR CORE INITIALIZATION
  const launchGame = async (game: GameItem, resume: boolean = false, customBytes?: Uint8Array) => {
    soundFx.playLaunch();
    setActiveRunningGame(game);
    setIsPaused(false);
    setIsDetailsModalOpen(false);
    setUIModeState('GAMEPLAY');

    // Request full screen where supported
    if (typeof document !== 'undefined' && !document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    }

    const romBytes = customBytes || importedRomsCache.current.get(game.id);

    try {
      const success = await consoleCoreManager.launchGame(game.consoleId, romBytes, game.title);
      if (!success) {
        const err = consoleCoreManager.getLastError() || `Unable to start ${game.consoleId.toUpperCase()} core`;
        addToast(err, 'error');
      }
    } catch (err: any) {
      addToast(`Core fault: ${err?.message || 'Emulation error'}`, 'error');
    }
  };

  const pauseGame = () => {
    soundFx.playSelect();
    consoleCoreManager.pause();
    setIsPaused(true);
    setQuickMenuOpen(true);
  };

  const resumeGame = () => {
    soundFx.playSelect();
    consoleCoreManager.resume();
    setIsPaused(false);
    setQuickMenuOpen(false);
  };

  const exitGame = () => {
    soundFx.playBack();
    consoleCoreManager.shutdown();
    setQuickMenuOpen(false);
    setIsPaused(false);
    setActiveRunningGame(null);
    setUIModeState('DESKTOP_CONSOLE');
    addToast('Returned to NostalgicVerse OS', 'info');
  };

  const toggleFastForward = () => {
    soundFx.playSelect();
    setIsFastForward(prev => !prev);
  };

  const createSaveState = (gameIdOrSlot?: string | number, slotNumber: number = 1) => {
    const targetGame = activeRunningGame || focusedGame;
    if (!targetGame) return;
    soundFx.playSelect();
    const actualSlot = typeof gameIdOrSlot === 'number' ? gameIdOrSlot : slotNumber;
    const newState: SaveStateItem = {
      id: `save-${targetGame.id}-${Date.now()}`,
      gameId: targetGame.id,
      slotNumber: actualSlot,
      name: `Slot ${actualSlot} — Snapshot State`,
      timestamp: 'Just now',
      playtime: `${Math.floor(targetGame.playtimeMinutes / 60)}h ${targetGame.playtimeMinutes % 60}m`,
      gameLocation: 'Active Gameplay Arena',
      screenshotGradient: targetGame.coverGradient
    };
    setSaveStates(prev => [newState, ...prev]);
    addToast(`Snapshot saved to Slot ${actualSlot}`, 'success');
  };

  const loadSaveState = (stateOrId: SaveStateItem | string) => {
    soundFx.playSelect();
    const state = typeof stateOrId === 'string' ? saveStates.find(s => s.id === stateOrId) : stateOrId;
    if (state) {
      addToast(`Restored snapshot Slot ${state.slotNumber}`, 'success');
      if (isPaused) {
        resumeGame();
      }
    }
  };

  const deleteSaveState = (id: string) => {
    soundFx.playBack();
    setSaveStates(prev => prev.filter(s => s.id !== id));
  };

  const captureScreenshot = () => {
    const targetGame = activeRunningGame || focusedGame;
    if (!targetGame) return;
    soundFx.playSelect();
    const newMedia: MediaCaptureItem = {
      id: `media-snap-${Date.now()}`,
      gameId: targetGame.id,
      gameTitle: targetGame.title,
      consoleId: targetGame.consoleId,
      type: 'screenshot',
      timestamp: 'Just now',
      fileSize: '3.6 MB',
      previewGradient: targetGame.coverGradient
    };
    setMediaItems(prev => [newMedia, ...prev]);
    addToast('Screenshot captured', 'success');
  };

  const toggleRecording = () => {
    soundFx.playSelect();
    setIsRecording(prev => !prev);
    addToast(`Recording ${!isRecording ? 'Started' : 'Saved'}`, 'info');
  };

  const optimizeRuntime = () => {
    soundFx.playSelect();
    setGraphicsSettings(prev => ({ ...prev, internalResolution: '2x', framePacing: 'smooth' }));
    setPerformanceConfig(prev => ({ ...prev, profile: 'performance', dynamicResolution: true }));
    addToast('System performance optimized for hardware', 'success');
  };

  const openGameDetails = (game: GameItem) => {
    soundFx.playSelect();
    setSelectedGameForDetails(game);
    setIsDetailsModalOpen(true);
  };

  const closeGameDetails = () => {
    soundFx.playBack();
    setIsDetailsModalOpen(false);
  };

  const openSettings = () => {
    soundFx.playSelect();
    setIsSettingsOpen(true);
  };

  const closeSettings = () => {
    soundFx.playBack();
    setIsSettingsOpen(false);
  };

  const openSaveStates = () => {
    soundFx.playSelect();
    setIsSaveStatesOpen(true);
  };

  const closeSaveStates = () => {
    soundFx.playBack();
    setIsSaveStatesOpen(false);
  };

  const openScanner = () => {
    soundFx.playSelect();
    setIsScannerOpen(true);
  };

  const closeScanner = () => {
    soundFx.playBack();
    setIsScannerOpen(false);
  };

  const openControllerMapper = () => {
    soundFx.playSelect();
    setIsControllerMapperOpen(true);
  };

  const closeControllerMapper = () => {
    soundFx.playBack();
    setIsControllerMapperOpen(false);
  };

  return (
    <ConsoleOSContext.Provider
      value={{
        uiMode,
        setUIMode,
        activeSection,
        setActiveSection,
        inputMode,
        games,
        filteredGames,
        focusedGameIndex,
        setFocusedGameIndex,
        focusedGame,
        activeRunningGame,
        selectedGameForDetails,
        setSelectedGameForDetails,
        selectedConsole,
        setSelectedConsole,
        searchQuery,
        setSearchQuery,
        toggleFavorite,
        importRomGame,
        isDetailsModalOpen,
        openGameDetails,
        closeGameDetails,
        isSettingsOpen,
        openSettings,
        closeSettings,
        isSaveStatesOpen,
        openSaveStates,
        closeSaveStates,
        isScannerOpen,
        openScanner,
        closeScanner,
        isControllerMapperOpen,
        openControllerMapper,
        closeControllerMapper,
        quickMenuOpen,
        setQuickMenuOpen,
        controllers,
        activeGamepadState,
        isControllerConnected,
        setIsControllerConnected,
        activeControllerButton,
        soundMuted,
        toggleSoundMute,
        isFullscreen,
        toggleFullscreen,
        timeString,
        batteryLevel,
        isMuted: soundMuted,
        setIsMuted: (m: boolean) => {
          setSoundMuted(m);
          soundFx.setMuted(m);
        },
        soundVolume,
        setSoundVolume,
        accentColor,
        setAccentColor,
        activeWallpaper,
        wallpaperSettings,
        updateWallpaperSettings,
        uploadCustomWallpaper,
        runtimeState,
        runtimeError,
        isPaused,
        setIsPaused,
        isFastForward,
        setIsFastForward,
        toggleFastForward,
        isRewind,
        setIsRewind,
        isRecording,
        toggleRecording,
        launchGame,
        pauseGame,
        resumeGame,
        exitGame,
        saveStates,
        createSaveState,
        loadSaveState,
        deleteSaveState,
        mediaItems,
        captureScreenshot,
        graphicsSettings,
        setGraphicsSettings,
        audioSettings,
        setAudioSettings,
        performanceConfig,
        setPerformanceConfig,
        touchLayout,
        optimizeRuntime,
        toasts,
        addToast,
        removeToast
      }}
    >
      {children}
    </ConsoleOSContext.Provider>
  );
};

export const useConsoleOS = () => {
  const context = useContext(ConsoleOSContext);
  if (!context) {
    throw new Error('useConsoleOS must be used within a ConsoleOSProvider');
  }
  return context;
};
