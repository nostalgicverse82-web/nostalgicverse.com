import React from 'react';
import { ConsoleOSProvider, useConsoleOS } from './context/ConsoleOSContext';
import { AppShell } from './ui/shell/AppShell';
import { GameplayRuntime } from './ui/gameplay/GameplayRuntime';

const ConsoleOSEmulatorRoot: React.FC = () => {
  const { uiMode } = useConsoleOS();

  return (
    <>
      {/* 1. Normal Console OS Launcher Shell (Hidden during gameplay) */}
      <AppShell />

      {/* 2. Isolated Fullscreen Hardware Gameplay Runtime (Visible only during gameplay) */}
      {uiMode === 'GAMEPLAY' && <GameplayRuntime />}
    </>
  );
};

export default function App() {
  return (
    <ConsoleOSProvider>
      <ConsoleOSEmulatorRoot />
    </ConsoleOSProvider>
  );
}
