import React from 'react';
import { useConsoleOS } from '../../context/ConsoleOSContext';
import { Gamepad2, Volume2, VolumeX, Maximize2, Minimize2, Keyboard } from 'lucide-react';
import { detectControllerBrand, getButtonGlyph, getControllerDisplayName } from '../../core/input/controllerBrand';
import { NormalizedButton } from '../../core/input/types';

export const ControllerLegend: React.FC = () => {
  const { 
    activeControllerButton, 
    activeGamepadState,
    isControllerConnected,
    soundMuted, 
    toggleSoundMute,
    isFullscreen,
    toggleFullscreen,
    openGameDetails,
    focusedGame,
    launchGame,
    openScanner,
    openSettings,
    activeSection,
    isDetailsModalOpen,
    isSettingsOpen,
    isSaveStatesOpen,
    isScannerOpen
  } = useConsoleOS();

  const brand = isControllerConnected 
    ? detectControllerBrand(activeGamepadState?.id)
    : 'keyboard';

  const brandTitle = isControllerConnected
    ? getControllerDisplayName(brand, activeGamepadState?.id)
    : 'Keyboard Controls';

  // Determine current contextual hints
  let selectAction = 'Play';
  let backAction = '';
  let showDetails = false;
  let showScan = true;
  let showTabs = true;

  if (isDetailsModalOpen) {
    selectAction = 'Launch';
    backAction = 'Close';
    showDetails = false;
    showScan = false;
    showTabs = false;
  } else if (isSettingsOpen) {
    selectAction = 'Select';
    backAction = 'Close';
    showDetails = false;
    showScan = false;
    showTabs = true;
  } else if (isScannerOpen) {
    selectAction = 'Load ROM';
    backAction = 'Close';
    showDetails = false;
    showScan = false;
    showTabs = false;
  } else if (isSaveStatesOpen) {
    selectAction = 'Restore';
    backAction = 'Close';
    showDetails = false;
    showScan = false;
    showTabs = false;
  } else if (activeSection === 'library') {
    selectAction = 'Play';
    backAction = 'Home';
    showDetails = true;
    showScan = true;
    showTabs = true;
  } else if (activeSection === 'consoles') {
    selectAction = 'Browse';
    backAction = 'Home';
    showDetails = false;
    showScan = false;
    showTabs = true;
  } else {
    // for-you (Carousel)
    selectAction = 'Play Game';
    backAction = '';
    showDetails = Boolean(focusedGame);
    showScan = true;
    showTabs = true;
  }

  const renderBadge = (button: NormalizedButton, labelOverride?: string) => {
    const glyph = getButtonGlyph(brand, button);
    const isPressed = activeControllerButton === `BTN_${button}`;
    return (
      <span 
        className={`px-1.5 py-0.5 min-w-[20px] rounded-md font-mono text-[10px] font-bold text-center border transition-all ${
          isPressed 
            ? 'scale-110 shadow-lg bg-cyan-400 text-black border-cyan-300' 
            : `${glyph.badgeBg} ${glyph.badgeText} ${glyph.badgeBorder}`
        }`}
      >
        {labelOverride || glyph.symbol}
      </span>
    );
  };

  return (
    <footer className="fixed bottom-0 left-0 right-0 z-30 px-6 py-2.5 bg-[#06080d]/90 backdrop-blur-xl border-t border-white/[0.08] flex items-center justify-between text-xs text-slate-300 select-none shadow-[0_-4px_20px_rgba(0,0,0,0.5)]">
      {/* Left: Controller Brand Indicator & Contextual Action Hint Bar */}
      <div className="flex items-center gap-4 sm:gap-6 overflow-x-auto no-scrollbar">
        {/* Device Status */}
        <div className="flex items-center gap-2 pr-3 border-r border-white/10 shrink-0">
          {isControllerConnected ? (
            <Gamepad2 className="w-4 h-4 text-cyan-400 animate-pulse" />
          ) : (
            <Keyboard className="w-4 h-4 text-zinc-400" />
          )}
          <span className="font-mono text-[11px] text-slate-300 font-semibold hidden md:inline">
            {brandTitle}
          </span>
        </div>

        {/* Dynamic Contextual Action Buttons */}
        <div className="flex items-center gap-4 shrink-0">
          {/* Action A / Select */}
          <button 
            onClick={() => {
              if (focusedGame && !isDetailsModalOpen && !isSettingsOpen && !isScannerOpen) {
                launchGame(focusedGame);
              }
            }}
            className="flex items-center gap-1.5 hover:text-white transition-colors"
          >
            {renderBadge('A')}
            <span className="font-semibold text-slate-200">{selectAction}</span>
          </button>

          {/* Action B / Back (when applicable) */}
          {backAction && (
            <div className="flex items-center gap-1.5">
              {renderBadge('B')}
              <span className="font-semibold text-slate-300">{backAction}</span>
            </div>
          )}

          {/* Action X / Details */}
          {showDetails && focusedGame && (
            <button 
              onClick={() => openGameDetails(focusedGame)}
              className="flex items-center gap-1.5 hover:text-white transition-colors"
            >
              {renderBadge('X')}
              <span className="font-semibold text-slate-300">Details</span>
            </button>
          )}

          {/* Action Y / Scan ROMs */}
          {showScan && (
            <button 
              onClick={openScanner}
              className="flex items-center gap-1.5 hover:text-white transition-colors hidden sm:flex"
            >
              {renderBadge('Y')}
              <span className="font-semibold text-slate-300">Scan ROMs</span>
            </button>
          )}

          {/* LB / RB / Tabs */}
          {showTabs && (
            <div className="hidden lg:flex items-center gap-1.5 text-slate-400">
              <div className="flex items-center gap-1">
                {renderBadge('L1')}
                {renderBadge('R1')}
              </div>
              <span className="font-medium text-[11px]">Switch Hub</span>
            </div>
          )}

          {/* Navigation Guide */}
          <div className="hidden xl:flex items-center gap-1.5 text-slate-400 pl-2 border-l border-white/10">
            <span className="px-1.5 py-0.5 rounded bg-white/5 border border-white/10 text-[10px] font-mono text-zinc-300">
              {brand === 'keyboard' ? 'Arrow Keys' : 'D-Pad / Stick'}
            </span>
            <span className="text-[11px]">Navigate</span>
          </div>
        </div>
      </div>

      {/* Right: Sound Mute & Fullscreen Toggles */}
      <div className="flex items-center gap-2.5 shrink-0 pl-3">
        {/* Settings Shortcut Button */}
        <button
          onClick={openSettings}
          className="px-2.5 py-1 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 text-[11px] font-semibold flex items-center gap-1.5 transition-colors hidden sm:flex"
          title="System Settings"
        >
          {renderBadge('START', brand === 'keyboard' ? 'Esc' : undefined)}
          <span className="hidden md:inline">Settings</span>
        </button>

        {/* Audio Mute Toggle */}
        <button
          onClick={toggleSoundMute}
          className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-colors"
          title={soundMuted ? 'Unmute Console Sound FX' : 'Mute Sound FX'}
        >
          {soundMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
        </button>

        {/* Fullscreen Toggle */}
        <button
          onClick={toggleFullscreen}
          className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-colors"
          title="Toggle Fullscreen"
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>
      </div>
    </footer>
  );
};
