import React from 'react';
import { useConsoleOS } from '../../context/ConsoleOSContext';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useConsoleOS();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
      {toasts.map((toast) => {
        let border = 'border-cyan-500/40';
        let bg = 'bg-[#0f172a]/95';
        let Icon = Info;
        let iconColor = 'text-cyan-400';

        if (toast.type === 'success') {
          border = 'border-emerald-500/50';
          iconColor = 'text-emerald-400';
          Icon = CheckCircle2;
        } else if (toast.type === 'warning' || toast.type === 'error') {
          border = 'border-rose-500/50';
          iconColor = 'text-rose-400';
          Icon = AlertCircle;
        }

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto p-3.5 rounded-2xl ${bg} border ${border} text-white shadow-2xl backdrop-blur-xl flex items-center gap-3 transition-all animate-in fade-in slide-in-from-bottom-3 duration-200`}
          >
            <Icon className={`w-5 h-5 shrink-0 ${iconColor}`} />
            <p className="text-xs font-semibold leading-snug flex-1">{toast.message}</p>
            <button
              onClick={() => removeToast(toast.id)}
              className="p-1 rounded-lg text-zinc-400 hover:text-white hover:bg-white/10"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
