import React, { useState } from 'react';
import { useConsoleOS } from '../../context/ConsoleOSContext';
import { 
  X, 
  Gamepad2, 
  RefreshCw, 
  Check, 
  Sliders, 
  Cpu, 
  Radio,
  Zap
} from 'lucide-react';

export const ControllerMapperModal: React.FC = () => {
  const {
    isControllerMapperOpen,
    closeControllerMapper,
    controllers,
    addToast
  } = useConsoleOS();

  const [activeTestButton, setActiveTestButton] = useState<string | null>(null);

  if (!isControllerMapperOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-2xl flex items-center justify-center p-4 sm:p-6">
      <div className="relative w-full max-w-2xl bg-[#0b0e14] border border-white/15 rounded-3xl overflow-hidden shadow-2xl text-white flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Gamepad2 className="w-5 h-5 text-purple-400" />
            <h3 className="font-black text-base uppercase tracking-wider text-white">
              Gamepad & Input Test Bench
            </h3>
          </div>
          <button
            onClick={closeControllerMapper}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Active Gamepads List */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
              Connected Gamepad Devices
            </span>

            {controllers.map((c) => (
              <div
                key={c.id}
                className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400 font-bold text-xs">
                    P{c.playerIndex}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">{c.name}</h4>
                    <p className="text-xs text-zinc-400">
                      Type: {c.type} • Latency: <span className="text-emerald-400 font-mono">1.8ms</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-md bg-emerald-500/20 text-emerald-400 text-xs font-bold flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    Active HID
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Interactive Button Test Bench */}
          <div className="p-5 rounded-2xl bg-black/40 border border-white/10 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
                Live Gamepad Input Visualizer
              </span>
              <span className="text-[11px] text-cyan-400 font-mono">
                Press any button to test response
              </span>
            </div>

            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
              {[
                'DPAD_UP', 'DPAD_DOWN', 'DPAD_LEFT', 'DPAD_RIGHT',
                'BTN_A', 'BTN_B', 'BTN_X', 'BTN_Y',
                'L1', 'R1', 'L2', 'R2',
                'L3', 'R3', 'START', 'SELECT'
              ].map((btn) => (
                <button
                  key={btn}
                  onClick={() => {
                    setActiveTestButton(btn);
                    addToast(`Input Detected: ${btn}`, 'info');
                    setTimeout(() => setActiveTestButton(null), 300);
                  }}
                  className={`p-2.5 rounded-xl border text-[10px] font-mono font-bold transition-all ${
                    activeTestButton === btn
                      ? 'bg-purple-500 text-black border-purple-400 shadow-lg shadow-purple-500/50 scale-105'
                      : 'bg-white/5 text-zinc-300 border-white/10 hover:bg-white/10'
                  }`}
                >
                  {btn}
                </button>
              ))}
            </div>
          </div>

          {/* Deadzone and Calibrate */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
            <div>
              <h4 className="text-xs font-bold text-white uppercase">Analog Stick Deadzone</h4>
              <p className="text-[11px] text-zinc-400">Default: 8% (Anti-drift circular algorithm)</p>
            </div>
            <button
              onClick={() => addToast('Analog Calibration Routine Completed', 'success')}
              className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-bold text-white border border-white/15"
            >
              Auto Calibrate
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
