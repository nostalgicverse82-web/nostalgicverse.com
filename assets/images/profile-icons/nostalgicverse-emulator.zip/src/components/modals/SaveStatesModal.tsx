import React from 'react';
import { useConsoleOS } from '../../context/ConsoleOSContext';
import { 
  X, 
  BookmarkCheck, 
  Play, 
  Trash2, 
  Plus, 
  Clock, 
  HardDrive, 
  Check 
} from 'lucide-react';

export const SaveStatesModal: React.FC = () => {
  const {
    isSaveStatesOpen,
    closeSaveStates,
    saveStates,
    loadSaveState,
    createSaveState,
    deleteSaveState,
    focusedGame,
    addToast
  } = useConsoleOS();

  if (!isSaveStatesOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-2xl flex items-center justify-center p-4 sm:p-6">
      <div className="relative w-full max-w-2xl bg-[#0b0e14] border border-white/15 rounded-3xl overflow-hidden shadow-2xl text-white flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookmarkCheck className="w-5 h-5 text-emerald-400" />
            <h3 className="font-black text-base uppercase tracking-wider text-white">
              Save States Manager
            </h3>
          </div>
          <button
            onClick={closeSaveStates}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
              Snapshots for {focusedGame ? focusedGame.title : 'Active Games'}
            </span>
            {focusedGame && (
              <button
                onClick={() => {
                  createSaveState(focusedGame.id, saveStates.length + 1);
                }}
                className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-500/20"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Snapshot</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {saveStates.map((save) => (
              <div
                key={save.id}
                className="p-3.5 rounded-2xl bg-white/5 border border-white/10 hover:border-white/20 transition-all flex flex-col gap-3 group"
              >
                <div className={`relative aspect-video rounded-xl overflow-hidden bg-gradient-to-br ${save.screenshotGradient} p-3 flex flex-col justify-between`}>
                  <div className="self-start px-2 py-0.5 rounded bg-black/70 backdrop-blur-md text-[10px] font-bold text-emerald-400 border border-emerald-500/40">
                    Slot {save.slotNumber}
                  </div>
                  <div className="self-end text-[10px] font-mono text-zinc-300 bg-black/70 px-1.5 py-0.5 rounded">
                    {save.playtime}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-white truncate max-w-[160px]">
                      {save.name}
                    </h4>
                    <span className="text-[10px] text-zinc-400 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-zinc-500" />
                      {save.timestamp}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        loadSaveState(save);
                        closeSaveStates();
                      }}
                      className="p-2 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/40 text-cyan-300 border border-cyan-500/40"
                      title="Load State"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                    </button>
                    <button
                      onClick={() => {
                        deleteSaveState(save.id);
                        addToast('Save state deleted', 'info');
                      }}
                      className="p-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30"
                      title="Delete State"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
