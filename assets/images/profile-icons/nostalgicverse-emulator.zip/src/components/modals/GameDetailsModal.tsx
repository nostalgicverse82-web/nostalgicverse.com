import React from 'react';
import { useConsoleOS } from '../../context/ConsoleOSContext';
import { 
  Play, 
  X, 
  Heart, 
  Clock, 
  ShieldCheck, 
  Cpu, 
  Sliders, 
  Folder, 
  Sparkles, 
  FileCode, 
  BookmarkCheck, 
  Share2, 
  Trash2,
  Maximize2
} from 'lucide-react';

export const GameDetailsModal: React.FC = () => {
  const {
    isDetailsModalOpen,
    selectedGameForDetails,
    closeGameDetails,
    launchGame,
    toggleFavorite,
    openSaveStates,
    openSettings,
    addToast
  } = useConsoleOS();

  if (!isDetailsModalOpen || !selectedGameForDetails) return null;

  const game = selectedGameForDetails;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-2xl flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-[#0b0e14] border border-white/15 rounded-3xl overflow-hidden shadow-2xl text-white flex flex-col my-auto">
        {/* Hero Banner */}
        <div className={`relative h-64 sm:h-72 w-full overflow-hidden bg-gradient-to-tr ${game.bannerGradient}`}>
          <div className="absolute inset-0 bg-gradient-to-t from-[#0b0e14] via-[#0b0e14]/60 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0b0e14]/90 via-transparent to-transparent" />

          {/* Close Button */}
          <button
            onClick={closeGameDetails}
            className="absolute top-4 right-4 p-2.5 rounded-full bg-black/60 hover:bg-white/20 text-white border border-white/20 backdrop-blur-md transition-all active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Floating Console Tag & Badges */}
          <div className="absolute top-4 left-6 flex items-center gap-2">
            <span className="px-3 py-1 rounded-lg bg-cyan-500/30 text-cyan-300 border border-cyan-500/50 text-xs font-black uppercase tracking-wider backdrop-blur-md">
              {game.consoleId.toUpperCase()}
            </span>
            <span className="px-3 py-1 rounded-lg bg-white/10 text-white border border-white/15 text-xs font-mono backdrop-blur-md">
              {game.region}
            </span>
          </div>

          {/* Title & Metadata */}
          <div className="absolute bottom-4 left-6 right-6">
            <h2 className="text-2xl sm:text-4xl font-black text-white drop-shadow-lg tracking-tight">
              {game.title}
            </h2>
            <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-zinc-300">
              <span className="font-semibold text-cyan-400">{game.publisher} ({game.releaseYear})</span>
              <span>•</span>
              <span>{game.genre}</span>
              <span>•</span>
              <span className="text-emerald-400 font-bold">★ {game.targetFps} FPS Target</span>
            </div>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 flex flex-col gap-6">
          {/* Main Action Bar */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                closeGameDetails();
                launchGame(game);
              }}
              className="flex-1 py-3.5 px-6 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl shadow-cyan-500/30 active:scale-95 transition-all"
            >
              <Play className="w-5 h-5 fill-current" />
              Launch Emulator
            </button>

            <button
              onClick={() => toggleFavorite(game.id)}
              className={`p-3.5 rounded-2xl border active:scale-95 transition-all ${
                game.isFavorite
                  ? 'bg-pink-500/20 text-pink-400 border-pink-500/50'
                  : 'bg-white/5 text-zinc-300 border-white/15 hover:text-white hover:bg-white/10'
              }`}
              title="Favorite"
            >
              <Heart className={`w-5 h-5 ${game.isFavorite ? 'fill-current' : ''}`} />
            </button>

            <button
              onClick={() => {
                closeGameDetails();
                openSaveStates();
              }}
              className="p-3.5 rounded-2xl bg-white/5 hover:bg-white/10 text-white border border-white/15 active:scale-95 transition-all"
              title="Manage Save States"
            >
              <BookmarkCheck className="w-5 h-5 text-emerald-400" />
            </button>
          </div>

          {/* Description */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-1">Overview</h4>
            <p className="text-sm text-zinc-300 leading-relaxed">
              {game.description}
            </p>
          </div>

          {/* Technical Specifications Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex flex-col">
              <span className="text-[10px] uppercase font-bold text-zinc-400">Developer</span>
              <span className="text-xs font-bold text-cyan-300 mt-1 truncate">{game.developer}</span>
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex flex-col">
              <span className="text-[10px] uppercase font-bold text-zinc-400">Play Time</span>
              <span className="text-xs font-bold text-white mt-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-zinc-400" />
                {Math.floor(game.playtimeMinutes / 60)}h {game.playtimeMinutes % 60}m
              </span>
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex flex-col">
              <span className="text-[10px] uppercase font-bold text-zinc-400">ROM File Size</span>
              <span className="text-xs font-mono font-bold text-white mt-1">{game.fileSize}</span>
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex flex-col">
              <span className="text-[10px] uppercase font-bold text-zinc-400">Format & Tier</span>
              <span className="text-xs font-bold text-emerald-400 mt-1">{game.fileFormat} • {game.compatibilityTier}</span>
            </div>
          </div>

          {/* File Info */}
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-zinc-400 font-mono truncate">
              <Folder className="w-4 h-4 text-zinc-500 shrink-0" />
              <span className="truncate">/storage/roms/{game.consoleId}/{game.id}{game.fileFormat}</span>
            </div>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-bold shrink-0 ml-2">
              Verified CRC32
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
