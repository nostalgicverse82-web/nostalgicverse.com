import React, { useState } from 'react';
import { useConsoleOS } from '../../context/ConsoleOSContext';
import { wallpaperManager } from '../../core/wallpaper/WallpaperManager';
import { NormalizedButton } from '../../core/input/types';
import { 
  X, 
  Sliders, 
  Monitor, 
  Volume2, 
  Gamepad2, 
  Cpu, 
  HardDrive, 
  Palette, 
  ShieldCheck, 
  Zap, 
  Image as ImageIcon,
  Sparkles,
  Check,
  Radio,
  RefreshCw,
  Eye
} from 'lucide-react';

type SettingsTab = 'controllers' | 'wallpapers' | 'graphics' | 'performance' | 'audio' | 'bios' | 'storage' | 'appearance';

export const SettingsModal: React.FC = () => {
  const {
    isSettingsOpen,
    closeSettings,
    graphicsSettings,
    setGraphicsSettings,
    audioSettings,
    setAudioSettings,
    performanceConfig,
    setPerformanceConfig,
    accentColor,
    setAccentColor,
    activeGamepadState,
    isControllerConnected,
    wallpaperSettings,
    updateWallpaperSettings,
    uploadCustomWallpaper,
    addToast
  } = useConsoleOS();

  const [activeTab, setActiveTab] = useState<SettingsTab>('controllers');
  const [selectedWallpaperPreview, setSelectedWallpaperPreview] = useState<string | null>(null);

  if (!isSettingsOpen) return null;

  const wallpapers = wallpaperManager.getWallpapers();

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-2xl flex items-center justify-center p-4 sm:p-6">
      <div className="relative w-full max-w-4xl h-[88vh] bg-[#0b0e14] border border-white/15 rounded-3xl overflow-hidden shadow-2xl text-white flex flex-col md:flex-row">
        {/* Left Settings Navigation Sidebar */}
        <aside className="w-full md:w-64 bg-black/40 border-r border-white/10 p-4 flex flex-col justify-between shrink-0">
          <div>
            <div className="flex items-center gap-2 px-3 py-2 mb-4">
              <Sliders className="w-5 h-5 text-cyan-400" />
              <h3 className="font-black text-sm uppercase tracking-wider text-white">
                Console Settings
              </h3>
            </div>

            <nav className="flex flex-row md:flex-col gap-1 overflow-x-auto no-scrollbar">
              <button
                onClick={() => setActiveTab('controllers')}
                className={`w-full px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-3 transition-all whitespace-nowrap ${
                  activeTab === 'controllers'
                    ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-md shadow-cyan-500/10'
                    : 'text-zinc-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Gamepad2 className="w-4 h-4" />
                <span>Controller Test Center</span>
              </button>

              <button
                onClick={() => setActiveTab('wallpapers')}
                className={`w-full px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-3 transition-all whitespace-nowrap ${
                  activeTab === 'wallpapers'
                    ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-md shadow-cyan-500/10'
                    : 'text-zinc-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <ImageIcon className="w-4 h-4" />
                <span>Wallpapers & Live FX</span>
              </button>

              <button
                onClick={() => setActiveTab('graphics')}
                className={`w-full px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-3 transition-all whitespace-nowrap ${
                  activeTab === 'graphics'
                    ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-md shadow-cyan-500/10'
                    : 'text-zinc-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Monitor className="w-4 h-4" />
                <span>Graphics & Emulation</span>
              </button>

              <button
                onClick={() => setActiveTab('performance')}
                className={`w-full px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-3 transition-all whitespace-nowrap ${
                  activeTab === 'performance'
                    ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-md shadow-cyan-500/10'
                    : 'text-zinc-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Zap className="w-4 h-4" />
                <span>Performance Profiles</span>
              </button>

              <button
                onClick={() => setActiveTab('audio')}
                className={`w-full px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-3 transition-all whitespace-nowrap ${
                  activeTab === 'audio'
                    ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-md shadow-cyan-500/10'
                    : 'text-zinc-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Volume2 className="w-4 h-4" />
                <span>Audio Engine</span>
              </button>

              <button
                onClick={() => setActiveTab('bios')}
                className={`w-full px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-3 transition-all whitespace-nowrap ${
                  activeTab === 'bios'
                    ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-md shadow-cyan-500/10'
                    : 'text-zinc-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                <span>BIOS & Firmwares</span>
              </button>

              <button
                onClick={() => setActiveTab('appearance')}
                className={`w-full px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-3 transition-all whitespace-nowrap ${
                  activeTab === 'appearance'
                    ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-md shadow-cyan-500/10'
                    : 'text-zinc-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Palette className="w-4 h-4" />
                <span>Theme & Accents</span>
              </button>
            </nav>
          </div>

          <div className="hidden md:block p-3 rounded-xl bg-white/5 border border-white/10 text-[11px] text-zinc-400">
            <span className="font-bold text-white block">NostalgicVerse OS v2.5</span>
            Web Gamepad & Real Hardware Core
          </div>
        </aside>

        {/* Right Settings Content Area */}
        <main className="flex-1 flex flex-col h-full overflow-hidden">
          {/* Header */}
          <div className="p-5 border-b border-white/10 flex items-center justify-between shrink-0">
            <h2 className="text-base sm:text-lg font-black tracking-tight text-white uppercase">
              {activeTab === 'controllers' && '🎮 Real Controller Test Center & Mapping'}
              {activeTab === 'wallpapers' && '🖼️ Wallpaper Manager & Live Particles'}
              {activeTab === 'graphics' && 'Graphics, Display & Video Shaders'}
              {activeTab === 'performance' && 'Performance & Frame Pacing'}
              {activeTab === 'audio' && 'Audio Engine & Latency'}
              {activeTab === 'bios' && 'Verified BIOS Images'}
              {activeTab === 'appearance' && 'Console Theme & Accent Colors'}
            </h2>

            <button
              onClick={closeSettings}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white active:scale-95 transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Scrollable Tab Body */}
          <div className="flex-1 p-6 overflow-y-auto space-y-6">
            {/* 1. Controller Test Center */}
            {activeTab === 'controllers' && (
              <div className="space-y-6">
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full ${isControllerConnected ? 'bg-emerald-400 animate-pulse' : 'bg-zinc-600'}`} />
                    <div>
                      <h4 className="text-sm font-bold text-white">
                        {isControllerConnected ? activeGamepadState?.id || 'Gamepad Connected' : 'No Controller Detected'}
                      </h4>
                      <p className="text-xs text-zinc-400">
                        {isControllerConnected ? 'Standard Web Gamepad API mapping verified' : 'Connect a Bluetooth or USB gamepad (DualSense, Xbox, Switch Pro, 8BitDo)'}
                      </p>
                    </div>
                  </div>
                  <span className="px-3 py-1 rounded-lg bg-cyan-500/20 text-cyan-400 text-xs font-mono font-bold">
                    {isControllerConnected ? '1.8ms HID Polling' : 'Idle'}
                  </span>
                </div>

                {/* Visual Gamepad Test Stage */}
                <div className="p-6 rounded-3xl bg-black/60 border border-white/10 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
                      Live Input Button & Analog Response
                    </span>
                    <span className="text-[11px] text-cyan-400 font-mono">
                      Press physical buttons on your controller
                    </span>
                  </div>

                  {/* Face buttons & D-Pad visualizer */}
                  <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                    {[
                      { key: 'A', label: 'A / ✕' },
                      { key: 'B', label: 'B / ●' },
                      { key: 'X', label: 'X / ■' },
                      { key: 'Y', label: 'Y / ▲' },
                      { key: 'UP', label: 'D-Up' },
                      { key: 'DOWN', label: 'D-Down' },
                      { key: 'LEFT', label: 'D-Left' },
                      { key: 'RIGHT', label: 'D-Right' },
                      { key: 'L1', label: 'L1 / LB' },
                      { key: 'R1', label: 'R1 / RB' },
                      { key: 'L2', label: 'L2 / LT' },
                      { key: 'R2', label: 'R2 / RT' },
                      { key: 'L3', label: 'L3' },
                      { key: 'R3', label: 'R3' },
                      { key: 'START', label: 'Start' },
                      { key: 'SELECT', label: 'Select' }
                    ].map((btn) => {
                      const buttonKey = btn.key as NormalizedButton;
                      const isPressed = activeGamepadState?.buttons[buttonKey]?.pressed;
                      return (
                        <div
                          key={btn.key}
                          className={`p-3 rounded-xl border text-center transition-all flex flex-col items-center justify-center gap-1 ${
                            isPressed
                              ? 'bg-cyan-500 text-black border-cyan-300 font-black shadow-[0_0_20px_rgba(6,182,212,0.8)] scale-105'
                              : 'bg-white/5 text-zinc-300 border-white/10 font-bold'
                          }`}
                        >
                          <span className="text-[10px] font-mono">{btn.label}</span>
                          <span className={`w-2 h-2 rounded-full ${isPressed ? 'bg-black' : 'bg-white/20'}`} />
                        </div>
                      );
                    })}
                  </div>

                  {/* Analog Sticks 2D Coordinate Crosshair */}
                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-col items-center gap-2">
                      <span className="text-xs font-bold text-zinc-300">Left Analog Stick</span>
                      <div className="relative w-24 h-24 rounded-full bg-black/70 border border-white/20 flex items-center justify-center">
                        <div 
                          className="w-5 h-5 rounded-full bg-cyan-400 shadow-md shadow-cyan-500/50 transition-transform duration-75"
                          style={{
                            transform: `translate(${((activeGamepadState?.axes.leftStickX || 0) * 35).toFixed(1)}px, ${((activeGamepadState?.axes.leftStickY || 0) * 35).toFixed(1)}px)`
                          }}
                        />
                      </div>
                      <span className="font-mono text-[10px] text-zinc-400">
                        X: {(activeGamepadState?.axes.leftStickX || 0).toFixed(2)} Y: {(activeGamepadState?.axes.leftStickY || 0).toFixed(2)}
                      </span>
                    </div>

                    <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-col items-center gap-2">
                      <span className="text-xs font-bold text-zinc-300">Right Analog Stick</span>
                      <div className="relative w-24 h-24 rounded-full bg-black/70 border border-white/20 flex items-center justify-center">
                        <div 
                          className="w-5 h-5 rounded-full bg-purple-400 shadow-md shadow-purple-500/50 transition-transform duration-75"
                          style={{
                            transform: `translate(${((activeGamepadState?.axes.rightStickX || 0) * 35).toFixed(1)}px, ${((activeGamepadState?.axes.rightStickY || 0) * 35).toFixed(1)}px)`
                          }}
                        />
                      </div>
                      <span className="font-mono text-[10px] text-zinc-400">
                        X: {(activeGamepadState?.axes.rightStickX || 0).toFixed(2)} Y: {(activeGamepadState?.axes.rightStickY || 0).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 2. Wallpapers & Live FX Tab */}
            {activeTab === 'wallpapers' && (
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
                    Wallpaper Behavior Mode
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {[
                      { id: 'game-specific', label: 'Game Dynamic', desc: 'Active game artwork takes over background' },
                      { id: 'live', label: 'Live Particle', desc: 'Real-time 3D synthwave, aurora & starfield' },
                      { id: 'video', label: 'Live Video', desc: 'Seamless looped HTML5 cinematic video' },
                      { id: 'global', label: 'Fixed Static', desc: 'Selected custom artwork for all views' }
                    ].map((m) => (
                      <button
                        key={m.id}
                        onClick={() => updateWallpaperSettings({ mode: m.id as any })}
                        className={`p-3.5 rounded-2xl border text-left transition-all flex flex-col justify-between gap-1 ${
                          wallpaperSettings.mode === m.id
                            ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/60 shadow-lg shadow-cyan-500/20'
                            : 'bg-white/5 text-zinc-300 border-white/10 hover:bg-white/10'
                        }`}
                      >
                        <span className="text-xs font-bold text-white">{m.label}</span>
                        <span className="text-[10px] text-zinc-400 leading-tight">{m.desc}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {wallpaperSettings.mode === 'video' && (
                  <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-bold text-white">Live Video Audio</h4>
                      <p className="text-xs text-zinc-400">Enable or mute audio tracks for background video loops</p>
                    </div>
                    <button
                      onClick={() => updateWallpaperSettings({ videoMuted: !wallpaperSettings.videoMuted })}
                      className={`px-3 py-1 rounded-lg text-xs font-bold ${
                        wallpaperSettings.videoMuted ? 'bg-white/10 text-zinc-400' : 'bg-cyan-500 text-black'
                      }`}
                    >
                      {wallpaperSettings.videoMuted ? 'Muted' : 'Unmuted'}
                    </button>
                  </div>
                )}

                {/* Live Wallpaper Performance Config */}
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-white">Live Wallpaper FPS Pacing</h4>
                    <p className="text-xs text-zinc-400">Automatically suspended during active gameplay to free 100% GPU/CPU</p>
                  </div>
                  <div className="flex items-center gap-2">
                    {[30, 60, 'auto'].map((fpsVal) => (
                      <button
                        key={fpsVal}
                        onClick={() => updateWallpaperSettings({ liveWallpaperFps: fpsVal as any })}
                        className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all ${
                          wallpaperSettings.liveWallpaperFps === fpsVal
                            ? 'bg-cyan-500 text-black border-cyan-400 shadow-md'
                            : 'bg-black/40 text-zinc-400 border-white/10 hover:text-white'
                        }`}
                      >
                        {fpsVal === 'auto' ? 'Auto' : `${fpsVal} FPS`}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Upload Custom Wallpaper */}
                <div className="p-4 rounded-2xl bg-white/5 border border-dashed border-white/20 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                      <ImageIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Upload Custom Wallpaper / Live Video</h4>
                      <p className="text-[11px] text-zinc-400">Supports PNG, JPG, WebP images and MP4, WebM animated videos</p>
                    </div>
                  </div>

                  <label className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-black text-xs uppercase tracking-wider cursor-pointer active:scale-95 transition-all shadow-md shadow-cyan-500/20 shrink-0">
                    <span>Browse Files</span>
                    <input
                      type="file"
                      accept="image/*,video/mp4,video/webm"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          uploadCustomWallpaper(file);
                        }
                      }}
                    />
                  </label>
                </div>

                {/* Wallpaper Gallery (/wallpaper/ directory items) */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
                      Installed Wallpapers (/wallpaper/ catalog)
                    </span>
                    <span className="text-[11px] text-cyan-400">
                      {wallpapers.length} Preloaded Themes
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {wallpapers.map((wp) => {
                      const isActive = wallpaperSettings.activeWallpaperId === wp.id;
                      return (
                        <div
                          key={wp.id}
                          onClick={() => updateWallpaperSettings({ activeWallpaperId: wp.id })}
                          className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col gap-2 relative ${
                            isActive
                              ? 'ring-2 ring-cyan-400 border-cyan-500 bg-cyan-500/10'
                              : 'bg-white/5 border-white/10 hover:border-white/20'
                          }`}
                        >
                          <div className={`aspect-video rounded-xl bg-gradient-to-tr ${wp.gradient} p-2 flex flex-col justify-between shadow-inner`}>
                            <span className="self-start px-2 py-0.5 rounded bg-black/70 text-[9px] font-black uppercase text-cyan-300">
                              {wp.type}
                            </span>
                            {isActive && (
                              <span className="self-end p-1 rounded-full bg-cyan-500 text-black shadow">
                                <Check className="w-3 h-3" />
                              </span>
                            )}
                          </div>
                          <div>
                            <h5 className="text-xs font-bold text-white truncate">{wp.name}</h5>
                            <span className="text-[10px] text-zinc-400 font-mono">{wp.filename}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* 3. Graphics & Video Shaders */}
            {activeTab === 'graphics' && (
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
                    Video Scaling Mode (Section 6)
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {[
                      { id: 'fit', label: 'Fit Screen (Aspect Correct)', desc: '4:3 for NES/SNES, 10:9 for GB, 3:2 for GBA' },
                      { id: 'integer-scale', label: 'Integer Scaling', desc: 'Pixel-perfect integer multiples' },
                      { id: 'original', label: 'Original 1x Native', desc: 'Native hardware framebuffer' },
                      { id: 'fill', label: 'Fill Screen', desc: 'Covers display area' },
                      { id: 'stretch', label: 'Stretch to Window', desc: 'Fills viewport without borders' }
                    ].map((m) => (
                      <div
                        key={m.id}
                        className="p-3 rounded-xl border border-white/10 bg-white/5 flex flex-col justify-between"
                      >
                        <div className="text-xs font-bold text-white">{m.label}</div>
                        <div className="text-[10px] text-zinc-400">{m.desc}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* NES Color Mode */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
                    NES Hardware Color Accuracy (Section 4)
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {[
                      { id: 'accurate', name: 'Accurate / Reference', desc: 'Smooth / FirebrandX 2C02 calibrated sRGB' },
                      { id: 'ntsc', name: 'NTSC-Style CRT', desc: 'Warm consumer television decoding' },
                      { id: 'composite', name: 'Sony CXA2025AS', desc: 'Trinitron CRT matrix standard' },
                      { id: 'rgb', name: 'PlayChoice-10 (2C03)', desc: 'Arcade direct RGB PPU output' },
                      { id: 'raw', name: 'Raw / Waveform', desc: 'Mathematical phase-angle levels' },
                      { id: 'core-native', name: 'Core Native', desc: 'Baseline jsnes palette' }
                    ].map((pal) => (
                      <div
                        key={pal.id}
                        className="p-3 rounded-xl border border-white/10 bg-white/5 flex flex-col justify-between"
                      >
                        <div className="text-xs font-bold text-cyan-300">{pal.name}</div>
                        <div className="text-[10px] text-zinc-400">{pal.desc}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-white">Phosphor CRT Scanlines</h4>
                    <p className="text-xs text-zinc-400">Authentic cathode-ray tube phosphor beam lines</p>
                  </div>
                  <button
                    onClick={() => {
                      setGraphicsSettings({ ...graphicsSettings, crtFilter: !graphicsSettings.crtFilter });
                    }}
                    className={`w-12 h-6 rounded-full transition-all p-0.5 ${
                      graphicsSettings.crtFilter ? 'bg-cyan-500' : 'bg-white/20'
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-full bg-white transition-transform ${graphicsSettings.crtFilter ? 'translate-x-6' : 'translate-x-0'}`} />
                  </button>
                </div>
              </div>
            )}

            {/* 4. Performance Tab */}
            {activeTab === 'performance' && (
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
                    Emulation Frame Pacing (Section 10 & 11)
                  </label>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { id: 'balanced', label: 'Balanced (Default)', desc: 'Smooth 60 FPS presentation' },
                      { id: 'accurate', label: 'Accurate (60Hz)', desc: 'Cycle-synchronized pacing' },
                      { id: 'low-latency', label: 'Low Latency', desc: 'Minimal input-to-display delay' }
                    ].map((p) => (
                      <div
                        key={p.id}
                        className="p-3.5 rounded-2xl border border-white/10 bg-white/5 flex flex-col justify-between gap-1"
                      >
                        <span className="text-xs font-bold text-cyan-400">{p.label}</span>
                        <span className="text-[10px] text-zinc-400">{p.desc}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
                    FPS Counter Telemetry (Section 9)
                  </label>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { id: 'off', label: 'Off', desc: '100% immersive clean screen' },
                      { id: 'simple', label: 'Simple (60.0)', desc: 'Discrete live FPS badge' },
                      { id: 'detailed', label: 'Detailed Telemetry', desc: 'FPS, Frame Time, CPU/GPU, Audio & Graph' }
                    ].map((m) => (
                      <div
                        key={m.id}
                        className="p-3.5 rounded-2xl border border-white/10 bg-white/5 flex flex-col justify-between gap-1"
                      >
                        <span className="text-xs font-bold text-white">{m.label}</span>
                        <span className="text-[10px] text-zinc-400">{m.desc}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-white">Pause When Tab Hidden</h4>
                    <p className="text-xs text-zinc-400">Suspends CPU execution when browser window loses focus</p>
                  </div>
                  <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-400 text-xs font-bold">
                    Active
                  </span>
                </div>
              </div>
            )}

            {/* 5. Audio Tab */}
            {activeTab === 'audio' && (
              <div className="space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-zinc-400 uppercase">
                    <span>Master Audio Output Volume</span>
                    <span className="text-white font-mono">{audioSettings.volume}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={audioSettings.volume}
                    onChange={(e) => setAudioSettings({ ...audioSettings, volume: Number(e.target.value) })}
                    className="w-full accent-cyan-500"
                  />
                </div>
              </div>
            )}

            {/* 6. BIOS Tab */}
            {activeTab === 'bios' && (
              <div className="space-y-3">
                <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-white">NES FamiCore System (Internal)</span>
                    <p className="text-[10px] text-zinc-400 font-mono">No external BIOS required (Built-in HLE Core)</p>
                  </div>
                  <span className="px-2.5 py-1 rounded-md bg-emerald-500/20 text-emerald-400 text-xs font-bold">
                    Ready
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-white">SNES Super16 DSP Firmware</span>
                    <p className="text-[10px] text-zinc-400 font-mono">Internal DSP1/DSP2 Emulated</p>
                  </div>
                  <span className="px-2.5 py-1 rounded-md bg-emerald-500/20 text-emerald-400 text-xs font-bold">
                    Ready
                  </span>
                </div>
              </div>
            )}

            {/* 7. Appearance */}
            {activeTab === 'appearance' && (
              <div className="space-y-4">
                <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider block">
                  Console OS Accent Glow
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
                  {[
                    { id: 'cyan', color: '#06b6d4', name: 'Electric Cyan' },
                    { id: 'purple', color: '#a855f7', name: 'Neon Purple' },
                    { id: 'emerald', color: '#10b981', name: 'Matrix Emerald' },
                    { id: 'pink', color: '#ec4899', name: 'Cyber Pink' },
                    { id: 'amber', color: '#f59e0b', name: 'Retro Amber' },
                    { id: 'blue', color: '#3b82f6', name: 'Cobalt Blue' },
                  ].map((c) => (
                    <button
                      key={c.id}
                      onClick={() => {
                        setAccentColor(c.id);
                        addToast(`Accent: ${c.name}`, 'info');
                      }}
                      className={`p-3 rounded-xl border flex flex-col items-center gap-2 transition-all ${
                        accentColor === c.id
                          ? 'border-white bg-white/10 shadow-lg scale-105'
                          : 'border-white/10 bg-white/5 hover:bg-white/10'
                      }`}
                    >
                      <div className="w-6 h-6 rounded-full" style={{ backgroundColor: c.color }} />
                      <span className="text-[10px] font-bold text-zinc-300">{c.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};
