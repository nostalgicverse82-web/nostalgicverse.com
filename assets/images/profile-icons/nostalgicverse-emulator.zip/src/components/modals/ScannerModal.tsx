import React, { useState, useRef } from 'react';
import { useConsoleOS } from '../../context/ConsoleOSContext';
import { romScanner } from '../../core/rom/RomScanner';
import { 
  X, 
  FolderSearch, 
  UploadCloud, 
  Play,
  FolderOpen
} from 'lucide-react';
import { 
  createSampleNesRom, 
  createSampleSnesRom,
  createSampleGbRom,
  createSampleGbcRom,
  createSampleGbaRom
} from '../../core/rom/sampleRoms';

export const ScannerModal: React.FC = () => {
  const {
    isScannerOpen,
    closeScanner,
    importRomGame,
    launchGame,
    addToast
  } = useConsoleOS();

  const [isProcessing, setIsProcessing] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const folderInputRef = useRef<HTMLInputElement | null>(null);

  if (!isScannerOpen) return null;

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setIsProcessing(true);

    try {
      let importedCount = 0;
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const buffer = await file.arrayBuffer();
        const parsed = await romScanner.parseRomAsync(file.name, buffer);

        if (parsed.valid) {
          const gameItem = romScanner.createGameItemFromScanned(parsed);
          importRomGame(gameItem, parsed.data);
          importedCount++;
        }
      }

      if (importedCount > 0) {
        addToast(`Successfully imported ${importedCount} authentic ROM(s)`, 'success');
        closeScanner();
      } else {
        addToast('No supported ROMs found. Ensure files have valid iNES or SNES headers.', 'warning');
      }
    } catch (err: any) {
      addToast(`Error importing ROMs: ${err?.message || 'Invalid format'}`, 'error');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleLoadDemoNes = () => {
    const nesBytes = createSampleNesRom();
    const scanned = romScanner.parseRom('NostalgicVerse_NES_Hardware_Test.nes', nesBytes.buffer as ArrayBuffer);
    const game = romScanner.createGameItemFromScanned(scanned);
    importRomGame(game, nesBytes);
    closeScanner();
    launchGame(game, false, nesBytes);
  };

  const handleLoadDemoSnes = () => {
    const snesBytes = createSampleSnesRom();
    const scanned = romScanner.parseRom('NostalgicVerse_SNES_Hardware_Test.sfc', snesBytes.buffer as ArrayBuffer);
    const game = romScanner.createGameItemFromScanned(scanned);
    importRomGame(game, snesBytes);
    closeScanner();
    launchGame(game, false, snesBytes);
  };

  const handleLoadDemoGb = () => {
    const gbBytes = createSampleGbRom();
    const scanned = romScanner.parseRom('NostalgicVerse_GB_Hardware_Test.gb', gbBytes.buffer as ArrayBuffer);
    const game = romScanner.createGameItemFromScanned(scanned);
    importRomGame(game, gbBytes);
    closeScanner();
    launchGame(game, false, gbBytes);
  };

  const handleLoadDemoGbc = () => {
    const gbcBytes = createSampleGbcRom();
    const scanned = romScanner.parseRom('NostalgicVerse_GBC_Hardware_Test.gbc', gbcBytes.buffer as ArrayBuffer);
    const game = romScanner.createGameItemFromScanned(scanned);
    importRomGame(game, gbcBytes);
    closeScanner();
    launchGame(game, false, gbcBytes);
  };

  const handleLoadDemoGba = () => {
    const gbaBytes = createSampleGbaRom();
    const scanned = romScanner.parseRom('NostalgicVerse_GBA_Hardware_Test.gba', gbaBytes.buffer as ArrayBuffer);
    const game = romScanner.createGameItemFromScanned(scanned);
    importRomGame(game, gbaBytes);
    closeScanner();
    launchGame(game, false, gbaBytes);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-2xl flex items-center justify-center p-4 sm:p-6">
      <div className="relative w-full max-w-xl bg-[#0b0e14] border border-white/15 rounded-3xl overflow-hidden shadow-2xl text-white flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FolderSearch className="w-5 h-5 text-cyan-400" />
            <h3 className="font-black text-base uppercase tracking-wider text-white">
              Real ROM Scanner & Importer
            </h3>
          </div>
          <button
            onClick={closeScanner}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 overflow-y-auto">
          {/* Drag and Drop Zone */}
          <div
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              handleFiles(e.dataTransfer.files);
            }}
            onClick={() => fileInputRef.current?.click()}
            className={`p-8 rounded-2xl border-2 border-dashed cursor-pointer transition-all flex flex-col items-center justify-center text-center gap-3 ${
              dragOver
                ? 'border-cyan-400 bg-cyan-500/10 scale-[1.01]'
                : 'border-white/20 bg-white/5 hover:bg-white/10 hover:border-white/30'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".nes,.unf,.unif,.sfc,.smc,.swc,.fig,.zip,.gb,.gbc,.gba"
              className="hidden"
              onChange={(e) => handleFiles(e.target.files)}
            />

            <UploadCloud className="w-10 h-10 text-cyan-400" />
            <div>
              <h4 className="text-sm font-bold text-white">
                Drag & drop genuine ROM files or ZIP archives
              </h4>
              <p className="text-xs text-zinc-400 mt-1">
                Supports .NES, .SFC, .SMC, .GB, .GBC, .GBA and .ZIP archives
              </p>
            </div>
            
            <div className="flex gap-2">
              <button 
                type="button"
                onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 text-xs font-bold text-white"
              >
                Select Files
              </button>
              <button
                type="button"
                onClick={(e) => { e.stopPropagation(); folderInputRef.current?.click(); }}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 text-xs font-bold text-white flex items-center gap-1.5"
              >
                <FolderOpen className="w-3.5 h-3.5" />
                <span>Select Folder</span>
              </button>
            </div>

            {/* Hidden directory folder input */}
            <input
              ref={folderInputRef}
              type="file"
              // @ts-expect-error webkitdirectory attribute
              webkitdirectory="true"
              className="hidden"
              onChange={(e) => handleFiles(e.target.files)}
            />
          </div>

          {/* Verification ROM Launchers */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider block">
              Direct Hardware Core Verification
            </span>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              <button
                onClick={handleLoadDemoNes}
                className="p-3 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-left transition-all flex items-center justify-between group"
              >
                <div>
                  <span className="text-xs font-bold text-white block">NES Hardware</span>
                  <span className="text-[10px] text-rose-300">6502 + 2A03 Execution</span>
                </div>
                <Play className="w-3.5 h-3.5 text-rose-400 group-hover:scale-110 transition-transform shrink-0" />
              </button>

              <button
                onClick={handleLoadDemoSnes}
                className="p-3 rounded-xl bg-pink-500/10 hover:bg-pink-500/20 border border-pink-500/30 text-left transition-all flex items-center justify-between group"
              >
                <div>
                  <span className="text-xs font-bold text-white block">SNES Hardware</span>
                  <span className="text-[10px] text-pink-300">Snes9x WASM Core</span>
                </div>
                <Play className="w-3.5 h-3.5 text-pink-400 group-hover:scale-110 transition-transform shrink-0" />
              </button>

              <button
                onClick={handleLoadDemoGb}
                className="p-3 rounded-xl bg-lime-500/10 hover:bg-lime-500/20 border border-lime-500/30 text-left transition-all flex items-center justify-between group"
              >
                <div>
                  <span className="text-xs font-bold text-white block">Game Boy</span>
                  <span className="text-[10px] text-lime-300">WasmBoy Z80 Core</span>
                </div>
                <Play className="w-3.5 h-3.5 text-lime-400 group-hover:scale-110 transition-transform shrink-0" />
              </button>

              <button
                onClick={handleLoadDemoGbc}
                className="p-3 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-left transition-all flex items-center justify-between group"
              >
                <div>
                  <span className="text-xs font-bold text-white block">Game Boy Color</span>
                  <span className="text-[10px] text-amber-300">CGB Color Core</span>
                </div>
                <Play className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform shrink-0" />
              </button>

              <button
                onClick={handleLoadDemoGba}
                className="p-3 rounded-xl bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 text-left transition-all flex items-center justify-between group col-span-2 sm:col-span-1"
              >
                <div>
                  <span className="text-xs font-bold text-white block">GBA Hardware</span>
                  <span className="text-[10px] text-purple-300">ARM7TDMI 32-Bit Core</span>
                </div>
                <Play className="w-3.5 h-3.5 text-purple-400 group-hover:scale-110 transition-transform shrink-0" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
