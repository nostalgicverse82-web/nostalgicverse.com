import React from 'react';
import { GameplayRuntime } from './GameplayRuntime';

export const ImmersiveGameplayView: React.FC = () => {
  return <GameplayRuntime />;
};
