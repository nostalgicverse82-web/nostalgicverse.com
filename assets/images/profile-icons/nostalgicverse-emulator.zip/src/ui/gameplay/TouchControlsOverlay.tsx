import React, { useState, useEffect, useCallback } from 'react';
import { ConsoleId } from '../../types/emulator';
import { consoleCoreManager } from '../../core/emulator/ConsoleCoreManager';
import { Menu, Eye, EyeOff } from 'lucide-react';

interface TouchControlsOverlayProps {
  consoleId: ConsoleId;
  isControllerConnected: boolean;
  onOpenMenu: () => void;
}

export const TouchControlsOverlay: React.FC<TouchControlsOverlayProps> = ({
  consoleId,
  isControllerConnected,
  onOpenMenu
}) => {
  const [opacity, setOpacity] = useState<number>(0.65);
  const [isVisible, setIsVisible] = useState<boolean>(true);
  const [activeButtons, setActiveButtons] = useState<Record<string, boolean>>({});

  // Auto-hide when external controller is connected (Section 13)
  const shouldRender = isVisible && !isControllerConnected;

  // Haptic feedback trigger (Section 14)
  const triggerHaptic = useCallback(() => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(15);
      } catch {}
    }
  }, []);

  const handleButtonDown = useCallback((button: string) => {
    triggerHaptic();
    setActiveButtons(prev => ({ ...prev, [button]: true }));

    const core = consoleCoreManager.getActiveCore();
    if (core && core.setButtonState) {
      core.setButtonState(0, button, true);
    }

    // Check SELECT + START combo to trigger Quick Menu (Section 14 & 21)
    if (
      (button === 'START' && activeButtons['SELECT']) ||
      (button === 'SELECT' && activeButtons['START'])
    ) {
      onOpenMenu();
    }
  }, [activeButtons, onOpenMenu, triggerHaptic]);

  const handleButtonUp = useCallback((button: string) => {
    setActiveButtons(prev => ({ ...prev, [button]: false }));

    const core = consoleCoreManager.getActiveCore();
    if (core && core.setButtonState) {
      core.setButtonState(0, button, false);
    }
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      const core = consoleCoreManager.getActiveCore();
      if (core && core.setButtonState) {
        const setBtn = core.setButtonState.bind(core);
        ['UP', 'DOWN', 'LEFT', 'RIGHT', 'A', 'B', 'X', 'Y', 'L1', 'R1', 'START', 'SELECT'].forEach(btn => {
          setBtn(0, btn, false);
        });
      }
    };
  }, []);

  if (!shouldRender) {
    return null;
  }

  const isSNES = consoleId === 'snes';

  return (
    <div 
      className="absolute inset-0 pointer-events-none z-30 select-none overflow-hidden touch-none"
      style={{ opacity }}
    >
      {/* Top Subtle Control Bar */}
      <div className="absolute top-3 left-4 right-4 flex items-center justify-between pointer-events-auto">
        <button
          onClick={onOpenMenu}
          className="p-2.5 rounded-2xl bg-black/40 backdrop-blur-md border border-white/20 text-white/80 active:scale-90 active:bg-cyan-500 active:text-black transition-all shadow-lg flex items-center gap-1.5 text-xs font-bold"
          title="Pause Menu (ESC)"
        >
          <Menu className="w-4 h-4" />
          <span className="text-[10px] uppercase font-mono tracking-wider">Menu</span>
        </button>

        <div className="flex items-center gap-1.5 bg-black/40 backdrop-blur-md border border-white/10 rounded-2xl p-1">
          <button
            onClick={() => setOpacity(prev => (prev >= 0.8 ? 0.35 : prev + 0.25))}
            className="p-1.5 rounded-xl text-white/70 hover:text-white transition-colors"
            title="Adjust Touch Opacity"
          >
            <span className="text-[10px] font-mono font-bold px-1">{Math.round(opacity * 100)}%</span>
          </button>
          <button
            onClick={() => setIsVisible(false)}
            className="p-1.5 rounded-xl text-white/70 hover:text-white transition-colors"
            title="Hide Touch Controls"
          >
            <EyeOff className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* SNES Top Shoulder Triggers L and R */}
      {isSNES && (
        <div className="absolute top-14 left-4 right-4 flex justify-between pointer-events-auto">
          <button
            onTouchStart={(e) => { e.preventDefault(); handleButtonDown('L1'); }}
            onTouchEnd={(e) => { e.preventDefault(); handleButtonUp('L1'); }}
            onMouseDown={() => handleButtonDown('L1')}
            onMouseUp={() => handleButtonUp('L1')}
            className={`w-24 h-11 rounded-2xl border flex items-center justify-center font-black text-sm tracking-wider backdrop-blur-md transition-all ${
              activeButtons['L1']
                ? 'bg-cyan-400 text-black border-cyan-300 scale-95 shadow-[0_0_15px_rgba(34,211,238,0.5)]'
                : 'bg-white/10 text-white/90 border-white/20 active:scale-95'
            }`}
          >
            L
          </button>

          <button
            onTouchStart={(e) => { e.preventDefault(); handleButtonDown('R1'); }}
            onTouchEnd={(e) => { e.preventDefault(); handleButtonUp('R1'); }}
            onMouseDown={() => handleButtonDown('R1')}
            onMouseUp={() => handleButtonUp('R1')}
            className={`w-24 h-11 rounded-2xl border flex items-center justify-center font-black text-sm tracking-wider backdrop-blur-md transition-all ${
              activeButtons['R1']
                ? 'bg-cyan-400 text-black border-cyan-300 scale-95 shadow-[0_0_15px_rgba(34,211,238,0.5)]'
                : 'bg-white/10 text-white/90 border-white/20 active:scale-95'
            }`}
          >
            R
          </button>
        </div>
      )}

      {/* Bottom Control Area */}
      <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between pointer-events-auto">
        {/* Left Side: Modern D-PAD */}
        <div className="relative w-44 h-44 flex items-center justify-center">
          {/* Cross Backing */}
          <div className="absolute w-40 h-14 bg-black/50 backdrop-blur-md rounded-2xl border border-white/15" />
          <div className="absolute w-14 h-40 bg-black/50 backdrop-blur-md rounded-2xl border border-white/15" />
          <div className="absolute w-14 h-14 bg-black/70 rounded-xl" />

          {/* UP Button */}
          <button
            onTouchStart={(e) => { e.preventDefault(); handleButtonDown('UP'); }}
            onTouchEnd={(e) => { e.preventDefault(); handleButtonUp('UP'); }}
            onMouseDown={() => handleButtonDown('UP')}
            onMouseUp={() => handleButtonUp('UP')}
            className={`absolute top-0 w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${
              activeButtons['UP']
                ? 'bg-cyan-400 text-black shadow-[0_0_12px_rgba(34,211,238,0.6)]'
                : 'text-white/80 active:bg-white/20'
            }`}
          >
            <div className="w-0 h-0 border-x-[6px] border-x-transparent border-b-[10px] border-b-current" />
          </button>

          {/* DOWN Button */}
          <button
            onTouchStart={(e) => { e.preventDefault(); handleButtonDown('DOWN'); }}
            onTouchEnd={(e) => { e.preventDefault(); handleButtonUp('DOWN'); }}
            onMouseDown={() => handleButtonDown('DOWN')}
            onMouseUp={() => handleButtonUp('DOWN')}
            className={`absolute bottom-0 w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${
              activeButtons['DOWN']
                ? 'bg-cyan-400 text-black shadow-[0_0_12px_rgba(34,211,238,0.6)]'
                : 'text-white/80 active:bg-white/20'
            }`}
          >
            <div className="w-0 h-0 border-x-[6px] border-x-transparent border-t-[10px] border-t-current" />
          </button>

          {/* LEFT Button */}
          <button
            onTouchStart={(e) => { e.preventDefault(); handleButtonDown('LEFT'); }}
            onTouchEnd={(e) => { e.preventDefault(); handleButtonUp('LEFT'); }}
            onMouseDown={() => handleButtonDown('LEFT')}
            onMouseUp={() => handleButtonUp('LEFT')}
            className={`absolute left-0 w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${
              activeButtons['LEFT']
                ? 'bg-cyan-400 text-black shadow-[0_0_12px_rgba(34,211,238,0.6)]'
                : 'text-white/80 active:bg-white/20'
            }`}
          >
            <div className="w-0 h-0 border-y-[6px] border-y-transparent border-r-[10px] border-r-current" />
          </button>

          {/* RIGHT Button */}
          <button
            onTouchStart={(e) => { e.preventDefault(); handleButtonDown('RIGHT'); }}
            onTouchEnd={(e) => { e.preventDefault(); handleButtonUp('RIGHT'); }}
            onMouseDown={() => handleButtonDown('RIGHT')}
            onMouseUp={() => handleButtonUp('RIGHT')}
            className={`absolute right-0 w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${
              activeButtons['RIGHT']
                ? 'bg-cyan-400 text-black shadow-[0_0_12px_rgba(34,211,238,0.6)]'
                : 'text-white/80 active:bg-white/20'
            }`}
          >
            <div className="w-0 h-0 border-y-[6px] border-y-transparent border-l-[10px] border-l-current" />
          </button>
        </div>

        {/* Center: SELECT & START Pills */}
        <div className="flex gap-4 pb-2">
          <button
            onTouchStart={(e) => { e.preventDefault(); handleButtonDown('SELECT'); }}
            onTouchEnd={(e) => { e.preventDefault(); handleButtonUp('SELECT'); }}
            onMouseDown={() => handleButtonDown('SELECT')}
            onMouseUp={() => handleButtonUp('SELECT')}
            className={`px-4 py-2 rounded-full border backdrop-blur-md text-[10px] font-mono font-black uppercase tracking-widest transition-all ${
              activeButtons['SELECT']
                ? 'bg-cyan-400 text-black border-cyan-300 scale-95 shadow-[0_0_12px_rgba(34,211,238,0.5)]'
                : 'bg-black/50 text-white/70 border-white/20 active:scale-95'
            }`}
          >
            SELECT
          </button>

          <button
            onTouchStart={(e) => { e.preventDefault(); handleButtonDown('START'); }}
            onTouchEnd={(e) => { e.preventDefault(); handleButtonUp('START'); }}
            onMouseDown={() => handleButtonDown('START')}
            onMouseUp={() => handleButtonUp('START')}
            className={`px-4 py-2 rounded-full border backdrop-blur-md text-[10px] font-mono font-black uppercase tracking-widest transition-all ${
              activeButtons['START']
                ? 'bg-cyan-400 text-black border-cyan-300 scale-95 shadow-[0_0_12px_rgba(34,211,238,0.5)]'
                : 'bg-black/50 text-white/70 border-white/20 active:scale-95'
            }`}
          >
            START
          </button>
        </div>

        {/* Right Side: Action Face Buttons */}
        {isSNES ? (
          // SNES Diamond Layout (A, B, X, Y)
          <div className="relative w-44 h-44 flex items-center justify-center">
            {/* X (Top) */}
            <button
              onTouchStart={(e) => { e.preventDefault(); handleButtonDown('X'); }}
              onTouchEnd={(e) => { e.preventDefault(); handleButtonUp('X'); }}
              onMouseDown={() => handleButtonDown('X')}
              onMouseUp={() => handleButtonUp('X')}
              className={`absolute top-0 w-14 h-14 rounded-full border flex items-center justify-center font-black text-base backdrop-blur-md transition-all ${
                activeButtons['X']
                  ? 'bg-blue-400 text-black border-blue-300 scale-90 shadow-[0_0_15px_rgba(96,165,250,0.7)]'
                  : 'bg-black/60 text-blue-300 border-blue-400/40 active:scale-90'
              }`}
            >
              X
            </button>

            {/* Y (Left) */}
            <button
              onTouchStart={(e) => { e.preventDefault(); handleButtonDown('Y'); }}
              onTouchEnd={(e) => { e.preventDefault(); handleButtonUp('Y'); }}
              onMouseDown={() => handleButtonDown('Y')}
              onMouseUp={() => handleButtonUp('Y')}
              className={`absolute left-0 w-14 h-14 rounded-full border flex items-center justify-center font-black text-base backdrop-blur-md transition-all ${
                activeButtons['Y']
                  ? 'bg-green-400 text-black border-green-300 scale-90 shadow-[0_0_15px_rgba(74,222,128,0.7)]'
                  : 'bg-black/60 text-green-300 border-green-400/40 active:scale-90'
              }`}
            >
              Y
            </button>

            {/* B (Bottom) */}
            <button
              onTouchStart={(e) => { e.preventDefault(); handleButtonDown('B'); }}
              onTouchEnd={(e) => { e.preventDefault(); handleButtonUp('B'); }}
              onMouseDown={() => handleButtonDown('B')}
              onMouseUp={() => handleButtonUp('B')}
              className={`absolute bottom-0 w-14 h-14 rounded-full border flex items-center justify-center font-black text-base backdrop-blur-md transition-all ${
                activeButtons['B']
                  ? 'bg-yellow-400 text-black border-yellow-300 scale-90 shadow-[0_0_15px_rgba(250,204,21,0.7)]'
                  : 'bg-black/60 text-yellow-300 border-yellow-400/40 active:scale-90'
              }`}
            >
              B
            </button>

            {/* A (Right) */}
            <button
              onTouchStart={(e) => { e.preventDefault(); handleButtonDown('A'); }}
              onTouchEnd={(e) => { e.preventDefault(); handleButtonUp('A'); }}
              onMouseDown={() => handleButtonDown('A')}
              onMouseUp={() => handleButtonUp('A')}
              className={`absolute right-0 w-14 h-14 rounded-full border flex items-center justify-center font-black text-base backdrop-blur-md transition-all ${
                activeButtons['A']
                  ? 'bg-red-400 text-black border-red-300 scale-90 shadow-[0_0_15px_rgba(248,113,113,0.7)]'
                  : 'bg-black/60 text-red-300 border-red-400/40 active:scale-90'
              }`}
            >
              A
            </button>
          </div>
        ) : (
          // NES 2-Button Layout (B and A angled)
          <div className="relative w-44 h-36 flex items-center justify-center gap-4">
            {/* Button B */}
            <button
              onTouchStart={(e) => { e.preventDefault(); handleButtonDown('B'); }}
              onTouchEnd={(e) => { e.preventDefault(); handleButtonUp('B'); }}
              onMouseDown={() => handleButtonDown('B')}
              onMouseUp={() => handleButtonUp('B')}
              className={`w-16 h-16 rounded-full border flex items-center justify-center font-black text-lg backdrop-blur-md transition-all translate-y-3 ${
                activeButtons['B']
                  ? 'bg-rose-500 text-white border-rose-300 scale-90 shadow-[0_0_15px_rgba(244,63,94,0.7)]'
                  : 'bg-black/60 text-rose-300 border-rose-500/40 active:scale-90'
              }`}
            >
              B
            </button>

            {/* Button A */}
            <button
              onTouchStart={(e) => { e.preventDefault(); handleButtonDown('A'); }}
              onTouchEnd={(e) => { e.preventDefault(); handleButtonUp('A'); }}
              onMouseDown={() => handleButtonDown('A')}
              onMouseUp={() => handleButtonUp('A')}
              className={`w-16 h-16 rounded-full border flex items-center justify-center font-black text-lg backdrop-blur-md transition-all -translate-y-2 ${
                activeButtons['A']
                  ? 'bg-rose-500 text-white border-rose-300 scale-90 shadow-[0_0_15px_rgba(244,63,94,0.7)]'
                  : 'bg-black/60 text-rose-300 border-rose-500/40 active:scale-90'
              }`}
            >
              A
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
