import React, { useEffect } from 'react';
import { useConsoleOS } from '../../context/ConsoleOSContext';
import { GameplaySurface } from './GameplaySurface';

export const GameplayRuntime: React.FC = () => {
  const { exitGame } = useConsoleOS();

  useEffect(() => {
    // During gameplay: document.body enters gameplay mode (Section 39)
    if (typeof document !== 'undefined') {
      document.body.classList.add('gameplay-mode');
    }

    return () => {
      if (typeof document !== 'undefined') {
        document.body.classList.remove('gameplay-mode');
      }
    };
  }, []);

  return (
    <div className="gameplay-runtime-root fixed inset-0 w-screen h-screen z-50 bg-black">
      <GameplaySurface onExit={exitGame} />
    </div>
  );
};
