import React from 'react';
import { useConsoleOS } from '../../context/ConsoleOSContext';
import { MOCK_CONSOLES } from '../../data/mockData';
import { LiveWallpaperCanvas } from '../../core/wallpaper/LiveWallpaperCanvas';
import { ConsoleWallpaperLayer } from '../../core/wallpaper/ConsoleWallpaperLayer';
import { 
  Play, 
  Info, 
  Heart, 
  Clock, 
  Sliders, 
  Gamepad2, 
  Zap, 
  Cpu, 
  Battery, 
  Wifi, 
  Volume2, 
  FolderSearch, 
  Disc3,
  BookmarkCheck,
  ChevronRight,
  ShieldCheck,
  Flame
} from 'lucide-react';

export const MobileLandscapeView: React.FC = () => {
  const {
    filteredGames,
    focusedGame,
    selectedConsole,
    setSelectedConsole,
    launchGame,
    openGameDetails,
    toggleFavorite,
    openSettings,
    openScanner,
    openSaveStates,
    openControllerMapper,
    activeSection,
    setActiveSection,
    batteryLevel,
    isMuted,
    accentColor,
    activeWallpaper,
    wallpaperSettings,
    isControllerConnected
  } = useConsoleOS();

  const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="relative w-full h-full min-h-screen bg-[#050608] text-white flex flex-row overflow-hidden select-none font-sans">
      {/* Wallpaper Layer (Static, Live Canvas, or Video) */}
      <ConsoleWallpaperLayer focusedGame={focusedGame} />

      {/* Left Handheld Quick Rail */}
      <aside className="w-16 md:w-20 z-30 bg-black/60 backdrop-blur-2xl border-r border-white/10 flex flex-col items-center py-4 justify-between shrink-0">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center font-black text-xs shadow-lg shadow-cyan-500/30">
            NV
          </div>

          <div className="w-8 h-[1px] bg-white/10 my-1" />

          {/* Nav Icons */}
          <button
            onClick={() => setActiveSection('for-you')}
            className={`w-11 h-11 rounded-xl flex items-center justify-center transition-all ${
              activeSection === 'for-you'
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-lg shadow-cyan-500/20'
                : 'text-zinc-400 hover:text-white hover:bg-white/5'
            }`}
            title="Home"
          >
            <Flame className="w-5 h-5" />
          </button>

          <button
            onClick={() => setActiveSection('library')}
            className={`w-11 h-11 rounded-xl flex items-center justify-center transition-all ${
              activeSection === 'library'
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-lg shadow-cyan-500/20'
                : 'text-zinc-400 hover:text-white hover:bg-white/5'
            }`}
            title="Library"
          >
            <Disc3 className="w-5 h-5" />
          </button>

          <button
            onClick={() => setActiveSection('consoles')}
            className={`w-11 h-11 rounded-xl flex items-center justify-center transition-all ${
              activeSection === 'consoles'
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-lg shadow-cyan-500/20'
                : 'text-zinc-400 hover:text-white hover:bg-white/5'
            }`}
            title="Cores & Consoles"
          >
            <Cpu className="w-5 h-5" />
          </button>

          <button
            onClick={openSaveStates}
            className="w-11 h-11 rounded-xl flex items-center justify-center text-zinc-400 hover:text-white hover:bg-white/5 transition-all"
            title="Save States"
          >
            <BookmarkCheck className="w-5 h-5" />
          </button>
        </div>

        <div className="flex flex-col items-center gap-3">
          <button
            onClick={openScanner}
            className="w-11 h-11 rounded-xl flex items-center justify-center text-zinc-400 hover:text-cyan-400 hover:bg-cyan-500/10 transition-all"
            title="Scan ROMs"
          >
            <FolderSearch className="w-5 h-5" />
          </button>

          <button
            onClick={openSettings}
            className="w-11 h-11 rounded-xl flex items-center justify-center text-zinc-400 hover:text-white hover:bg-white/5 transition-all"
            title="Settings"
          >
            <Sliders className="w-5 h-5" />
          </button>
        </div>
      </aside>

      {/* Main Handheld Content Area */}
      <main className="flex-1 flex flex-col h-full z-10 overflow-hidden">
        {/* Top Status Bar */}
        <header className="h-12 px-6 flex items-center justify-between border-b border-white/5 bg-black/40 backdrop-blur-md shrink-0">
          <div className="flex items-center gap-4">
            <span className="text-xs font-bold uppercase tracking-widest text-cyan-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              NOSTALGICVERSE HANDHELD OS
            </span>
            <span className="text-xs text-zinc-400 border-l border-white/10 pl-3">
              {filteredGames.length} ROMs Ready
            </span>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono text-zinc-400">
            {isControllerConnected && (
              <span className="flex items-center gap-1 text-emerald-400 font-bold">
                <Gamepad2 className="w-3.5 h-3.5" />
                HID Gamepad
              </span>
            )}
            <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-emerald-400 font-semibold">
              <Zap className="w-3 h-3" />
              60.0 FPS
            </div>
            <div className="flex items-center gap-1 text-zinc-300">
              <Wifi className="w-3.5 h-3.5" />
            </div>
            <div className="flex items-center gap-1.5 text-zinc-300">
              <Battery className="w-4 h-4 text-emerald-400" />
              <span>{batteryLevel}%</span>
            </div>
            <div className="text-white font-bold ml-2">{currentTime}</div>
          </div>
        </header>

        {/* Console Filter Strip */}
        <div className="px-6 py-2 flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0 border-b border-white/5 bg-black/20">
          <button
            onClick={() => setSelectedConsole('all')}
            className={`px-3.5 py-1 rounded-lg text-xs font-bold uppercase tracking-wider transition-all whitespace-nowrap ${
              selectedConsole === 'all'
                ? 'bg-cyan-500 text-black shadow-md shadow-cyan-500/30'
                : 'bg-white/5 text-zinc-400 hover:text-white hover:bg-white/10'
            }`}
          >
            All Systems
          </button>
          {MOCK_CONSOLES.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedConsole(c.id)}
              className={`px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-wider transition-all whitespace-nowrap flex items-center gap-1.5 ${
                selectedConsole === c.id
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-md shadow-cyan-500/20'
                  : 'bg-white/5 text-zinc-400 hover:text-white hover:bg-white/10'
              }`}
            >
              <span>{c.name}</span>
              <span className="text-[10px] opacity-60">({c.gameCount})</span>
            </button>
          ))}
        </div>

        {/* Central Split View */}
        <div className="flex-1 flex flex-row p-6 gap-6 overflow-hidden">
          {/* Focused Game Spotlight */}
          {focusedGame && (
            <div className="w-5/12 flex flex-col justify-between z-10">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="px-2.5 py-0.5 rounded bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 text-[10px] font-black uppercase tracking-widest">
                    {focusedGame.consoleId.toUpperCase()}
                  </span>
                  <span className="text-xs text-zinc-400 font-mono">
                    {focusedGame.developer}
                  </span>
                  <span className="text-xs text-zinc-500">•</span>
                  <span className="text-xs text-emerald-400 font-bold">★ 60 FPS Cycle-Accurate</span>
                </div>

                <h1 className="text-2xl lg:text-3xl font-black tracking-tight text-white line-clamp-2 drop-shadow-md">
                  {focusedGame.title}
                </h1>

                <p className="text-xs text-zinc-300 mt-2 line-clamp-3 leading-relaxed">
                  {focusedGame.description}
                </p>

                {/* Quick Spec Pills */}
                <div className="flex flex-wrap gap-2 mt-4 text-[11px] text-zinc-400">
                  <div className="px-2 py-1 rounded-md bg-white/5 border border-white/10 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-cyan-400" />
                    {Math.floor(focusedGame.playtimeMinutes / 60)}h {focusedGame.playtimeMinutes % 60}m
                  </div>
                  <div className="px-2 py-1 rounded-md bg-white/5 border border-white/10 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-emerald-400" />
                    Verified ROM
                  </div>
                  <div className="px-2 py-1 rounded-md bg-white/5 border border-white/10 font-mono">
                    {focusedGame.fileSize}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-3 mt-4">
                <button
                  onClick={() => launchGame(focusedGame)}
                  className="flex-1 py-3 px-5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl shadow-cyan-500/30 active:scale-95 transition-all"
                >
                  <Play className="w-4 h-4 fill-current" />
                  Launch Game
                </button>

                <button
                  onClick={() => openGameDetails(focusedGame)}
                  className="p-3 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/15 active:scale-95 transition-all"
                  title="Game Info & Settings"
                >
                  <Info className="w-4 h-4" />
                </button>

                <button
                  onClick={() => toggleFavorite(focusedGame.id)}
                  className={`p-3 rounded-xl border active:scale-95 transition-all ${
                    focusedGame.isFavorite
                      ? 'bg-pink-500/20 text-pink-400 border-pink-500/50'
                      : 'bg-white/10 text-zinc-300 border-white/15 hover:text-white'
                  }`}
                  title="Favorite"
                >
                  <Heart className={`w-4 h-4 ${focusedGame.isFavorite ? 'fill-current' : ''}`} />
                </button>
              </div>
            </div>
          )}

          {/* Horizontal Game Ribbon */}
          <div className="w-7/12 flex flex-col justify-center overflow-hidden">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                Installed Collection ({filteredGames.length})
              </span>
              <span className="text-[11px] text-cyan-400 flex items-center gap-1">
                Scroll & Select <ChevronRight className="w-3 h-3" />
              </span>
            </div>

            <div className="flex items-center gap-4 overflow-x-auto py-3 px-1 no-scrollbar scroll-smooth">
              {filteredGames.map((game) => {
                const isSelected = focusedGame?.id === game.id;
                return (
                  <div
                    key={game.id}
                    onClick={() => launchGame(game)}
                    className={`shrink-0 w-36 md:w-44 group cursor-pointer transition-all duration-300 rounded-2xl overflow-hidden relative ${
                      isSelected
                        ? 'ring-4 ring-cyan-400 scale-105 shadow-2xl shadow-cyan-500/40 -translate-y-2'
                        : 'opacity-70 hover:opacity-100 hover:scale-100'
                    }`}
                  >
                    <div className={`aspect-[3/4] rounded-2xl bg-gradient-to-br ${game.coverGradient} p-3 flex flex-col justify-between relative`}>
                      <div className="self-start px-2 py-0.5 rounded bg-black/70 backdrop-blur-md text-[9px] font-black text-cyan-300 border border-white/10 uppercase">
                        {game.consoleId}
                      </div>

                      {game.isFavorite && (
                        <div className="absolute top-2 right-2 text-pink-500">
                          <Heart className="w-3.5 h-3.5 fill-current" />
                        </div>
                      )}

                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-black/40 backdrop-blur-xs transition-opacity">
                        <div className="w-10 h-10 rounded-full bg-cyan-500 text-black flex items-center justify-center shadow-lg">
                          <Play className="w-5 h-5 fill-current ml-0.5" />
                        </div>
                      </div>

                      <div className="mt-auto">
                        <p className="text-xs font-bold text-white truncate drop-shadow">
                          {game.title}
                        </p>
                        <p className="text-[10px] text-zinc-300 truncate">
                          {game.genre}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
