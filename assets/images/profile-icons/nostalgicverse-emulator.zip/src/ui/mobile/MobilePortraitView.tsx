import React from 'react';
import { useConsoleOS } from '../../context/ConsoleOSContext';
import { MOCK_CONSOLES } from '../../data/mockData';
import { LiveWallpaperCanvas } from '../../core/wallpaper/LiveWallpaperCanvas';
import { ConsoleWallpaperLayer } from '../../core/wallpaper/ConsoleWallpaperLayer';
import { 
  Play, 
  Info, 
  Heart, 
  Clock, 
  Search, 
  Settings, 
  Sliders, 
  Gamepad2, 
  Zap, 
  Cpu, 
  Battery, 
  Wifi, 
  FolderSearch, 
  Sparkles, 
  BookmarkCheck,
  Disc3,
  ChevronRight,
  ShieldCheck,
  Flame
} from 'lucide-react';

export const MobilePortraitView: React.FC = () => {
  const {
    filteredGames,
    focusedGame,
    selectedConsole,
    setSelectedConsole,
    launchGame,
    openGameDetails,
    toggleFavorite,
    openSettings,
    openScanner,
    openSaveStates,
    openControllerMapper,
    activeSection,
    setActiveSection,
    batteryLevel,
    timeString,
    accentColor,
    activeWallpaper,
    wallpaperSettings,
    isControllerConnected
  } = useConsoleOS();

  return (
    <div className="relative w-full h-full min-h-screen bg-[#050608] text-white flex flex-col justify-between overflow-x-hidden select-none font-sans pb-20">
      {/* Wallpaper Layer (Static, Live Canvas, or Video) */}
      <ConsoleWallpaperLayer focusedGame={focusedGame} />

      {/* 1. Mobile Status & Brand Header */}
      <header className="px-5 pt-4 pb-2 flex items-center justify-between border-b border-white/5 bg-black/40 backdrop-blur-lg sticky top-0 z-30">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center font-black text-xs shadow-md shadow-cyan-500/30">
            NV
          </div>
          <div>
            <span className="text-xs font-black tracking-wider text-white block uppercase">
              NOSTALGICVERSE
            </span>
            <span className="text-[9px] font-mono text-cyan-400 font-bold uppercase tracking-widest block">
              PORTABLE OS
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={openScanner}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-cyan-400 border border-white/10"
            title="Import / Scan ROMs"
          >
            <FolderSearch className="w-4 h-4" />
          </button>

          <button
            onClick={openSettings}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-300 border border-white/10"
            title="Settings & Controller Test"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* 2. Console Filter Horizontal Strip */}
      <section className="relative z-10 px-5 py-3 flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
        <button
          onClick={() => setSelectedConsole('all')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all whitespace-nowrap ${
            selectedConsole === 'all'
              ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-500/30 font-black'
              : 'bg-white/5 text-zinc-400 hover:text-white hover:bg-white/10'
          }`}
        >
          All ({filteredGames.length})
        </button>
        {MOCK_CONSOLES.map((c) => (
          <button
            key={c.id}
            onClick={() => setSelectedConsole(c.id)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all whitespace-nowrap flex items-center gap-1.5 ${
              selectedConsole === c.id
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-md shadow-cyan-500/20'
                : 'bg-white/5 text-zinc-400 hover:text-white hover:bg-white/10'
            }`}
          >
            <span>{c.name}</span>
          </button>
        ))}
      </section>

      {/* 3. Hero Featured Spotlight Card */}
      {focusedGame && (
        <section className="relative z-10 px-5 py-2">
          <div className="relative rounded-3xl overflow-hidden border border-white/15 bg-[#0e121a] shadow-2xl p-5 flex flex-col justify-between min-h-[220px]">
            <div className={`absolute inset-0 bg-gradient-to-tr ${focusedGame.bannerGradient} opacity-40`} />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0e121a] via-[#0e121a]/60 to-transparent" />

            {/* Console Tag & Quick Info */}
            <div className="relative z-10 flex items-center justify-between">
              <span className="px-2.5 py-1 rounded-lg bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 text-[10px] font-black uppercase tracking-widest backdrop-blur-md">
                {focusedGame.consoleId.toUpperCase()}
              </span>

              <button
                onClick={() => toggleFavorite(focusedGame.id)}
                className={`p-2 rounded-xl border backdrop-blur-md transition-all ${
                  focusedGame.isFavorite
                    ? 'bg-pink-500/20 text-pink-400 border-pink-500/50'
                    : 'bg-black/40 text-zinc-300 border-white/10'
                }`}
              >
                <Heart className={`w-4 h-4 ${focusedGame.isFavorite ? 'fill-current' : ''}`} />
              </button>
            </div>

            {/* Title & Metadata */}
            <div className="relative z-10 my-3">
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight leading-tight">
                {focusedGame.title}
              </h2>
              <p className="text-xs text-zinc-300 line-clamp-2 mt-1">
                {focusedGame.description}
              </p>
            </div>

            {/* Launch Bar */}
            <div className="relative z-10 flex items-center gap-2 pt-2">
              <button
                onClick={() => launchGame(focusedGame)}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-black font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/30 active:scale-95 transition-all"
              >
                <Play className="w-4 h-4 fill-current" />
                Play Game
              </button>

              <button
                onClick={() => openGameDetails(focusedGame)}
                className="p-3 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/15 active:scale-95 transition-all"
              >
                <Info className="w-4 h-4" />
              </button>
            </div>
          </div>
        </section>
      )}

      {/* 4. Game Collection Cards Grid */}
      <section className="relative z-10 px-5 py-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400">
            Game Library ({filteredGames.length})
          </h3>
          <span className="text-[11px] text-cyan-400">Tap to launch</span>
        </div>

        <div className="grid grid-cols-2 gap-3.5">
          {filteredGames.map((game) => (
            <div
              key={game.id}
              onClick={() => launchGame(game)}
              className="p-3 rounded-2xl bg-white/5 border border-white/10 hover:border-cyan-500/40 active:scale-95 transition-all flex flex-col gap-2 cursor-pointer group"
            >
              <div className={`aspect-[4/3] rounded-xl bg-gradient-to-br ${game.coverGradient} p-2 flex flex-col justify-between relative overflow-hidden shadow-inner`}>
                <span className="self-start px-2 py-0.5 rounded bg-black/70 backdrop-blur-md text-[9px] font-black text-cyan-300 border border-white/10 uppercase">
                  {game.consoleId}
                </span>

                <span className="self-end px-1.5 py-0.5 rounded bg-black/60 text-[9px] font-mono text-zinc-300">
                  {game.targetFps} FPS
                </span>

                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                  <div className="w-8 h-8 rounded-full bg-cyan-500 text-black flex items-center justify-center">
                    <Play className="w-4 h-4 fill-current ml-0.5" />
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-xs font-bold text-white truncate group-hover:text-cyan-300 transition-colors">
                  {game.title}
                </h4>
                <p className="text-[10px] text-zinc-400 truncate">
                  {game.genre} • {game.fileSize}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Mobile Bottom Touch Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 h-16 bg-[#080b11]/95 backdrop-blur-2xl border-t border-white/10 px-6 flex items-center justify-around">
        <button
          onClick={() => setActiveSection('for-you')}
          className={`flex flex-col items-center gap-1 transition-all ${
            activeSection === 'for-you' ? 'text-cyan-400' : 'text-zinc-500 hover:text-white'
          }`}
        >
          <Flame className="w-5 h-5" />
          <span className="text-[10px] font-bold">Home</span>
        </button>

        <button
          onClick={() => setActiveSection('library')}
          className={`flex flex-col items-center gap-1 transition-all ${
            activeSection === 'library' ? 'text-cyan-400' : 'text-zinc-500 hover:text-white'
          }`}
        >
          <Disc3 className="w-5 h-5" />
          <span className="text-[10px] font-bold">Library</span>
        </button>

        <button
          onClick={openSaveStates}
          className="flex flex-col items-center gap-1 text-zinc-500 hover:text-white transition-all"
        >
          <BookmarkCheck className="w-5 h-5" />
          <span className="text-[10px] font-bold">Saves</span>
        </button>

        <button
          onClick={openSettings}
          className="flex flex-col items-center gap-1 text-zinc-500 hover:text-white transition-all"
        >
          <Sliders className="w-5 h-5" />
          <span className="text-[10px] font-bold">Config</span>
        </button>
      </nav>
    </div>
  );
};
