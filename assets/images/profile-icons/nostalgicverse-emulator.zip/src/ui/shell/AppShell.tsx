import React from 'react';
import { useConsoleOS } from '../../context/ConsoleOSContext';
import { DesktopConsoleView } from '../desktop/DesktopConsoleView';
import { MobilePortraitView } from '../mobile/MobilePortraitView';
import { MobileLandscapeView } from '../mobile/MobileLandscapeView';
import { ControllerLegend } from '../../components/controller/ControllerLegend';
import { GameDetailsModal } from '../../components/modals/GameDetailsModal';
import { SettingsModal } from '../../components/modals/SettingsModal';
import { SaveStatesModal } from '../../components/modals/SaveStatesModal';
import { ScannerModal } from '../../components/modals/ScannerModal';
import { ControllerMapperModal } from '../../components/modals/ControllerMapperModal';
import { ToastContainer } from '../../components/common/ToastContainer';

export const AppShell: React.FC = () => {
  const { uiMode } = useConsoleOS();

  // If in GAMEPLAY mode, AppShell renders nothing so zero UI leaks into gameplay
  if (uiMode === 'GAMEPLAY') {
    return null;
  }

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-black text-white font-sans app-shell-root">
      {/* Console OS Viewports */}
      {uiMode === 'DESKTOP_CONSOLE' && <DesktopConsoleView />}
      {uiMode === 'MOBILE_PORTRAIT' && <MobilePortraitView />}
      {uiMode === 'MOBILE_LANDSCAPE' && <MobileLandscapeView />}

      {/* Global Modals */}
      <GameDetailsModal />
      <SettingsModal />
      <SaveStatesModal />
      <ScannerModal />
      <ControllerMapperModal />
      <ToastContainer />

      {/* Controller Legend */}
      <ControllerLegend />
    </div>
  );
};
