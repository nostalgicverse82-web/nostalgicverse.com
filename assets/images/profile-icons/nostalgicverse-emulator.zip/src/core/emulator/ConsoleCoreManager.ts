import { ConsoleId } from '../../types/emulator';
import { EmulatorCoreAdapter, EmulatorControllerState, DiagnosticInfo } from './EmulatorCore';
import { NESCoreAdapter } from './nes/NESCoreAdapter';
import { SNESCoreAdapter } from './snes/SNESCoreAdapter';
import { GBCoreAdapter, GBPaletteMode } from './gb/GBCoreAdapter';
import { GBACoreAdapter } from './gba/GBACoreAdapter';
import { NESPaletteMode } from './nes/NESPalettes';
import { audioPipeline } from '../audio/AudioPipeline';
import { 
  createSampleNesRom, 
  createSampleSnesRom,
  createSampleGbRom,
  createSampleGbcRom,
  createSampleGbaRom
} from '../rom/sampleRoms';

export type EmulationRuntimeState = 
  | 'LAUNCHER'
  | 'LOADING_GAME'
  | 'INITIALIZING_CORE'
  | 'LOADING_ROM'
  | 'INITIALIZING_VIDEO'
  | 'INITIALIZING_AUDIO'
  | 'INITIALIZING_INPUT'
  | 'RUNNING'
  | 'PAUSED'
  | 'EXITING_GAME'
  | 'ERROR';

export interface EmulationErrorDetails {
  console: string;
  romName: string;
  status: 'FAILED';
  reason: string;
  suggestedAction: string;
}

const raf = typeof requestAnimationFrame !== 'undefined' 
  ? requestAnimationFrame 
  : (cb: FrameRequestCallback) => setTimeout(() => cb(performance.now()), 1000 / 60) as unknown as number;

const caf = typeof cancelAnimationFrame !== 'undefined' 
  ? cancelAnimationFrame 
  : (id: number) => clearTimeout(id as any);

export class ConsoleCoreManager {
  private activeCore: EmulatorCoreAdapter | null = null;
  private animFrameId: number | null = null;
  private runtimeState: EmulationRuntimeState = 'LAUNCHER';
  private lastErrorDetails: EmulationErrorDetails | null = null;
  private hasProducedFrame = false;

  private frameCallback?: (frame: Uint8ClampedArray | Uint8Array | HTMLCanvasElement, width: number, height: number) => void;
  private stateCallback?: (state: EmulationRuntimeState, error?: EmulationErrorDetails | null) => void;

  public async launchGame(
    consoleId: ConsoleId,
    romData?: Uint8Array,
    gameTitle?: string,
    filename?: string
  ): Promise<boolean> {
    this.shutdown(false);
    this.lastErrorDetails = null;
    this.hasProducedFrame = false;
    this.setState('LOADING_GAME');

    const effectiveTitle = gameTitle || filename || `${consoleId.toUpperCase()} Game`;
    const extMap: Record<ConsoleId, string> = {
      nes: 'nes',
      snes: 'sfc',
      gb: 'gb',
      gbc: 'gbc',
      gba: 'gba',
      nds: 'nds',
      n64: 'z64',
      ps1: 'iso',
      psp: 'iso',
      '3ds': '3ds',
      ps2: 'iso',
      ps3: 'iso'
    };
    const effectiveFilename = filename || `${effectiveTitle}.${extMap[consoleId] || 'rom'}`;

    try {
      // 1. Core Selection & Initialization
      this.setState('INITIALIZING_CORE');
      let core: EmulatorCoreAdapter;
      if (consoleId === 'nes') {
        core = new NESCoreAdapter();
      } else if (consoleId === 'snes') {
        core = new SNESCoreAdapter();
      } else if (consoleId === 'gb') {
        core = new GBCoreAdapter('gb');
      } else if (consoleId === 'gbc') {
        core = new GBCoreAdapter('gbc');
      } else if (consoleId === 'gba') {
        core = new GBACoreAdapter();
      } else {
        throw {
          console: consoleId.toUpperCase(),
          romName: effectiveTitle,
          status: 'FAILED',
          reason: `Emulator core for '${consoleId.toUpperCase()}' is currently in staging. Only genuine hardware-verified cores are allowed.`,
          suggestedAction: 'Please launch an NES, SNES, GB, GBC, or GBA cartridge to experience authentic 60 FPS hardware execution.'
        };
      }

      this.activeCore = core;
      await core.initialize();

      // 2. ROM Loading & Validation
      this.setState('LOADING_ROM');
      let dataToLoad = romData;
      if (!dataToLoad || dataToLoad.length === 0) {
        if (consoleId === 'nes') {
          dataToLoad = createSampleNesRom();
        } else if (consoleId === 'snes') {
          dataToLoad = createSampleSnesRom();
        } else if (consoleId === 'gb') {
          dataToLoad = createSampleGbRom();
        } else if (consoleId === 'gbc') {
          dataToLoad = createSampleGbcRom();
        } else if (consoleId === 'gba') {
          dataToLoad = createSampleGbaRom();
        } else {
          const cidStr = String(consoleId).toUpperCase();
          throw {
            console: cidStr,
            romName: effectiveTitle,
            status: 'FAILED',
            reason: `Emulator core for '${cidStr}' is currently in staging. Only genuine hardware-verified cores are allowed.`,
            suggestedAction: 'Please select a supported cartridge file (.nes, .sfc, .gb, .gbc, .gba) via the ROM Scanner.'
          };
        }
      }

      // Pre-validate ROM using core's hardware rules
      const validation = core.validateROM(dataToLoad, effectiveFilename);
      if (!validation.valid) {
        throw {
          console: consoleId.toUpperCase(),
          romName: effectiveTitle,
          status: 'FAILED',
          reason: validation.errorReason || 'Cartridge failed hardware validation check.',
          suggestedAction: validation.suggestedAction || 'Ensure this is a clean, uncorrupted ROM image.'
        };
      }

      const loaded = await core.loadROM(dataToLoad, effectiveFilename);
      if (!loaded) {
        throw {
          console: consoleId.toUpperCase(),
          romName: effectiveTitle,
          status: 'FAILED',
          reason: `Core failed to initialize memory and CPU registers for ${effectiveTitle}.`,
          suggestedAction: 'Check that the ROM header and mappers match supported specifications.'
        };
      }

      // 3. Audio & Video Initializations
      this.setState('INITIALIZING_AUDIO');
      if (consoleId === 'nes') {
        audioPipeline.init();
        audioPipeline.resume();
      }

      this.setState('INITIALIZING_VIDEO');
      this.setState('INITIALIZING_INPUT');

      // 4. Start 60 FPS Emulation Frame Loop
      this.startLoop();

      return true;
    } catch (err: any) {
      const errorDetails: EmulationErrorDetails = {
        console: err?.console || consoleId.toUpperCase(),
        romName: err?.romName || effectiveTitle,
        status: 'FAILED',
        reason: err?.reason || err?.message || 'Emulation initialization failure',
        suggestedAction: err?.suggestedAction || 'Verify ROM integrity and compatibility.'
      };

      this.lastErrorDetails = errorDetails;
      this.setState('ERROR', errorDetails);
      this.shutdown(false);
      return false;
    }
  }

  private startLoop() {
    let lastTime = performance.now();
    const frameInterval = 1000 / 60;

    const loop = (now: number) => {
      if (this.runtimeState !== 'RUNNING' && this.runtimeState !== 'INITIALIZING_INPUT' && this.runtimeState !== 'PAUSED') {
        return;
      }

      const delta = now - lastTime;
      if (this.runtimeState !== 'PAUSED' && delta >= frameInterval) {
        lastTime = now - (delta % frameInterval);

        if (this.activeCore) {
          try {
            // Execute authentic hardware frame
            this.activeCore.runFrame();

            // Retrieve Real Frame Buffer
            const frame = this.activeCore.getVideoFrame();
            const width = this.activeCore.getVideoWidth();
            const height = this.activeCore.getVideoHeight();

            if (frame) {
              if (!this.hasProducedFrame) {
                this.hasProducedFrame = true;
                this.setState('RUNNING');
              }

              if (this.frameCallback) {
                this.frameCallback(frame, width, height);
              }
            }

            // Stream NES hardware audio
            if (this.activeCore.getAudioSamples) {
              const audioSamples = this.activeCore.getAudioSamples();
              if (audioSamples && audioSamples.length > 0) {
                audioPipeline.writeSamples(audioSamples);
              }
            }
          } catch (err: any) {
            const errDetails: EmulationErrorDetails = {
              console: this.activeCore.consoleId.toUpperCase(),
              romName: 'Active Cartridge',
              status: 'FAILED',
              reason: `Execution fault: ${err?.message || 'CPU/PPU Trap'}`,
              suggestedAction: 'The ROM encountered an unhandled instruction. Reset the game or inspect developer diagnostics.'
            };
            this.lastErrorDetails = errDetails;
            this.setState('ERROR', errDetails);
            this.shutdown(false);
            return;
          }
        }
      }

      this.animFrameId = raf(loop);
    };

    this.animFrameId = raf(loop);
  }

  public setControllerState(player: number, state: EmulatorControllerState) {
    if (this.activeCore && (this.runtimeState === 'RUNNING' || this.runtimeState === 'PAUSED')) {
      this.activeCore.setControllerState(player, state);
    }
  }

  public pause() {
    if (this.runtimeState === 'RUNNING') {
      if (this.activeCore) this.activeCore.pause();
      this.setState('PAUSED');
    }
  }

  public resume() {
    if (this.runtimeState === 'PAUSED') {
      if (this.activeCore) this.activeCore.resume();
      if (this.activeCore?.consoleId === 'nes') {
        audioPipeline.resume();
      }
      this.setState('RUNNING');
    }
  }

  public reset() {
    if (this.activeCore) {
      this.activeCore.reset();
    }
  }

  public shutdown(notify = true) {
    if (this.animFrameId !== null) {
      caf(this.animFrameId);
      this.animFrameId = null;
    }
    if (this.activeCore) {
      this.activeCore.shutdown();
      this.activeCore = null;
    }
    audioPipeline.shutdown();
    this.hasProducedFrame = false;

    if (notify) {
      this.setState('LAUNCHER');
    }
  }

  private setState(state: EmulationRuntimeState, error?: EmulationErrorDetails | null) {
    this.runtimeState = state;
    if (this.stateCallback) {
      this.stateCallback(state, error || this.lastErrorDetails);
    }
  }

  public onVideoFrame(fn: (frame: Uint8ClampedArray | Uint8Array | HTMLCanvasElement, width: number, height: number) => void) {
    this.frameCallback = fn;
  }

  public onStateChange(fn: (state: EmulationRuntimeState, error?: EmulationErrorDetails | null) => void) {
    this.stateCallback = fn;
  }

  public getRuntimeState(): EmulationRuntimeState {
    return this.runtimeState;
  }

  public getLastErrorDetails(): EmulationErrorDetails | null {
    return this.lastErrorDetails;
  }

  public getLastError(): string | null {
    return this.lastErrorDetails?.reason || null;
  }

  public getActiveCore(): EmulatorCoreAdapter | null {
    return this.activeCore;
  }

  public getDiagnostics(): DiagnosticInfo | null {
    if (this.activeCore?.getDiagnostics) {
      return this.activeCore.getDiagnostics();
    }
    return null;
  }

  public async createSaveState(): Promise<Uint8Array | null> {
    if (this.activeCore?.createSaveState) {
      return await this.activeCore.createSaveState();
    }
    return null;
  }

  public setNesPalette(mode: NESPaletteMode, customColors?: Uint32Array) {
    if (this.activeCore instanceof NESCoreAdapter) {
      this.activeCore.setPalette(mode, customColors);
    }
  }

  public setGbPalette(mode: GBPaletteMode) {
    if (this.activeCore instanceof GBCoreAdapter) {
      this.activeCore.setPaletteMode(mode);
    }
  }

  public async loadSaveState(data: Uint8Array): Promise<boolean> {
    if (this.activeCore?.loadSaveState) {
      return await this.activeCore.loadSaveState(data);
    }
    return false;
  }
}

export const consoleCoreManager = new ConsoleCoreManager();
