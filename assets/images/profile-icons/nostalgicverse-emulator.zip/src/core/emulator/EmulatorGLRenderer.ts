/**
 * Hardware-Accelerated WebGL2 / WebGL Framebuffer Renderer
 * Directly uploads the emulator's native 256x240 (NES) or 256x224 (SNES) framebuffer
 * with NEAREST texture filtering, zero color alteration, zero interpolation, and integer scaling.
 */

export type ScalingMode = 
  | 'original' 
  | 'integer-scale' 
  | 'fit' 
  | 'fill' 
  | 'stretch' 
  | 'custom'
  | 'pixel-perfect' 
  | '4:3';

export class EmulatorGLRenderer {
  private canvas: HTMLCanvasElement;
  private gl: WebGLRenderingContext | WebGL2RenderingContext | null = null;
  private ctx2d: CanvasRenderingContext2D | null = null;
  private program: WebGLProgram | null = null;
  private texture: WebGLTexture | null = null;
  private positionBuffer: WebGLBuffer | null = null;
  private texCoordBuffer: WebGLBuffer | null = null;
  private uTextureLocation: WebGLUniformLocation | null = null;

  private nativeWidth = 256;
  private nativeHeight = 240;
  private scalingMode: ScalingMode = 'fit';
  private customScale = 2.5;
  private crtFilter = false;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.initWebGL();
  }

  private initWebGL() {
    // Attempt WebGL2 first, then WebGL1, fallback to 2D
    const opts: WebGLContextAttributes = {
      alpha: false,
      depth: false,
      stencil: false,
      antialias: false,
      preserveDrawingBuffer: false,
      powerPreference: 'high-performance'
    };

    this.gl = (this.canvas.getContext('webgl2', opts) as WebGL2RenderingContext) ||
              (this.canvas.getContext('webgl', opts) as WebGLRenderingContext);

    if (!this.gl) {
      this.ctx2d = this.canvas.getContext('2d', { alpha: false });
      if (this.ctx2d) {
        this.ctx2d.imageSmoothingEnabled = false;
      }
      return;
    }

    const gl = this.gl;

    // Vertex Shader: full quad
    const vsSource = `
      attribute vec2 a_position;
      attribute vec2 a_texCoord;
      varying vec2 v_texCoord;
      void main() {
        gl_Position = vec4(a_position, 0.0, 1.0);
        v_texCoord = a_texCoord;
      }
    `;

    // Fragment Shader: pure passthrough with NEAREST texture sample + optional scanline
    const fsSource = `
      precision mediump float;
      varying vec2 v_texCoord;
      uniform sampler2D u_texture;
      uniform float u_scanlines;

      void main() {
        vec4 color = texture2D(u_texture, v_texCoord);
        if (u_scanlines > 0.5) {
          float scanline = sin(v_texCoord.y * 480.0 * 3.14159) * 0.15;
          color.rgb -= scanline;
        }
        gl_FragColor = vec4(color.rgb, 1.0);
      }
    `;

    const vs = this.compileShader(gl.VERTEX_SHADER, vsSource);
    const fs = this.compileShader(gl.FRAGMENT_SHADER, fsSource);
    if (!vs || !fs) return;

    this.program = gl.createProgram();
    if (!this.program) return;

    gl.attachShader(this.program, vs);
    gl.attachShader(this.program, fs);
    gl.linkProgram(this.program);

    if (!gl.getProgramParameter(this.program, gl.LINK_STATUS)) {
      console.warn('WebGL link failed, falling back to 2D canvas');
      this.gl = null;
      this.ctx2d = this.canvas.getContext('2d', { alpha: false });
      if (this.ctx2d) this.ctx2d.imageSmoothingEnabled = false;
      return;
    }

    gl.useProgram(this.program);

    // Quad geometry: 2 triangles
    const positions = new Float32Array([
      -1, -1,
       1, -1,
      -1,  1,
      -1,  1,
       1, -1,
       1,  1
    ]);
    this.positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.positionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, positions, gl.STATIC_DRAW);

    // TexCoords: flip Y so top of emulator frame is at top of screen
    const texCoords = new Float32Array([
      0, 1,
      1, 1,
      0, 0,
      0, 0,
      1, 1,
      1, 0
    ]);
    this.texCoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.texCoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, texCoords, gl.STATIC_DRAW);

    // Dedicated Emulator Texture with NEAREST filtering
    this.texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);

    this.uTextureLocation = gl.getUniformLocation(this.program, 'u_texture');
  }

  private compileShader(type: number, source: string): WebGLShader | null {
    if (!this.gl) return null;
    const shader = this.gl.createShader(type);
    if (!shader) return null;
    this.gl.shaderSource(shader, source);
    this.gl.compileShader(shader);
    if (!this.gl.getShaderParameter(shader, this.gl.COMPILE_STATUS)) {
      this.gl.deleteShader(shader);
      return null;
    }
    return shader;
  }

  public setDimensions(width: number, height: number) {
    this.nativeWidth = width;
    this.nativeHeight = height;
  }

  public setScalingMode(mode: ScalingMode) {
    this.scalingMode = mode;
  }

  public setCustomScale(scale: number) {
    this.customScale = Math.max(0.5, Math.min(6.0, scale));
  }

  public setCrtFilter(enabled: boolean) {
    this.crtFilter = enabled;
  }

  public render(frameData: Uint8ClampedArray | Uint8Array | HTMLCanvasElement, width: number, height: number) {
    this.nativeWidth = width;
    this.nativeHeight = height;

    if (this.gl && this.program && this.texture) {
      const gl = this.gl;

      if (this.canvas.width !== width || this.canvas.height !== height) {
        this.canvas.width = width;
        this.canvas.height = height;
      }

      gl.viewport(0, 0, width, height);
      gl.useProgram(this.program);

      // Upload raw pixel buffer or canvas directly to GPU texture
      gl.bindTexture(gl.TEXTURE_2D, this.texture);
      if (frameData instanceof HTMLCanvasElement) {
        gl.texImage2D(
          gl.TEXTURE_2D,
          0,
          gl.RGBA,
          gl.RGBA,
          gl.UNSIGNED_BYTE,
          frameData
        );
      } else {
        gl.texImage2D(
          gl.TEXTURE_2D,
          0,
          gl.RGBA,
          width,
          height,
          0,
          gl.RGBA,
          gl.UNSIGNED_BYTE,
          frameData
        );
      }

      // Uniforms
      gl.uniform1i(this.uTextureLocation, 0);
      const uScanlinesLoc = gl.getUniformLocation(this.program, 'u_scanlines');
      if (uScanlinesLoc) {
        gl.uniform1f(uScanlinesLoc, this.crtFilter ? 1.0 : 0.0);
      }

      // Attributes
      const aPosLoc = gl.getAttribLocation(this.program, 'a_position');
      gl.enableVertexAttribArray(aPosLoc);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.positionBuffer);
      gl.vertexAttribPointer(aPosLoc, 2, gl.FLOAT, false, 0, 0);

      const aTexLoc = gl.getAttribLocation(this.program, 'a_texCoord');
      gl.enableVertexAttribArray(aTexLoc);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.texCoordBuffer);
      gl.vertexAttribPointer(aTexLoc, 2, gl.FLOAT, false, 0, 0);

      // Draw
      gl.drawArrays(gl.TRIANGLES, 0, 6);
    } else if (this.ctx2d) {
      // 2D Canvas Fallback
      if (this.canvas.width !== width || this.canvas.height !== height) {
        this.canvas.width = width;
        this.canvas.height = height;
      }
      this.ctx2d.imageSmoothingEnabled = false;
      if (frameData instanceof HTMLCanvasElement) {
        this.ctx2d.drawImage(frameData, 0, 0, width, height);
      } else {
        const imgData = this.ctx2d.createImageData(width, height);
        imgData.data.set(frameData);
        this.ctx2d.putImageData(imgData, 0, 0);
      }

      if (this.crtFilter) {
        this.ctx2d.fillStyle = 'rgba(0, 0, 0, 0.2)';
        for (let y = 0; y < height; y += 2) {
          this.ctx2d.fillRect(0, y, width, 1);
        }
      }
    }
  }

  public computeDisplaySize(viewportWidth: number, viewportHeight: number): { width: number; height: number } {
    const nw = this.nativeWidth;
    const nh = this.nativeHeight;

    // Authentic Hardware Aspect Ratio
    let targetRatio = nw / nh;
    if (nw === 256 && (nh === 240 || nh === 224)) {
      // NES (256x240) & SNES (256x224) output standard 4:3 CRT DAR
      targetRatio = 4 / 3;
    } else if (nw === 160 && nh === 144) {
      // Game Boy / Game Boy Color (160x144) native aspect ratio is 10:9
      targetRatio = 10 / 9;
    } else if (nw === 240 && nh === 160) {
      // Game Boy Advance (240x160) native aspect ratio is 3:2
      targetRatio = 3 / 2;
    }

    switch (this.scalingMode) {
      case 'original': {
        return {
          width: nw,
          height: nh
        };
      }

      case 'pixel-perfect':
      case 'integer-scale': {
        const maxScaleX = Math.floor(viewportWidth / nw);
        const maxScaleY = Math.floor(viewportHeight / nh);
        const scale = Math.max(1, Math.min(maxScaleX, maxScaleY));
        return {
          width: nw * scale,
          height: nh * scale
        };
      }

      case 'fit':
      case '4:3': {
        const viewRatio = viewportWidth / viewportHeight;
        if (viewRatio > targetRatio) {
          return {
            width: Math.round(viewportHeight * targetRatio),
            height: viewportHeight
          };
        } else {
          return {
            width: viewportWidth,
            height: Math.round(viewportWidth / targetRatio)
          };
        }
      }

      case 'fill': {
        const viewRatio = viewportWidth / viewportHeight;
        if (viewRatio > targetRatio) {
          return {
            width: viewportWidth,
            height: Math.round(viewportWidth / targetRatio)
          };
        } else {
          return {
            width: Math.round(viewportHeight * targetRatio),
            height: viewportHeight
          };
        }
      }

      case 'stretch': {
        return {
          width: viewportWidth,
          height: viewportHeight
        };
      }

      case 'custom': {
        return {
          width: Math.round(nw * this.customScale),
          height: Math.round(nh * this.customScale)
        };
      }

      default: {
        return {
          width: nw,
          height: nh
        };
      }
    }
  }

  public destroy() {
    if (this.gl) {
      if (this.texture) this.gl.deleteTexture(this.texture);
      if (this.positionBuffer) this.gl.deleteBuffer(this.positionBuffer);
      if (this.texCoordBuffer) this.gl.deleteBuffer(this.texCoordBuffer);
      if (this.program) this.gl.deleteProgram(this.program);
    }
  }
}
