import { ConsoleId } from '../../types/emulator';

export interface EmulatorControllerState {
  A: boolean;
  B: boolean;
  X: boolean;
  Y: boolean;
  UP: boolean;
  DOWN: boolean;
  LEFT: boolean;
  RIGHT: boolean;
  L1: boolean;
  R1: boolean;
  L2: boolean;
  R2: boolean;
  START: boolean;
  SELECT: boolean;
  HOME?: boolean;
}

export interface DiagnosticInfo {
  romName: string;
  romSize: string;
  console: string;
  mapper: number | string;
  cpuPc: string;
  cpuSp: string;
  cpuA: string;
  cpuX: string;
  cpuY: string;
  cpuStatus: string;
  frameCount: number;
  emulationSpeed: string;
  fps: number;
  audioBufferSize: number;
  controllerConnected: boolean;
  controllerButtons: string[];
  coreStatus: string;
  romLoadingStatus: string;
}

export interface RomValidationResult {
  valid: boolean;
  consoleId?: ConsoleId;
  title?: string;
  errorReason?: string;
  suggestedAction?: string;
  mapper?: number | string;
  prgSize?: number;
  chrSize?: number;
  ramSize?: number;
  mirroring?: string;
  battery?: boolean;
  region?: string;
  checksum?: number;
  isChecksumValid?: boolean;
}

export interface EmulatorCoreAdapter {
  id: string;
  name: string;
  consoleId: ConsoleId;
  version: string;

  initialize(): Promise<void>;
  validateROM(romData: Uint8Array, filename?: string): RomValidationResult;
  loadROM(romData: Uint8Array, filename?: string): Promise<boolean>;
  reset(): void;
  runFrame(): void;
  pause(): void;
  resume(): void;
  shutdown(): void;

  getVideoFrame(): Uint8ClampedArray | Uint8Array | HTMLCanvasElement;
  getVideoWidth(): number;
  getVideoHeight(): number;
  getAudioSamples?(): Float32Array | null;

  setButtonState?(player: number, button: string, pressed: boolean): void;
  setControllerState(player: number, state: EmulatorControllerState): void;

  createSaveState?(): Promise<Uint8Array | null> | Uint8Array | null;
  loadSaveState?(data: Uint8Array): Promise<boolean> | boolean;

  getFPS?(): number;
  getEmulationSpeed?(): string;
  getCoreName?(): string;
  getCoreVersion?(): string;
  getROMInfo?(): RomValidationResult | null;
  getDiagnostics?(): DiagnosticInfo;
}
