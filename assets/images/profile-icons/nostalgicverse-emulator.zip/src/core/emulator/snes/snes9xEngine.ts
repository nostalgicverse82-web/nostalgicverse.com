// @ts-ignore
import createSnes9xModule from './snes9xCore.js';

export interface Snes9xModuleInstance {
  _malloc(size: number): number;
  _free(ptr: number): void;
  _s9xwasm_setup(): number;
  _s9xwasm_load_rom(ptr: number, size: number): number;
  _s9xwasm_reset(): void;
  _s9xwasm_exec(): number;
  _s9xwasm_frame_rgba(): number;
  _s9xwasm_frame_width(): number;
  _s9xwasm_frame_height(): number;
  _s9xwasm_input(port: number, mask: number): void;
  _s9xwasm_audio_ptr(): number;
  _s9xwasm_audio_len(): number;
  _s9xwasm_state_size(): number;
  _s9xwasm_state_save(ptr: number): void;
  _s9xwasm_state_load(ptr: number): number;
  HEAPU8: Uint8Array;
  HEAP16: Int16Array;
}

let cachedModule: Snes9xModuleInstance | null = null;

export async function initSnes9xCore(): Promise<Snes9xModuleInstance> {
  if (cachedModule) return cachedModule;

  let wasmBinary: ArrayBuffer | undefined;
  try {
    const res = await fetch('/emulator/snes9x/snes9x.wasm');
    if (res.ok) {
      wasmBinary = await res.arrayBuffer();
    }
  } catch (err) {
    console.warn('Direct fetch of snes9x.wasm failed, falling back to locateFile', err);
  }

  const mod = (await (createSnes9xModule as any)({
    wasmBinary,
    locateFile: (path: string) => `/emulator/snes9x/${path}`
  })) as Snes9xModuleInstance;

  cachedModule = mod;
  return mod;
}
