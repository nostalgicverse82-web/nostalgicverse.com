import React, { useRef, useEffect } from 'react';

interface VideoWallpaperProps {
  videoUrl: string;
  muted?: boolean;
  volume?: number; // 0 to 100
  playbackRate?: number;
  opacity?: number;
  blur?: number;
  vignette?: boolean;
  isSuspended?: boolean;
}

export const VideoWallpaper: React.FC<VideoWallpaperProps> = ({
  videoUrl,
  muted = true,
  volume = 50,
  playbackRate = 1.0,
  opacity = 0.85,
  blur = 0,
  vignette = true,
  isSuspended = false
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    video.muted = muted;
    video.volume = Math.max(0, Math.min(1, volume / 100));
    video.playbackRate = playbackRate;

    if (isSuspended) {
      video.pause();
    } else {
      video.play().catch(() => {
        // Autoplay policy fallback: mute and retry
        video.muted = true;
        video.play().catch(() => {});
      });
    }
  }, [muted, volume, playbackRate, isSuspended, videoUrl]);

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden select-none z-0">
      <video
        ref={videoRef}
        key={videoUrl}
        src={videoUrl}
        autoPlay
        loop
        playsInline
        muted={muted}
        className="w-full h-full object-cover transition-opacity duration-1000 ease-out"
        style={{
          opacity,
          filter: blur > 0 ? `blur(${blur}px)` : undefined,
          transform: 'scale(1.04)'
        }}
      />

      {vignette && (
        <>
          <div className="absolute inset-0 bg-gradient-to-t from-[#05070c] via-transparent to-[#05070c]/60 pointer-events-none" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#05070c]/90 via-[#05070c]/30 to-transparent pointer-events-none" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_40%,rgba(5,7,12,0.85)_100%)] pointer-events-none" />
        </>
      )}
    </div>
  );
};
