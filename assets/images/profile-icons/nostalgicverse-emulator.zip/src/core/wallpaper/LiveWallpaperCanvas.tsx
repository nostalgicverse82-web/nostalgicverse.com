import React, { useRef, useEffect } from 'react';

interface LiveWallpaperCanvasProps {
  type: 'grid3d' | 'aurora' | 'crt' | 'stars';
  fps?: 30 | 60 | 'auto';
  isSuspended?: boolean;
}

export const LiveWallpaperCanvas: React.FC<LiveWallpaperCanvasProps> = ({
  type,
  fps = 60,
  isSuspended = false
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (isSuspended) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let frame = 0;
    let lastTime = performance.now();
    const frameInterval = fps === 30 ? 1000 / 30 : 1000 / 60;

    // Resize handling
    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    // Particle seed for aurora
    const particles = Array.from({ length: 45 }, () => ({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      radius: Math.random() * 3 + 1,
      speedX: (Math.random() - 0.5) * 0.4,
      speedY: -Math.random() * 0.6 - 0.2,
      opacity: Math.random() * 0.6 + 0.2,
      hue: Math.random() * 60 + 240
    }));

    const render = (now: number) => {
      const delta = now - lastTime;
      if (delta >= frameInterval) {
        lastTime = now - (delta % frameInterval);
        frame++;

        const w = canvas.width;
        const h = canvas.height;

        ctx.clearRect(0, 0, w, h);

        if (type === 'grid3d') {
          // 3D Perspective Synthwave Grid
          const horizon = h * 0.55;
          ctx.fillStyle = 'rgba(5, 7, 12, 0.95)';
          ctx.fillRect(0, 0, w, h);

          // Star dots in sky
          ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
          for (let i = 0; i < 30; i++) {
            const sx = (i * 137.5) % w;
            const sy = (i * 93.3) % horizon;
            ctx.fillRect(sx, sy, 1.5, 1.5);
          }

          // Horizon Sun Glow
          const sunGrad = ctx.createRadialGradient(w / 2, horizon, 10, w / 2, horizon, w * 0.45);
          sunGrad.addColorStop(0, 'rgba(6, 182, 212, 0.35)');
          sunGrad.addColorStop(0.5, 'rgba(99, 102, 241, 0.15)');
          sunGrad.addColorStop(1, 'transparent');
          ctx.fillStyle = sunGrad;
          ctx.fillRect(0, 0, w, h);

          // Grid Perspective Lines
          ctx.strokeStyle = 'rgba(6, 182, 212, 0.25)';
          ctx.lineWidth = 1;

          // Vertical converging lines
          for (let x = -w * 0.5; x <= w * 1.5; x += w / 12) {
            ctx.beginPath();
            ctx.moveTo(w / 2, horizon);
            ctx.lineTo(x, h);
            ctx.stroke();
          }

          // Moving horizontal lines
          const speed = 0.8;
          const gridOffset = (frame * speed) % 30;
          for (let y = horizon; y < h; y += (y - horizon + 10) * 0.2) {
            const currentY = y + gridOffset * ((y - horizon) / (h - horizon));
            if (currentY <= h) {
              ctx.beginPath();
              ctx.moveTo(0, currentY);
              ctx.lineTo(w, currentY);
              ctx.stroke();
            }
          }
        } else if (type === 'aurora') {
          // Floating Cosmic Dust Particles & Nebula Glow
          const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
          bgGrad.addColorStop(0, '#05070c');
          bgGrad.addColorStop(0.5, '#0b091a');
          bgGrad.addColorStop(1, '#05070c');
          ctx.fillStyle = bgGrad;
          ctx.fillRect(0, 0, w, h);

          // Moving Aurora waves
          const waveX = Math.sin(frame * 0.01) * 100;
          const aura = ctx.createRadialGradient(w * 0.5 + waveX, h * 0.4, 20, w * 0.5, h * 0.4, w * 0.6);
          aura.addColorStop(0, 'rgba(139, 92, 246, 0.25)');
          aura.addColorStop(0.5, 'rgba(6, 182, 212, 0.12)');
          aura.addColorStop(1, 'transparent');
          ctx.fillStyle = aura;
          ctx.fillRect(0, 0, w, h);

          // Render particles
          particles.forEach((p) => {
            p.y += p.speedY;
            p.x += p.speedX;
            if (p.y < 0) p.y = h;
            if (p.x < 0) p.x = w;
            if (p.x > w) p.x = 0;

            ctx.fillStyle = `hsla(${p.hue}, 80%, 70%, ${p.opacity})`;
            ctx.shadowColor = `hsl(${p.hue}, 80%, 60%)`;
            ctx.shadowBlur = 8;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            ctx.fill();
            ctx.shadowBlur = 0;
          });
        } else if (type === 'crt') {
          // Phosphor scanline luminescence
          ctx.fillStyle = '#05080c';
          ctx.fillRect(0, 0, w, h);

          const pulse = 0.15 + Math.sin(frame * 0.05) * 0.05;
          ctx.fillStyle = `rgba(16, 185, 129, ${pulse})`;
          ctx.fillRect(0, 0, w, h);

          // Raster scanlines
          ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
          for (let y = 0; y < h; y += 4) {
            ctx.fillRect(0, y, w, 2);
          }
        } else if (type === 'stars') {
          // Hyperspace Warp Starfield
          ctx.fillStyle = 'rgba(5, 7, 12, 0.25)';
          ctx.fillRect(0, 0, w, h);

          const cx = w / 2;
          const cy = h / 2;
          ctx.fillStyle = '#ffffff';

          for (let i = 0; i < 70; i++) {
            const angle = (i * 0.17) + (frame * 0.002);
            const dist = ((frame * 2.5 + i * 20) % (w * 0.8));
            const x = cx + Math.cos(angle) * dist;
            const y = cy + Math.sin(angle) * dist;
            const size = Math.max(1, (dist / (w * 0.4)) * 3.5);

            if (x >= 0 && x <= w && y >= 0 && y <= h) {
              ctx.beginPath();
              ctx.arc(x, y, size, 0, Math.PI * 2);
              ctx.fill();
            }
          }
        }
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, [type, fps, isSuspended]);

  if (isSuspended) return null;

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none z-0"
    />
  );
};
