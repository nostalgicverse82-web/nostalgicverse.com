export interface WallpaperItem {
  id: string;
  name: string;
  filename: string;
  type: 'static' | 'live' | 'video';
  liveType?: 'grid3d' | 'aurora' | 'crt' | 'stars';
  videoUrl?: string;
  themeColor: string;
  gradient: string;
  matchedGames?: string[];
  customUrl?: string;
}

export interface WallpaperSettings {
  mode: 'game-specific' | 'global' | 'live' | 'video';
  activeWallpaperId: string;
  liveWallpaperEnabled: boolean;
  liveWallpaperFps: 30 | 60 | 'auto';
  videoMuted: boolean;
  videoAutoplay: boolean;
}

export class WallpaperManager {
  private wallpapers: WallpaperItem[] = [];
  private settings: WallpaperSettings = {
    mode: 'game-specific',
    activeWallpaperId: 'sotc-epic',
    liveWallpaperEnabled: true,
    liveWallpaperFps: 60,
    videoMuted: true,
    videoAutoplay: true
  };

  private listeners: Set<(settings: WallpaperSettings) => void> = new Set();

  constructor() {
    this.loadManifest();
    this.loadSavedSettings();
  }

  private async loadManifest() {
    try {
      const res = await fetch('/wallpaper/wallpapers.json');
      if (res.ok) {
        this.wallpapers = await res.json();
      }
    } catch {
      this.wallpapers = [
        {
          id: 'sotc-epic',
          name: 'Shadow of the Colossus — Forbidden Lands',
          filename: 'shadow-of-the-colossus.jpg',
          type: 'static',
          themeColor: '#f59e0b',
          gradient: 'from-amber-950/90 via-stone-900/90 to-[#05070c]',
          matchedGames: ['ps2-sotc', 'Shadow of the Colossus']
        },
        {
          id: 'gow-spartan',
          name: 'God of War — Spartan Temple',
          filename: 'god-of-war.jpg',
          type: 'static',
          themeColor: '#ef4444',
          gradient: 'from-red-950/90 via-zinc-900/90 to-[#05070c]',
          matchedGames: ['psp-gows', 'God of War']
        },
        {
          id: 'mgs-shadow-moses',
          name: 'Metal Gear Solid — Shadow Moses Heliport',
          filename: 'metal-gear-solid.jpg',
          type: 'static',
          themeColor: '#10b981',
          gradient: 'from-emerald-950/90 via-neutral-900/90 to-[#05070c]',
          matchedGames: ['ps1-mgs', 'Metal Gear Solid']
        },
        {
          id: 'cyber-grid-live',
          name: 'Nostalgic 3D Synthwave Grid',
          filename: 'live-grid',
          type: 'live',
          liveType: 'grid3d',
          themeColor: '#06b6d4',
          gradient: 'from-cyan-950/90 via-slate-900/90 to-[#05070c]'
        },
        {
          id: 'aurora-particles-live',
          name: 'Cosmic Aurora Particles',
          filename: 'live-aurora',
          type: 'live',
          liveType: 'aurora',
          themeColor: '#8b5cf6',
          gradient: 'from-purple-950/90 via-slate-900/90 to-[#05070c]'
        }
      ];
    }
  }

  public getWallpapers(): WallpaperItem[] {
    return this.wallpapers;
  }

  public addUploadedWallpaper(wallpaper: WallpaperItem) {
    this.wallpapers = [wallpaper, ...this.wallpapers.filter(w => w.id !== wallpaper.id)];
    this.settings.activeWallpaperId = wallpaper.id;
    this.settings.mode = wallpaper.type === 'video' ? 'video' : wallpaper.type === 'live' ? 'live' : 'global';
    this.saveSettings();
    this.notify();
  }

  public getSettings(): WallpaperSettings {
    return this.settings;
  }

  public updateSettings(newSettings: Partial<WallpaperSettings>) {
    this.settings = { ...this.settings, ...newSettings };
    this.saveSettings();
    this.notify();
  }

  public getActiveWallpaperForGame(gameId?: string, gameTitle?: string, fallbackGradient?: string): WallpaperItem {
    if (this.settings.mode === 'video') {
      const vid = this.wallpapers.find(w => w.id === this.settings.activeWallpaperId && w.type === 'video');
      if (vid) return vid;
    }

    if (this.settings.mode === 'live' && this.settings.liveWallpaperEnabled) {
      const live = this.wallpapers.find(w => w.id === this.settings.activeWallpaperId && w.type === 'live') 
        || this.wallpapers.find(w => w.type === 'live');
      if (live) return live;
    }

    if (this.settings.mode === 'global') {
      const global = this.wallpapers.find(w => w.id === this.settings.activeWallpaperId);
      if (global) return global;
    }

    // Game-specific matching
    if (gameId || gameTitle) {
      const matched = this.wallpapers.find(w => {
        if (!w.matchedGames) return false;
        return w.matchedGames.some(g => 
          (gameId && g.toLowerCase() === gameId.toLowerCase()) || 
          (gameTitle && gameTitle.toLowerCase().includes(g.toLowerCase()))
        );
      });
      if (matched) return matched;
    }

    return this.wallpapers[0] || {
      id: 'default',
      name: 'NostalgicVerse Deep Void',
      filename: 'default.jpg',
      type: 'static',
      themeColor: '#06b6d4',
      gradient: fallbackGradient || 'from-cyan-950/80 via-slate-900/90 to-[#05070c]'
    };
  }

  public onChange(fn: (settings: WallpaperSettings) => void) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private notify() {
    this.listeners.forEach(fn => fn(this.settings));
  }

  private saveSettings() {
    try {
      localStorage.setItem('nv_wallpaper_settings', JSON.stringify(this.settings));
    } catch {}
  }

  private loadSavedSettings() {
    try {
      const s = localStorage.getItem('nv_wallpaper_settings');
      if (s) {
        this.settings = { ...this.settings, ...JSON.parse(s) };
      }
    } catch {}
  }
}

export const wallpaperManager = new WallpaperManager();
