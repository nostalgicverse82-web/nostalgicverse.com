import React from 'react';
import { useConsoleOS } from '../../context/ConsoleOSContext';
import { LiveWallpaperCanvas } from './LiveWallpaperCanvas';
import { VideoWallpaper } from './VideoWallpaper';
import { GameItem } from '../../types/emulator';

interface ConsoleWallpaperLayerProps {
  focusedGame?: GameItem | null;
}

export const ConsoleWallpaperLayer: React.FC<ConsoleWallpaperLayerProps> = ({ focusedGame }) => {
  const { wallpaperSettings, activeWallpaper } = useConsoleOS();

  // 1. Live Video Wallpaper
  if (wallpaperSettings.mode === 'video' || (activeWallpaper && activeWallpaper.type === 'video')) {
    const videoUrl = activeWallpaper?.videoUrl || 'https://assets.mixkit.co/videos/preview/mixkit-retro-futuristic-wireframe-grid-tunnel-42777-large.mp4';
    return (
      <VideoWallpaper
        videoUrl={videoUrl}
        muted={wallpaperSettings.videoMuted}
        volume={50}
        opacity={0.85}
        vignette={true}
      />
    );
  }

  // 2. Interactive Procedural Live Canvas Wallpaper
  if (wallpaperSettings.mode === 'live' && activeWallpaper?.liveType) {
    return (
      <LiveWallpaperCanvas
        type={activeWallpaper.liveType}
        fps={wallpaperSettings.liveWallpaperFps}
      />
    );
  }

  // 3. Static High-Resolution Artwork / Gradient
  const gradient = activeWallpaper?.gradient || focusedGame?.bannerGradient || 'from-cyan-950/90 via-slate-900/90 to-[#05070c]';
  const customUrl = activeWallpaper?.customUrl;

  return (
    <div className="absolute inset-0 pointer-events-none transition-all duration-700 ease-out overflow-hidden z-0">
      {customUrl ? (
        <img
          src={customUrl}
          alt="Wallpaper"
          className="w-full h-full object-cover transition-all duration-1000 ease-out scale-105 filter blur-xs"
        />
      ) : (
        <div className={`w-full h-full bg-gradient-to-tr ${gradient} opacity-90 transition-all duration-1000 ease-out scale-105 filter blur-xs`} />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-[#05070c] via-[#05070c]/50 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#05070c]/90 via-[#05070c]/40 to-transparent" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,rgba(0,229,255,0.06),transparent_60%)]" />
    </div>
  );
};
