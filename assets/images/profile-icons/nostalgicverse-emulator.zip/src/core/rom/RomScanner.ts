import { GameItem, ConsoleId } from '../../types/emulator';
import JSZip from 'jszip';

export interface ScannedRomInfo {
  valid: boolean;
  consoleId: ConsoleId;
  title: string;
  fileSize: string;
  format: string;
  mapper?: number | string;
  data: Uint8Array;
  errorReason?: string;
}

export class RomScanner {
  public async parseRomAsync(filename: string, buffer: ArrayBuffer): Promise<ScannedRomInfo> {
    const ext = filename.split('.').pop()?.toLowerCase() || '';

    // Handle ZIP archive extraction (Section 4)
    if (ext === 'zip') {
      try {
        const zip = await JSZip.loadAsync(buffer);
        const supportedExts = ['nes', 'unf', 'unif', 'sfc', 'smc', 'swc', 'fig', 'gb', 'gbc', 'gba'];
        let targetEntry: JSZip.JSZipObject | null = null;
        let innerFilename = '';

        zip.forEach((path, entry) => {
          if (!entry.dir && !targetEntry) {
            const innerExt = path.split('.').pop()?.toLowerCase() || '';
            if (supportedExts.includes(innerExt)) {
              targetEntry = entry;
              innerFilename = path.split('/').pop() || path;
            }
          }
        });

        if (targetEntry) {
          const extractedBuf = await (targetEntry as JSZip.JSZipObject).async('arraybuffer');
          return this.parseRom(innerFilename, extractedBuf);
        } else {
          return {
            valid: false,
            consoleId: 'nes',
            title: filename,
            fileSize: `${(buffer.byteLength / 1024).toFixed(1)} KB`,
            format: '.zip',
            data: new Uint8Array(buffer),
            errorReason: 'No supported ROM found inside the ZIP archive (.nes, .sfc, .smc, .gb, .gbc, .gba).'
          };
        }
      } catch (err: any) {
        return {
          valid: false,
          consoleId: 'nes',
          title: filename,
          fileSize: `${(buffer.byteLength / 1024).toFixed(1)} KB`,
          format: '.zip',
          data: new Uint8Array(buffer),
          errorReason: `Corrupted ZIP file: ${err?.message || 'Unable to decompress archive'}`
        };
      }
    }

    return this.parseRom(filename, buffer);
  }

  public parseRom(filename: string, buffer: ArrayBuffer): ScannedRomInfo {
    const data = new Uint8Array(buffer);
    const ext = filename.split('.').pop()?.toLowerCase() || '';

    const sizeStr = buffer.byteLength > 1024 * 1024 
      ? `${(buffer.byteLength / (1024 * 1024)).toFixed(2)} MB`
      : `${(buffer.byteLength / 1024).toFixed(1)} KB`;

    // 1. Binary Detection for NES: 'NES\x1a' (0x4E, 0x45, 0x53, 0x1A)
    const isNesMagic = data.length > 16 && 
      data[0] === 0x4e && data[1] === 0x45 && data[2] === 0x53 && data[3] === 0x1a;

    if (isNesMagic || ext === 'nes' || ext === 'unf' || ext === 'unif') {
      const mapper = isNesMagic ? (((data[6] >> 4) & 0x0f) | (data[7] & 0xf0)) : 0;
      const cleanTitle = filename.replace(/\.(nes|unf|unif)$/i, '').replace(/[\(\[\_].*?[\)\]\_]/g, '').trim();

      return {
        valid: isNesMagic,
        consoleId: 'nes',
        title: cleanTitle || 'NES Cartridge',
        fileSize: sizeStr,
        format: `.${ext || 'nes'}`,
        mapper: `Mapper #${mapper}`,
        data,
        errorReason: isNesMagic ? undefined : 'Invalid NES header: Missing "NES\\x1a" signature.'
      };
    }

    // 2. Binary Detection for SNES (.sfc, .smc, .swc, .fig)
    // Check LoROM ($7FC0) or HiROM ($FFC0)
    const hasCopier = data.length % 1024 === 512;
    const baseOffset = hasCopier ? 512 : 0;
    let snesTitle = '';
    let isSnes = false;

    if (data.length >= baseOffset + 0x7fc0 + 32) {
      // Check LoROM checksum complement: csum + comp === 0xffff
      const loCsum = (data[baseOffset + 0x7fc0 + 0x1f] << 8) | data[baseOffset + 0x7fc0 + 0x1e];
      const loComp = (data[baseOffset + 0x7fc0 + 0x1d] << 8) | data[baseOffset + 0x7fc0 + 0x1c];
      if ((loCsum + loComp) === 0xffff) {
        isSnes = true;
        for (let i = 0; i < 21; i++) {
          const ch = data[baseOffset + 0x7fc0 + i];
          if (ch >= 32 && ch <= 126) snesTitle += String.fromCharCode(ch);
        }
      }
    }

    if (!isSnes && data.length >= baseOffset + 0xffc0 + 32) {
      // Check HiROM checksum complement
      const hiCsum = (data[baseOffset + 0xffc0 + 0x1f] << 8) | data[baseOffset + 0xffc0 + 0x1e];
      const hiComp = (data[baseOffset + 0xffc0 + 0x1d] << 8) | data[baseOffset + 0xffc0 + 0x1c];
      if ((hiCsum + hiComp) === 0xffff) {
        isSnes = true;
        for (let i = 0; i < 21; i++) {
          const ch = data[baseOffset + 0xffc0 + i];
          if (ch >= 32 && ch <= 126) snesTitle += String.fromCharCode(ch);
        }
      }
    }

    if (isSnes || ['sfc', 'smc', 'swc', 'fig'].includes(ext)) {
      const cleanTitle = snesTitle.trim() || 
        filename.replace(/\.(sfc|smc|swc|fig)$/i, '').replace(/[\(\[\_].*?[\)\]\_]/g, '').trim();

      return {
        valid: data.length >= 32768,
        consoleId: 'snes',
        title: cleanTitle || 'Super Nintendo Cartridge',
        fileSize: sizeStr,
        format: `.${ext || 'sfc'}`,
        data,
        errorReason: data.length >= 32768 ? undefined : 'File too small for SNES cartridge (< 32KB).'
      };
    }

    // 3. Binary Detection for GB / GBC (.gb, .gbc, .dmg, .cgb)
    let isGb = false;
    let isGbc = false;
    let gbTitle = '';

    if (data.length >= 0x150) {
      // Check Nintendo Logo at 0x0104..0x0133
      if (data[0x0104] === 0xce && data[0x0105] === 0xed && data[0x0106] === 0x66 && data[0x0107] === 0x66) {
        isGb = true;
        for (let i = 0x0134; i <= 0x0142; i++) {
          const byte = data[i];
          if (byte >= 32 && byte <= 126) gbTitle += String.fromCharCode(byte);
        }
        const cgbFlag = data[0x0143];
        isGbc = (cgbFlag === 0x80 || cgbFlag === 0xc0);
      }
    }

    if (isGb || ['gb', 'gbc', 'dmg', 'cgb'].includes(ext)) {
      const cleanTitle = gbTitle.trim() || filename.replace(/\.(gb|gbc|dmg|cgb)$/i, '').replace(/[\(\[\_].*?[\)\]\_]/g, '').trim();
      const detectedConsole: ConsoleId = (isGbc || ext === 'gbc' || ext === 'cgb') ? 'gbc' : 'gb';
      return {
        valid: data.length >= 32768,
        consoleId: detectedConsole,
        title: cleanTitle || (detectedConsole === 'gbc' ? 'Game Boy Color Cartridge' : 'Game Boy Cartridge'),
        fileSize: sizeStr,
        format: `.${ext || (detectedConsole === 'gbc' ? 'gbc' : 'gb')}`,
        data,
        errorReason: data.length >= 32768 ? undefined : 'Cartridge size is too small (< 32KB).'
      };
    }

    // 4. Binary Detection for GBA (.gba, .agb, .bin)
    let isGba = false;
    let gbaTitle = '';
    let gbaCode = '';

    if (data.length >= 0xc0) {
      // Fixed value 0x96 at offset 0x00B2
      if (data[0x00b2] === 0x96) {
        isGba = true;
        for (let i = 0x00a0; i <= 0x00ab; i++) {
          const byte = data[i];
          if (byte >= 32 && byte <= 126) gbaTitle += String.fromCharCode(byte);
        }
        for (let i = 0x00ac; i <= 0x00af; i++) {
          const byte = data[i];
          if (byte >= 32 && byte <= 126) gbaCode += String.fromCharCode(byte);
        }
      }
    }

    if (isGba || ['gba', 'agb'].includes(ext)) {
      const cleanTitle = gbaTitle.trim() || filename.replace(/\.(gba|agb)$/i, '').replace(/[\(\[\_].*?[\)\]\_]/g, '').trim();
      return {
        valid: data.length >= 32768,
        consoleId: 'gba',
        title: cleanTitle || 'Game Boy Advance Cartridge',
        fileSize: sizeStr,
        format: `.${ext || 'gba'}`,
        mapper: gbaCode ? `Code: ${gbaCode}` : undefined,
        data,
        errorReason: data.length >= 32768 ? undefined : 'Cartridge size is too small for GBA (< 32KB).'
      };
    }

    // 5. Fallback for other unrecognized binary dumps
    const cleanTitle = filename.replace(/\.[^/.]+$/, '').trim();

    return {
      valid: true,
      consoleId: 'nes',
      title: cleanTitle,
      fileSize: sizeStr,
      format: `.${ext}`,
      data
    };
  }

  public createGameItemFromScanned(info: ScannedRomInfo): GameItem {
    const id = `user-rom-${info.consoleId}-${Date.now()}`;
    const gradients: Record<ConsoleId, { cover: string; banner: string; color: string }> = {
      nes: { cover: 'from-rose-700 to-stone-900', banner: 'from-rose-950/90 via-stone-900/90 to-[#05070c]', color: '#f43f5e' },
      snes: { cover: 'from-pink-700 to-purple-950', banner: 'from-pink-950/90 via-purple-900/90 to-[#05070c]', color: '#ec4899' },
      gb: { cover: 'from-lime-700 to-slate-950', banner: 'from-lime-950/90 via-slate-900/90 to-[#05070c]', color: '#84cc16' },
      gbc: { cover: 'from-amber-700 to-stone-950', banner: 'from-amber-950/90 via-stone-900/90 to-[#05070c]', color: '#f59e0b' },
      gba: { cover: 'from-purple-700 to-slate-950', banner: 'from-purple-950/90 via-slate-900/90 to-[#05070c]', color: '#a855f7' },
      nds: { cover: 'from-cyan-700 to-slate-950', banner: 'from-cyan-950/90 via-slate-900/90 to-[#05070c]', color: '#06b6d4' },
      n64: { cover: 'from-emerald-700 to-stone-950', banner: 'from-emerald-950/90 via-stone-900/90 to-[#05070c]', color: '#10b981' },
      ps1: { cover: 'from-indigo-700 to-neutral-950', banner: 'from-indigo-950/90 via-neutral-900/90 to-[#05070c]', color: '#6366f1' },
      psp: { cover: 'from-blue-700 to-slate-950', banner: 'from-blue-950/90 via-slate-900/90 to-[#05070c]', color: '#3b82f6' },
      '3ds': { cover: 'from-red-700 to-slate-950', banner: 'from-red-950/90 via-slate-900/90 to-[#05070c]', color: '#ef4444' },
      ps2: { cover: 'from-blue-800 to-indigo-950', banner: 'from-blue-950/90 via-indigo-950/90 to-[#05070c]', color: '#00439c' },
      ps3: { cover: 'from-fuchsia-800 to-neutral-950', banner: 'from-fuchsia-950/90 via-neutral-900/90 to-[#05070c]', color: '#d946ef' }
    };

    const g = gradients[info.consoleId] || gradients.nes;

    return {
      id,
      title: info.title,
      subtitle: `Imported Cartridge · ${info.format}`,
      consoleId: info.consoleId,
      developer: 'Authentic Cartridge',
      publisher: 'User ROM Library',
      releaseYear: 2026,
      genre: 'Retro Game',
      region: 'World',
      fileFormat: info.format,
      fileSize: info.fileSize,
      playtimeMinutes: 0,
      isFavorite: false,
      targetFps: 60,
      coverGradient: g.cover,
      bannerGradient: g.banner,
      heroColor: g.color,
      description: `Locally loaded ROM image for ${info.consoleId.toUpperCase()}. Executed directly by the authentic hardware core.`,
      compatibilityTier: 'perfect',
      saveStateCount: 0
    };
  }
}

export const romScanner = new RomScanner();
