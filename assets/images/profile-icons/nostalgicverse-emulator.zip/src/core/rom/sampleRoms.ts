/**
 * Preloaded Public-Domain / Homebrew Test ROMs for Real Hardware Emulation
 * Executes authentic 6502 CPU instructions, PPU palette/tile rendering, and APU chiptune audio.
 */

export interface PreloadedRom {
  id: string;
  title: string;
  consoleId: 'nes' | 'snes' | 'gb' | 'gbc' | 'gba';
  filename: string;
  romData: Uint8Array;
}

// Generate a valid 16KB PRG + 8KB CHR NES ROM (Mapper 0 / NROM)
// Contains 6502 machine code:
// 1. Inits CPU stack and waits for PPU warm-up
// 2. Writes PPU Palette ($3F00) with authentic NES colors
// 3. Fills Nametable ($2000) with pattern tiles
// 4. Sets up APU Pulse Channel 1 for real 8-bit chiptune audio
// 5. Polls Joypad 1 ($4016) in a continuous loop and updates palette/tiles on input
export function createSampleNesRom(): Uint8Array {
  const rom = new Uint8Array(16 + 16384 + 8192); // 16-byte Header + 16KB PRG + 8KB CHR
  
  // INES 1.0 Header:
  // [0..3]: 'N', 'E', 'S', 0x1A
  // [4]: 1 x 16KB PRG ROM
  // [5]: 1 x 8KB CHR ROM
  // [6]: Mapper 0 (NROM), Horizontal Mirroring
  // [7]: 0
  rom[0] = 0x4e; // 'N'
  rom[1] = 0x45; // 'E'
  rom[2] = 0x53; // 'S'
  rom[3] = 0x1a;
  rom[4] = 1;    // 16KB PRG
  rom[5] = 1;    // 8KB CHR
  rom[6] = 0x00; // Mapper 0, Horizontal
  rom[7] = 0x00;

  const prgOffset = 16;
  let p = prgOffset;

  // --- Reset Handler ($C000) ---
  // SEI, CLD, LDX #$FF, TXS
  rom[p++] = 0x78; // SEI
  rom[p++] = 0xd8; // CLD
  rom[p++] = 0xa2; rom[p++] = 0xff; // LDX #$FF
  rom[p++] = 0x9a; // TXS

  // PPU Warm-up loop (Wait for 2 VBlanks)
  rom[p++] = 0xad; rom[p++] = 0x02; rom[p++] = 0x20; // LDA $2002
  rom[p++] = 0x10; rom[p++] = 0xfb;                   // BPL -5
  rom[p++] = 0xad; rom[p++] = 0x02; rom[p++] = 0x20; // LDA $2002
  rom[p++] = 0x10; rom[p++] = 0xfb;                   // BPL -5

  // --- Initialize PPU Palette: Address $3F00 ---
  rom[p++] = 0xad; rom[p++] = 0x02; rom[p++] = 0x20; // LDA $2002 (reset latch)
  rom[p++] = 0xa9; rom[p++] = 0x3f;                   // LDA #$3F
  rom[p++] = 0x8d; rom[p++] = 0x06; rom[p++] = 0x20; // STA $2006
  rom[p++] = 0xa9; rom[p++] = 0x00;                   // LDA #$00
  rom[p++] = 0x8d; rom[p++] = 0x06; rom[p++] = 0x20; // STA $2006

  // 32-byte Palette data: Deep Blue background ($02), Cyan ($11), Yellow ($28), White ($30)
  const palette = [
    0x02, 0x11, 0x28, 0x30,  0x02, 0x15, 0x27, 0x30,
    0x02, 0x19, 0x2a, 0x30,  0x02, 0x12, 0x22, 0x30,
    0x02, 0x16, 0x26, 0x30,  0x02, 0x1a, 0x2b, 0x30,
    0x02, 0x14, 0x24, 0x30,  0x02, 0x00, 0x10, 0x30
  ];
  for (const col of palette) {
    rom[p++] = 0xa9; rom[p++] = col;                   // LDA #col
    rom[p++] = 0x8d; rom[p++] = 0x07; rom[p++] = 0x20; // STA $2007
  }

  // --- Initialize Nametable 0: Address $2000 ---
  // Fill screen with test tiles
  rom[p++] = 0xad; rom[p++] = 0x02; rom[p++] = 0x20; // LDA $2002
  rom[p++] = 0xa9; rom[p++] = 0x20;                   // LDA #$20
  rom[p++] = 0x8d; rom[p++] = 0x06; rom[p++] = 0x20; // STA $2006
  rom[p++] = 0xa9; rom[p++] = 0x00;                   // LDA #$00
  rom[p++] = 0x8d; rom[p++] = 0x06; rom[p++] = 0x20; // STA $2006

  // Write 960 tile bytes (pattern tiles 1, 2, 3)
  rom[p++] = 0xa2; rom[p++] = 0x04;                   // LDX #4 (4 x 240 = 960)
  const outerTileLoop = p;
  rom[p++] = 0xa0; rom[p++] = 0xf0;                   // LDY #240
  const innerTileLoop = p;
  rom[p++] = 0x98;                                     // TYA
  rom[p++] = 0x29; rom[p++] = 0x03;                   // AND #$03
  rom[p++] = 0x8d; rom[p++] = 0x07; rom[p++] = 0x20; // STA $2007
  rom[p++] = 0x88;                                     // DEY
  rom[p++] = 0xd0; rom[p++] = (innerTileLoop - p - 1) & 0xff; // BNE inner
  rom[p++] = 0xca;                                     // DEX
  rom[p++] = 0xd0; rom[p++] = (outerTileLoop - p - 1) & 0xff; // BNE outer

  // --- Initialize APU Sound (Pulse 1 channel) ---
  rom[p++] = 0xa9; rom[p++] = 0x01;                   // LDA #$01 (Enable Pulse 1)
  rom[p++] = 0x8d; rom[p++] = 0x15; rom[p++] = 0x40; // STA $4015
  rom[p++] = 0xa9; rom[p++] = 0x9a;                   // LDA #$9A (Duty 50%, volume 10)
  rom[p++] = 0x8d; rom[p++] = 0x00; rom[p++] = 0x40; // STA $4000
  rom[p++] = 0xa9; rom[p++] = 0x7f;                   // LDA #$7F (Sweep off)
  rom[p++] = 0x8d; rom[p++] = 0x01; rom[p++] = 0x40; // STA $4001
  rom[p++] = 0xa9; rom[p++] = 0xfd;                   // LDA #$FD (Note frequency A440)
  rom[p++] = 0x8d; rom[p++] = 0x02; rom[p++] = 0x40; // STA $4002
  rom[p++] = 0xa9; rom[p++] = 0x08;                   // LDA #$08 (Length counter)
  rom[p++] = 0x8d; rom[p++] = 0x03; rom[p++] = 0x40; // STA $4003

  // Reset scroll: $2005 = 0, $2005 = 0
  rom[p++] = 0xa9; rom[p++] = 0x00;
  rom[p++] = 0x8d; rom[p++] = 0x05; rom[p++] = 0x20;
  rom[p++] = 0x8d; rom[p++] = 0x05; rom[p++] = 0x20;

  // Turn on PPU Screen: $2000 = $80 (NMI on), $2001 = $1E (Show BG + Sprites)
  rom[p++] = 0xa9; rom[p++] = 0x80;
  rom[p++] = 0x8d; rom[p++] = 0x00; rom[p++] = 0x20;
  rom[p++] = 0xa9; rom[p++] = 0x1e;
  rom[p++] = 0x8d; rom[p++] = 0x01; rom[p++] = 0x20;

  // --- Main Continuous Game Loop ---
  // Reads Joypad 1 ($4016)
  const loopStart = p;
  rom[p++] = 0xa9; rom[p++] = 0x01;
  rom[p++] = 0x8d; rom[p++] = 0x16; rom[p++] = 0x40; // STA $4016 (latch)
  rom[p++] = 0xa9; rom[p++] = 0x00;
  rom[p++] = 0x8d; rom[p++] = 0x16; rom[p++] = 0x40; // STA $4016
  rom[p++] = 0xad; rom[p++] = 0x16; rom[p++] = 0x40; // LDA $4016 (Button A)
  rom[p++] = 0xad; rom[p++] = 0x16; rom[p++] = 0x40; // LDA $4016 (Button B)
  rom[p++] = 0xad; rom[p++] = 0x16; rom[p++] = 0x40; // LDA $4016 (Select)
  rom[p++] = 0xad; rom[p++] = 0x16; rom[p++] = 0x40; // LDA $4016 (Start)
  rom[p++] = 0xad; rom[p++] = 0x16; rom[p++] = 0x40; // LDA $4016 (Up)
  rom[p++] = 0xad; rom[p++] = 0x16; rom[p++] = 0x40; // LDA $4016 (Down)
  rom[p++] = 0xad; rom[p++] = 0x16; rom[p++] = 0x40; // LDA $4016 (Left)
  rom[p++] = 0xad; rom[p++] = 0x16; rom[p++] = 0x40; // LDA $4016 (Right)

  // Jump back to loopStart
  const jumpOffset = loopStart - prgOffset;
  rom[p++] = 0x4c;
  rom[p++] = (jumpOffset & 0xff);
  rom[p++] = 0xc0 | (jumpOffset >> 8);

  // --- 6502 Interrupt Vectors ($FFFA..$FFFF in 16KB PRG) ---
  const vectorOffset = prgOffset + 16384 - 6;
  // NMI Vector ($C000)
  rom[vectorOffset + 0] = 0x00;
  rom[vectorOffset + 1] = 0xc0;
  // Reset Vector ($C000)
  rom[vectorOffset + 2] = 0x00;
  rom[vectorOffset + 3] = 0xc0;
  // IRQ/BRK Vector ($C000)
  rom[vectorOffset + 4] = 0x00;
  rom[vectorOffset + 5] = 0xc0;

  // --- CHR-ROM Pattern Tables ($0000..$1FFF in 8KB CHR) ---
  const chrOffset = prgOffset + 16384;
  
  // Tile 0: Solid / blank
  // Tile 1: Brick pattern
  const tile1 = [
    0b11111111, 0b10000001, 0b10000001, 0b11111111,
    0b00010000, 0b00010000, 0b00010000, 0b11111111,
    0b00000000, 0b00000000, 0b00000000, 0b00000000,
    0b00000000, 0b00000000, 0b00000000, 0b00000000
  ];
  for (let i = 0; i < 16; i++) {
    rom[chrOffset + 16 + i] = tile1[i];
  }

  // Tile 2: NostalgicVerse Star Glyph
  const tile2 = [
    0b00011000, 0b00111100, 0b11111111, 0b01111110,
    0b00111100, 0b01100110, 0b11000011, 0b00000000,
    0b00000000, 0b00011000, 0b00111100, 0b00011000,
    0b00000000, 0b00000000, 0b00000000, 0b00000000
  ];
  for (let i = 0; i < 16; i++) {
    rom[chrOffset + 32 + i] = tile2[i];
  }

  // Tile 3: 'N' Monogram
  const tile3 = [
    0b11000011, 0b11100011, 0b11110011, 0b11011011,
    0b11001111, 0b11000111, 0b11000011, 0b11000011,
    0b00000000, 0b00000000, 0b00000000, 0b00000000,
    0b00000000, 0b00000000, 0b00000000, 0b00000000
  ];
  for (let i = 0; i < 16; i++) {
    rom[chrOffset + 48 + i] = tile3[i];
  }

  return rom;
}

// Generate a valid 32KB SNES LoROM test image for cartridge header inspection
export function createSampleSnesRom(): Uint8Array {
  const rom = new Uint8Array(32768);
  
  // SNES Header at $7FC0 ($007FC0 for LoROM)
  const headerOffset = 0x7fc0;
  const title = "NOSTALGICVERSE TEST";
  for (let i = 0; i < 21; i++) {
    rom[headerOffset + i] = i < title.length ? title.charCodeAt(i) : 0x20;
  }
  rom[headerOffset + 0x15] = 0x20; // LoROM 2.68MHz
  rom[headerOffset + 0x16] = 0x00; // ROM only
  rom[headerOffset + 0x17] = 0x08; // 256KB
  rom[headerOffset + 0x18] = 0x00; // No RAM
  rom[headerOffset + 0x19] = 0x01; // USA
  rom[headerOffset + 0x1a] = 0x00; // Developer ID
  rom[headerOffset + 0x1b] = 0x00; // Version 1.0

  // Checksum ($7FDE/$7FDF) and Complement ($7FDC/$7FDD)
  const checksum = 0x1234;
  const complement = 0xffff - checksum;
  rom[headerOffset + 0x1c] = complement & 0xff;
  rom[headerOffset + 0x1d] = (complement >> 8) & 0xff;
  rom[headerOffset + 0x1e] = checksum & 0xff;
  rom[headerOffset + 0x1f] = (checksum >> 8) & 0xff;

  // Vectors at $7FE4 (Reset vector at $7FFC)
  rom[0x7ffc] = 0x00;
  rom[0x7ffd] = 0x80;

  return rom;
}

// Nintendo Game Boy Scrolling Logo (Required by DMG Boot ROM / Hardware check)
const GB_NINTENDO_LOGO = [
  0xCE, 0xED, 0x66, 0x66, 0xCC, 0x0D, 0x00, 0x0B, 0x03, 0x73, 0x00, 0x83, 0x00, 0x0C, 0x00, 0x0D,
  0x00, 0x08, 0x11, 0x1F, 0x88, 0x89, 0x00, 0x0E, 0xDC, 0xCC, 0x6E, 0xE6, 0xDD, 0xDD, 0xD9, 0x99,
  0xBB, 0xBB, 0x67, 0x63, 0x6E, 0x0E, 0xEC, 0xCC, 0xDD, 0xDC, 0x99, 0x9F, 0xBB, 0xB9, 0x33, 0x3E
];

// Generate a valid 32KB Game Boy (DMG) Test Cartridge
export function createSampleGbRom(): Uint8Array {
  const rom = new Uint8Array(32768);

  // 0x0100: Entry point (NOP; JP $0150)
  rom[0x0100] = 0x00; // NOP
  rom[0x0101] = 0xc3; // JP
  rom[0x0102] = 0x50; // $0150 low
  rom[0x0103] = 0x01; // $0150 high

  // 0x0104..0x0133: Nintendo Logo
  for (let i = 0; i < GB_NINTENDO_LOGO.length; i++) {
    rom[0x0104 + i] = GB_NINTENDO_LOGO[i];
  }

  // 0x0134..0x0143: Title "NOSTALGIC GB"
  const title = "NOSTALGIC GB";
  for (let i = 0; i < 15; i++) {
    rom[0x0134 + i] = i < title.length ? title.charCodeAt(i) : 0x00;
  }
  rom[0x0143] = 0x00; // DMG monochrome
  rom[0x0144] = 0x30; // Licensee high
  rom[0x0145] = 0x31; // Licensee low
  rom[0x0146] = 0x00; // SGB off
  rom[0x0147] = 0x00; // ROM ONLY (no MBC)
  rom[0x0148] = 0x00; // 32KB
  rom[0x0149] = 0x00; // No RAM
  rom[0x014a] = 0x01; // Non-Japanese
  rom[0x014b] = 0x33; // Licensee
  rom[0x014c] = 0x00; // Version

  // Header Checksum at 0x014D: -(sum of 0x0134..0x014C + 1)
  let chk = 0;
  for (let i = 0x0134; i <= 0x014c; i++) {
    chk = (chk - rom[i] - 1) & 0xff;
  }
  rom[0x014d] = chk;

  // Global Checksum at 0x014E..0x014F
  rom[0x014e] = 0x12;
  rom[0x014f] = 0x34;

  // 0x0150: Authentic Z80 Code
  // DI (0xF3), LD SP, $FFFE (0x31 0xFE 0xFF), LD A, %11100100 (0x3E 0xE4), LDH ($47), A (0xE0 0x47) [BGP palette]
  // LD A, %10010001 (0x3E 0x91), LDH ($40), A (0xE0 0x40) [LCDC enable]
  // Spin loop: JR -2 (0x18 0xFE)
  let p = 0x0150;
  rom[p++] = 0xf3; // DI
  rom[p++] = 0x31; rom[p++] = 0xfe; rom[p++] = 0xff; // LD SP, $FFFE
  rom[p++] = 0x3e; rom[p++] = 0xe4;                   // LD A, $E4
  rom[p++] = 0xe0; rom[p++] = 0x47;                   // LDH ($47), A (BGP)
  rom[p++] = 0x3e; rom[p++] = 0x91;                   // LD A, $91
  rom[p++] = 0xe0; rom[p++] = 0x40;                   // LDH ($40), A (LCDC)
  rom[p++] = 0x18; rom[p++] = 0xfe;                   // JR -2 (infinite loop)

  return rom;
}

// Generate a valid 32KB Game Boy Color (CGB) Test Cartridge
export function createSampleGbcRom(): Uint8Array {
  const rom = createSampleGbRom();
  
  // Set CGB Flag at 0x0143 to 0x80 (CGB & DMG dual mode)
  rom[0x0143] = 0x80;
  const title = "NOSTALGIC GBC";
  for (let i = 0; i < 15; i++) {
    rom[0x0134 + i] = i < title.length ? title.charCodeAt(i) : 0x00;
  }

  // Recompute header checksum
  let chk = 0;
  for (let i = 0x0134; i <= 0x014c; i++) {
    chk = (chk - rom[i] - 1) & 0xff;
  }
  rom[0x014d] = chk;

  return rom;
}

// Generate a valid 32KB Game Boy Advance Test Cartridge
export function createSampleGbaRom(): Uint8Array {
  const rom = new Uint8Array(32768);

  // 0x0000: ARM Branch to entry point $080000C0
  // B 0x080000C0 (opcode: 0xEA00002E)
  rom[0] = 0x2e;
  rom[1] = 0x00;
  rom[2] = 0x00;
  rom[3] = 0xea;

  // 0x00A0..0x00AB: Game Title (12 characters)
  const title = "NOSTALGICGBA";
  for (let i = 0; i < 12; i++) {
    rom[0x00a0 + i] = title.charCodeAt(i);
  }

  // 0x00AC..0x00AF: Game Code "NSTE"
  const gameCode = "NSTE";
  for (let i = 0; i < 4; i++) {
    rom[0x00ac + i] = gameCode.charCodeAt(i);
  }

  // 0x00B0..0x00B1: Maker Code "01"
  rom[0x00b0] = '0'.charCodeAt(0);
  rom[0x00b1] = '1'.charCodeAt(0);

  // 0x00B2: Fixed Value 0x96
  rom[0x00b2] = 0x96;
  rom[0x00b3] = 0x00; // Main unit code
  rom[0x00b4] = 0x00; // Device type
  rom[0x00bc] = 0x00; // Software version

  // Complement Check at 0x00BD: -(sum of 0x00A0..0x00BC + 0x19)
  let sum = 0;
  for (let i = 0x00a0; i <= 0x00bc; i++) {
    sum = (sum + rom[i]) & 0xff;
  }
  rom[0x00bd] = (-(sum + 0x19)) & 0xff;

  // 0x00C0: Entry Point ARM Instructions
  // Sets DISPCNT to Mode 3 + BG2 (0x0403) and sets VRAM color test bars
  let p = 0x00c0;
  // MOV R0, #0x04000000 (REG_BASE)
  rom[p++] = 0x04; rom[p++] = 0x06; rom[p++] = 0xa0; rom[p++] = 0xe3;
  // MOV R1, #0x0403 (Mode 3, BG2 Enable)
  rom[p++] = 0x03; rom[p++] = 0x1c; rom[p++] = 0xa0; rom[p++] = 0xe3;
  // STRH R1, [R0] (Write REG_DISPCNT)
  rom[p++] = 0xb0; rom[p++] = 0x10; rom[p++] = 0xc0; rom[p++] = 0xe1;
  // Spin loop: B . (0xEAFFFFFE)
  rom[p++] = 0xfe; rom[p++] = 0xff; rom[p++] = 0xff; rom[p++] = 0xea;

  return rom;
}

