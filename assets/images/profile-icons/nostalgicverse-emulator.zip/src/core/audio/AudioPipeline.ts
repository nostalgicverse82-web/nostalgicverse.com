export class AudioPipeline {
  private audioCtx: AudioContext | null = null;
  private scriptNode: ScriptProcessorNode | null = null;
  private gainNode: GainNode | null = null;
  private ringBuffer: Float32Array;
  private writePos = 0;
  private readPos = 0;
  private bufferSize = 8192;
  private isMuted = false;
  private volume = 0.85;

  constructor() {
    this.ringBuffer = new Float32Array(this.bufferSize);
  }

  public init() {
    if (this.audioCtx) return;
    if (typeof window === 'undefined') return;

    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioContextClass({ sampleRate: 44100 });
      this.gainNode = this.audioCtx.createGain();
      this.gainNode.gain.value = this.isMuted ? 0 : this.volume;
      this.gainNode.connect(this.audioCtx.destination);

      // 1024 buffer size for ~23ms latency
      this.scriptNode = this.audioCtx.createScriptProcessor(1024, 0, 1);
      this.scriptNode.onaudioprocess = (e) => {
        const output = e.outputBuffer.getChannelData(0);
        for (let i = 0; i < output.length; i++) {
          if (this.readPos !== this.writePos) {
            output[i] = this.ringBuffer[this.readPos];
            this.readPos = (this.readPos + 1) % this.bufferSize;
          } else {
            output[i] = 0;
          }
        }
      };

      this.scriptNode.connect(this.gainNode);
    } catch {}
  }

  public resume() {
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  public writeSamples(samples: Float32Array) {
    for (let i = 0; i < samples.length; i++) {
      this.ringBuffer[this.writePos] = samples[i];
      this.writePos = (this.writePos + 1) % this.bufferSize;
    }
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol / 100));
    if (this.gainNode) {
      this.gainNode.gain.value = this.isMuted ? 0 : this.volume;
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.gainNode) {
      this.gainNode.gain.value = muted ? 0 : this.volume;
    }
  }

  public shutdown() {
    if (this.scriptNode) {
      this.scriptNode.disconnect();
      this.scriptNode = null;
    }
    if (this.audioCtx) {
      this.audioCtx.close();
      this.audioCtx = null;
    }
    this.writePos = 0;
    this.readPos = 0;
  }
}

export const audioPipeline = new AudioPipeline();
