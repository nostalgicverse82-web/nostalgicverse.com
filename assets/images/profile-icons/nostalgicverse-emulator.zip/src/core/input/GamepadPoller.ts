import { 
  NormalizedButton, 
  ControllerMapping, 
  DEFAULT_STANDARD_MAPPING, 
  NormalizedGamepadState,
  NavigationEvent 
} from './types';

export class GamepadPoller {
  private isPolling = false;
  private animFrameId: number | null = null;
  private mappings: Map<string, ControllerMapping> = new Map();
  private lastButtonStates: Map<string, boolean> = new Map();
  
  // Navigation hold/repeat throttle
  private navHoldTimer: number | null = null;
  private navRepeatInterval: number | null = null;
  private activeNavDirection: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT' | null = null;

  // Listeners
  public onStateUpdate?: (state: NormalizedGamepadState | null) => void;
  public onButtonPress?: (button: NormalizedButton, gamepadIndex: number) => void;
  public onButtonRelease?: (button: NormalizedButton, gamepadIndex: number) => void;
  public onNavigation?: (event: NavigationEvent) => void;
  public onConnect?: (gamepad: Gamepad) => void;
  public onDisconnect?: (gamepad: Gamepad) => void;
  public onSelectStartHold?: () => void;

  private selectStartHoldStart = 0;
  private selectStartFired = false;
  private activeGamepadIndex = -1;

  constructor() {
    this.setupEventListeners();
  }

  private setupEventListeners() {
    if (typeof window === 'undefined') return;

    window.addEventListener('gamepadconnected', (e: GamepadEvent) => {
      this.activeGamepadIndex = e.gamepad.index;
      if (this.onConnect) this.onConnect(e.gamepad);
      this.start();
    });

    window.addEventListener('gamepaddisconnected', (e: GamepadEvent) => {
      if (this.activeGamepadIndex === e.gamepad.index) {
        this.activeGamepadIndex = -1;
      }
      if (this.onDisconnect) this.onDisconnect(e.gamepad);
      if (this.onStateUpdate) this.onStateUpdate(null);
    });
  }

  public start() {
    if (this.isPolling) return;
    this.isPolling = true;
    this.pollLoop();
  }

  public stop() {
    this.isPolling = false;
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
  }

  public setCustomMapping(controllerId: string, mapping: ControllerMapping) {
    this.mappings.set(controllerId, mapping);
  }

  public getRawGamepad(): Gamepad | null {
    if (typeof navigator === 'undefined' || !navigator.getGamepads) return null;
    const gamepads = navigator.getGamepads();
    if (this.activeGamepadIndex >= 0 && gamepads[this.activeGamepadIndex]) {
      return gamepads[this.activeGamepadIndex];
    }
    for (let i = 0; i < gamepads.length; i++) {
      if (gamepads[i]) {
        this.activeGamepadIndex = i;
        return gamepads[i];
      }
    }
    return null;
  }

  public getNormalizedState(): NormalizedGamepadState | null {
    const pad = this.getRawGamepad();
    if (!pad) return null;

    const mapping = this.mappings.get(pad.id) || DEFAULT_STANDARD_MAPPING;
    const buttons = {} as Record<NormalizedButton, { pressed: boolean; value: number }>;

    const checkButton = (key: NormalizedButton, idx: number) => {
      const b = pad.buttons[idx];
      buttons[key] = {
        pressed: Boolean(b && b.pressed),
        value: b ? b.value : 0
      };
    };

    (Object.keys(mapping) as NormalizedButton[]).forEach((btn) => {
      checkButton(btn, mapping[btn]);
    });

    // Check D-Pad from analog stick or axes fallback if not mapped to standard buttons
    const leftStickX = Math.abs(pad.axes[0] || 0) > 0.15 ? pad.axes[0] : 0;
    const leftStickY = Math.abs(pad.axes[1] || 0) > 0.15 ? pad.axes[1] : 0;
    const rightStickX = Math.abs(pad.axes[2] || 0) > 0.15 ? pad.axes[2] : 0;
    const rightStickY = Math.abs(pad.axes[3] || 0) > 0.15 ? pad.axes[3] : 0;

    return {
      connected: pad.connected,
      id: pad.id,
      index: pad.index,
      mapping: pad.mapping,
      buttons,
      axes: {
        leftStickX,
        leftStickY,
        rightStickX,
        rightStickY
      },
      timestamp: pad.timestamp
    };
  }

  private pollLoop = () => {
    if (!this.isPolling) return;

    const state = this.getNormalizedState();

    if (state && state.connected) {
      // 1. Check Button Transitions
      (Object.keys(state.buttons) as NormalizedButton[]).forEach((btn) => {
        const isPressed = state.buttons[btn].pressed;
        const wasPressed = Boolean(this.lastButtonStates.get(btn));

        if (isPressed && !wasPressed) {
          if (this.onButtonPress) this.onButtonPress(btn, state.index);
        } else if (!isPressed && wasPressed) {
          if (this.onButtonRelease) this.onButtonRelease(btn, state.index);
        }

        this.lastButtonStates.set(btn, isPressed);
      });

      // 2. Check SELECT + START 100-200ms simultaneous hold for pause/quick menu
      if (state.buttons.SELECT?.pressed && state.buttons.START?.pressed) {
        if (!this.selectStartHoldStart) {
          this.selectStartHoldStart = performance.now();
        } else if (!this.selectStartFired && performance.now() - this.selectStartHoldStart >= 150) {
          this.selectStartFired = true;
          if (this.onSelectStartHold) {
            this.onSelectStartHold();
          }
        }
      } else {
        this.selectStartHoldStart = 0;
        this.selectStartFired = false;
      }

      // 3. Handle Spatial Navigation with dead-zone & repeat throttling
      let navDir: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT' | null = null;
      let source: 'dpad' | 'leftStick' = 'dpad';

      if (state.buttons.LEFT.pressed || state.axes.leftStickX < -0.45) {
        navDir = 'LEFT';
        source = state.buttons.LEFT.pressed ? 'dpad' : 'leftStick';
      } else if (state.buttons.RIGHT.pressed || state.axes.leftStickX > 0.45) {
        navDir = 'RIGHT';
        source = state.buttons.RIGHT.pressed ? 'dpad' : 'leftStick';
      } else if (state.buttons.UP.pressed || state.axes.leftStickY < -0.45) {
        navDir = 'UP';
        source = state.buttons.UP.pressed ? 'dpad' : 'leftStick';
      } else if (state.buttons.DOWN.pressed || state.axes.leftStickY > 0.45) {
        navDir = 'DOWN';
        source = state.buttons.DOWN.pressed ? 'dpad' : 'leftStick';
      }

      this.handleNavigationHold(navDir, source);

      if (this.onStateUpdate) {
        this.onStateUpdate(state);
      }
    } else {
      this.clearNavTimers();
    }

    this.animFrameId = requestAnimationFrame(this.pollLoop);
  };

  private handleNavigationHold(
    dir: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT' | null,
    source: 'dpad' | 'leftStick'
  ) {
    if (dir === this.activeNavDirection) return;

    this.clearNavTimers();
    this.activeNavDirection = dir;

    if (dir && this.onNavigation) {
      // Immediate first step
      this.onNavigation({ direction: dir, source });

      // Initial hold delay (350ms)
      this.navHoldTimer = window.setTimeout(() => {
        // Continuous repeat (160ms)
        this.navRepeatInterval = window.setInterval(() => {
          if (this.activeNavDirection && this.onNavigation) {
            this.onNavigation({ direction: this.activeNavDirection, source });
          }
        }, 160);
      }, 350);
    }
  }

  private clearNavTimers() {
    if (this.navHoldTimer !== null) {
      clearTimeout(this.navHoldTimer);
      this.navHoldTimer = null;
    }
    if (this.navRepeatInterval !== null) {
      clearInterval(this.navRepeatInterval);
      this.navRepeatInterval = null;
    }
    this.activeNavDirection = null;
  }
}

export const gamepadPoller = new GamepadPoller();
