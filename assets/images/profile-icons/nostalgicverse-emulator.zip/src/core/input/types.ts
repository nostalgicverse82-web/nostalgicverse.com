export type NormalizedButton =
  | 'A'
  | 'B'
  | 'X'
  | 'Y'
  | 'UP'
  | 'DOWN'
  | 'LEFT'
  | 'RIGHT'
  | 'L1'
  | 'R1'
  | 'L2'
  | 'R2'
  | 'L3'
  | 'R3'
  | 'START'
  | 'SELECT'
  | 'HOME';

export interface ControllerMapping {
  A: number;
  B: number;
  X: number;
  Y: number;
  UP: number;
  DOWN: number;
  LEFT: number;
  RIGHT: number;
  L1: number;
  R1: number;
  L2: number;
  R2: number;
  L3: number;
  R3: number;
  START: number;
  SELECT: number;
  HOME: number;
}

export const DEFAULT_STANDARD_MAPPING: ControllerMapping = {
  A: 0, // Cross / A
  B: 1, // Circle / B
  X: 2, // Square / X
  Y: 3, // Triangle / Y
  L1: 4,
  R1: 5,
  L2: 6,
  R2: 7,
  SELECT: 8, // Share / Select / Back
  START: 9,  // Options / Start
  L3: 10,
  R3: 11,
  UP: 12,
  DOWN: 13,
  LEFT: 14,
  RIGHT: 15,
  HOME: 16 // PS / Xbox Guide button
};

export interface NormalizedGamepadState {
  connected: boolean;
  id: string;
  index: number;
  mapping: string;
  buttons: Record<NormalizedButton, { pressed: boolean; value: number }>;
  axes: {
    leftStickX: number;
    leftStickY: number;
    rightStickX: number;
    rightStickY: number;
  };
  timestamp: number;
}

export type InputMode = 'controller' | 'keyboard' | 'touch' | 'mouse';

export interface NavigationEvent {
  direction: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';
  source: 'dpad' | 'leftStick';
}
