import { 
  NormalizedButton, 
  ControllerMapping, 
  DEFAULT_STANDARD_MAPPING, 
  NormalizedGamepadState, 
  InputMode,
  NavigationEvent 
} from './types';
import { gamepadPoller } from './GamepadPoller';
import { soundFx } from '../../services/soundFx';

export class ControllerManager {
  private activeInputMode: InputMode = 'mouse';
  private customMappings: Map<string, ControllerMapping> = new Map();
  private listeners: Set<(state: NormalizedGamepadState | null) => void> = new Set();
  private modeListeners: Set<(mode: InputMode) => void> = new Set();

  constructor() {
    this.setupListeners();
    this.loadSavedMappings();
  }

  private setupListeners() {
    gamepadPoller.onStateUpdate = (state) => {
      this.listeners.forEach(fn => fn(state));
    };

    gamepadPoller.onConnect = (pad) => {
      this.setInputMode('controller');
    };

    gamepadPoller.onDisconnect = () => {
      this.setInputMode('keyboard');
    };

    if (typeof window !== 'undefined') {
      window.addEventListener('keydown', () => {
        if (this.activeInputMode !== 'keyboard') {
          this.setInputMode('keyboard');
        }
      });

      window.addEventListener('touchstart', () => {
        if (this.activeInputMode !== 'touch') {
          this.setInputMode('touch');
        }
      }, { passive: true });

      window.addEventListener('mousemove', (e) => {
        if (e.movementX !== 0 || e.movementY !== 0) {
          if (this.activeInputMode !== 'mouse') {
            this.setInputMode('mouse');
          }
        }
      });
    }
  }

  public start() {
    gamepadPoller.start();
  }

  public stop() {
    gamepadPoller.stop();
  }

  public getInputMode(): InputMode {
    return this.activeInputMode;
  }

  public setInputMode(mode: InputMode) {
    if (this.activeInputMode === mode) return;
    this.activeInputMode = mode;
    this.modeListeners.forEach(fn => fn(mode));
  }

  public onInputModeChange(fn: (mode: InputMode) => void) {
    this.modeListeners.add(fn);
    return () => this.modeListeners.delete(fn);
  }

  public onStateUpdate(fn: (state: NormalizedGamepadState | null) => void) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  public onButtonPress(fn: (button: NormalizedButton, padIndex: number) => void) {
    gamepadPoller.onButtonPress = fn;
  }

  public onNavigation(fn: (nav: NavigationEvent) => void) {
    gamepadPoller.onNavigation = fn;
  }

  public onSelectStartHold(fn: () => void) {
    gamepadPoller.onSelectStartHold = fn;
  }

  public getMappingForController(controllerId: string): ControllerMapping {
    return this.customMappings.get(controllerId) || DEFAULT_STANDARD_MAPPING;
  }

  public saveMappingForController(controllerId: string, mapping: ControllerMapping) {
    this.customMappings.set(controllerId, mapping);
    gamepadPoller.setCustomMapping(controllerId, mapping);
    try {
      localStorage.setItem('nv_ctrl_mappings', JSON.stringify(Array.from(this.customMappings.entries())));
    } catch {}
  }

  private loadSavedMappings() {
    try {
      const saved = localStorage.getItem('nv_ctrl_mappings');
      if (saved) {
        const entries: [string, ControllerMapping][] = JSON.parse(saved);
        entries.forEach(([id, map]) => {
          this.customMappings.set(id, map);
          gamepadPoller.setCustomMapping(id, map);
        });
      }
    } catch {}
  }
}

export const controllerManager = new ControllerManager();
