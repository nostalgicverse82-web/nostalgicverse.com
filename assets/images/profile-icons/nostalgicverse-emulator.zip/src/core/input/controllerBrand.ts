import { NormalizedButton } from './types';

export type ControllerBrand = 'xbox' | 'playstation' | 'nintendo' | 'keyboard' | 'generic';

export interface ButtonGlyphInfo {
  label: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  symbol: string;
}

export interface ControllerContextHints {
  select: string; // e.g., 'Play' or 'Select' or 'Launch'
  back?: string;   // e.g., 'Back' or 'Close'
  details?: string; // e.g., 'Details'
  scan?: string;   // e.g., 'Scan ROMs'
  favorite?: string; // e.g., 'Favorite'
  switchHub?: string; // e.g., 'Switch Hub'
  menu?: string;   // e.g., 'Settings' or 'Quick Menu'
}

/**
 * Detect controller brand from browser Gamepad.id string
 */
export function detectControllerBrand(gamepadId?: string | null): ControllerBrand {
  if (!gamepadId) return 'keyboard';
  const id = gamepadId.toLowerCase();

  // Sony / PlayStation
  if (
    id.includes('sony') ||
    id.includes('dualshock') ||
    id.includes('dualsense') ||
    id.includes('playstation') ||
    id.includes('ps5') ||
    id.includes('ps4') ||
    id.includes('ps3') ||
    id.includes('054c') // Sony USB vendor ID
  ) {
    return 'playstation';
  }

  // Nintendo (Switch Pro, Joy-Con)
  if (
    id.includes('nintendo') ||
    id.includes('switch') ||
    id.includes('joy-con') ||
    id.includes('pro controller') ||
    id.includes('057e') // Nintendo USB vendor ID
  ) {
    return 'nintendo';
  }

  // Microsoft / Xbox / XInput
  if (
    id.includes('xbox') ||
    id.includes('x-box') ||
    id.includes('xinput') ||
    id.includes('microsoft') ||
    id.includes('045e') // Microsoft USB vendor ID
  ) {
    return 'xbox';
  }

  // Standard PC Gamepad defaults to Xbox convention
  return 'xbox';
}

/**
 * Get human-readable controller device title
 */
export function getControllerDisplayName(brand: ControllerBrand, rawId?: string | null): string {
  if (brand === 'keyboard') return 'Keyboard & Mouse';
  if (brand === 'playstation') {
    if (rawId?.toLowerCase().includes('dualsense')) return 'PlayStation DualSense Wireless';
    return 'PlayStation DualShock Controller';
  }
  if (brand === 'nintendo') {
    if (rawId?.toLowerCase().includes('joy-con')) return 'Nintendo Switch Joy-Con';
    return 'Nintendo Switch Pro Controller';
  }
  if (brand === 'xbox') {
    return 'Xbox Wireless / XInput Controller';
  }
  return rawId || 'Standard Gamepad';
}

/**
 * Get button glyph details matching the exact physical branding
 */
export function getButtonGlyph(brand: ControllerBrand, button: NormalizedButton): ButtonGlyphInfo {
  if (brand === 'playstation') {
    switch (button) {
      case 'A':
        return { label: '✕', symbol: '✕', badgeBg: 'bg-blue-600/30', badgeText: 'text-blue-400', badgeBorder: 'border-blue-500/50' };
      case 'B':
        return { label: '○', symbol: '○', badgeBg: 'bg-rose-600/30', badgeText: 'text-rose-400', badgeBorder: 'border-rose-500/50' };
      case 'X':
        return { label: '□', symbol: '□', badgeBg: 'bg-pink-600/30', badgeText: 'text-pink-400', badgeBorder: 'border-pink-500/50' };
      case 'Y':
        return { label: '△', symbol: '△', badgeBg: 'bg-emerald-600/30', badgeText: 'text-emerald-400', badgeBorder: 'border-emerald-500/50' };
      case 'L1':
        return { label: 'L1', symbol: 'L1', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'R1':
        return { label: 'R1', symbol: 'R1', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'L2':
        return { label: 'L2', symbol: 'L2', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'R2':
        return { label: 'R2', symbol: 'R2', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'START':
        return { label: 'Options', symbol: 'Options', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'SELECT':
        return { label: 'Share', symbol: 'Share', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'HOME':
        return { label: 'PS', symbol: 'PS', badgeBg: 'bg-blue-600/40', badgeText: 'text-blue-300', badgeBorder: 'border-blue-400/50' };
      default:
        return { label: button, symbol: button, badgeBg: 'bg-slate-800', badgeText: 'text-slate-300', badgeBorder: 'border-slate-600' };
    }
  }

  if (brand === 'nintendo') {
    switch (button) {
      case 'A':
        return { label: 'B', symbol: 'B', badgeBg: 'bg-rose-600/30', badgeText: 'text-rose-400', badgeBorder: 'border-rose-500/50' };
      case 'B':
        return { label: 'A', symbol: 'A', badgeBg: 'bg-amber-600/30', badgeText: 'text-amber-400', badgeBorder: 'border-amber-500/50' };
      case 'X':
        return { label: 'Y', symbol: 'Y', badgeBg: 'bg-blue-600/30', badgeText: 'text-blue-400', badgeBorder: 'border-blue-500/50' };
      case 'Y':
        return { label: 'X', symbol: 'X', badgeBg: 'bg-emerald-600/30', badgeText: 'text-emerald-400', badgeBorder: 'border-emerald-500/50' };
      case 'L1':
        return { label: 'L', symbol: 'L', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'R1':
        return { label: 'R', symbol: 'R', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'L2':
        return { label: 'ZL', symbol: 'ZL', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'R2':
        return { label: 'ZR', symbol: 'ZR', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'START':
        return { label: '+', symbol: '+', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'SELECT':
        return { label: '–', symbol: '–', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'HOME':
        return { label: 'Home', symbol: 'Home', badgeBg: 'bg-cyan-600/40', badgeText: 'text-cyan-300', badgeBorder: 'border-cyan-400/50' };
      default:
        return { label: button, symbol: button, badgeBg: 'bg-slate-800', badgeText: 'text-slate-300', badgeBorder: 'border-slate-600' };
    }
  }

  // Xbox & Standard
  if (brand === 'xbox' || brand === 'generic') {
    switch (button) {
      case 'A':
        return { label: 'A', symbol: 'A', badgeBg: 'bg-emerald-600/30', badgeText: 'text-emerald-400', badgeBorder: 'border-emerald-500/50' };
      case 'B':
        return { label: 'B', symbol: 'B', badgeBg: 'bg-rose-600/30', badgeText: 'text-rose-400', badgeBorder: 'border-rose-500/50' };
      case 'X':
        return { label: 'X', symbol: 'X', badgeBg: 'bg-blue-600/30', badgeText: 'text-blue-400', badgeBorder: 'border-blue-500/50' };
      case 'Y':
        return { label: 'Y', symbol: 'Y', badgeBg: 'bg-amber-600/30', badgeText: 'text-amber-400', badgeBorder: 'border-amber-500/50' };
      case 'L1':
        return { label: 'LB', symbol: 'LB', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'R1':
        return { label: 'RB', symbol: 'RB', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'L2':
        return { label: 'LT', symbol: 'LT', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'R2':
        return { label: 'RT', symbol: 'RT', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'START':
        return { label: 'Menu', symbol: 'Menu', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'SELECT':
        return { label: 'View', symbol: 'View', badgeBg: 'bg-slate-700/50', badgeText: 'text-slate-200', badgeBorder: 'border-slate-500/40' };
      case 'HOME':
        return { label: 'Xbox', symbol: 'Xbox', badgeBg: 'bg-emerald-600/40', badgeText: 'text-emerald-300', badgeBorder: 'border-emerald-400/50' };
      default:
        return { label: button, symbol: button, badgeBg: 'bg-slate-800', badgeText: 'text-slate-300', badgeBorder: 'border-slate-600' };
    }
  }

  // Keyboard mapping
  switch (button) {
    case 'A':
      return { label: 'Enter', symbol: '↵ Enter', badgeBg: 'bg-cyan-600/20', badgeText: 'text-cyan-300', badgeBorder: 'border-cyan-500/40' };
    case 'B':
      return { label: 'Esc', symbol: 'Esc', badgeBg: 'bg-rose-600/20', badgeText: 'text-rose-300', badgeBorder: 'border-rose-500/40' };
    case 'X':
      return { label: 'X', symbol: 'X', badgeBg: 'bg-blue-600/20', badgeText: 'text-blue-300', badgeBorder: 'border-blue-500/40' };
    case 'Y':
      return { label: 'Y', symbol: 'Y', badgeBg: 'bg-amber-600/20', badgeText: 'text-amber-300', badgeBorder: 'border-amber-500/40' };
    case 'L1':
      return { label: 'Q', symbol: 'Q', badgeBg: 'bg-slate-800', badgeText: 'text-slate-300', badgeBorder: 'border-slate-700' };
    case 'R1':
      return { label: 'E', symbol: 'E', badgeBg: 'bg-slate-800', badgeText: 'text-slate-300', badgeBorder: 'border-slate-700' };
    default:
      return { label: button, symbol: button, badgeBg: 'bg-slate-800', badgeText: 'text-slate-300', badgeBorder: 'border-slate-700' };
  }
}
