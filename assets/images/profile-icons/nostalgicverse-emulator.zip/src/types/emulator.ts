export type ConsoleId = 
  | 'nes' 
  | 'snes' 
  | 'gb' 
  | 'gbc' 
  | 'gba' 
  | 'nds' 
  | 'n64' 
  | 'ps1' 
  | 'psp' 
  | '3ds' 
  | 'ps2'
  | 'ps3';

export type UIMode = 
  | 'DESKTOP_CONSOLE' 
  | 'MOBILE_PORTRAIT' 
  | 'MOBILE_LANDSCAPE' 
  | 'GAMEPLAY';

export type ConsoleOSSection = 
  | 'for-you' 
  | 'library' 
  | 'consoles' 
  | 'adaptive' 
  | 'saves' 
  | 'media' 
  | 'settings';

export interface ConsoleInfo {
  id: ConsoleId;
  name: string;
  fullName: string;
  generation: string;
  releaseYear: number;
  coreName: string;
  coreVersion: string;
  gameCount: number;
  storageUsed: string;
  supportedFormats: string[];
  color: string;
  badgeBg: string;
  isExperimental?: boolean;
}

export type CompatibilityTier = 'perfect' | 'playable' | 'experimental' | 'issues';

export interface GameItem {
  id: string;
  title: string;
  subtitle?: string;
  consoleId: ConsoleId;
  developer: string;
  publisher: string;
  releaseYear: number;
  genre: string;
  region: 'USA' | 'EUR' | 'JPN' | 'World';
  fileFormat: string;
  fileSize: string;
  playtimeMinutes: number;
  lastPlayed?: string;
  isFavorite: boolean;
  progressPercent?: number;
  coverGradient: string;
  bannerGradient: string;
  heroColor: string;
  description: string;
  compatibilityTier: CompatibilityTier;
  targetFps: number;
  saveStateCount: number;
  recommendedSettings?: {
    renderer: string;
    resolution: string;
    framePacing: string;
  };
  achievements?: {
    unlocked: number;
    total: number;
  };
}

export interface SaveStateItem {
  id: string;
  gameId: string;
  slotNumber: number;
  name: string;
  timestamp: string;
  playtime: string;
  gameLocation: string;
  screenshotGradient: string;
  isAutoSave?: boolean;
}

export interface ControllerDevice {
  id: string;
  name: string;
  type: 'bluetooth' | 'usb' | 'touch' | 'keyboard';
  connected: boolean;
  batteryLevel?: number;
  profileName: string;
  vibrationSupported: boolean;
  playerIndex?: number;
}

export interface GraphicsSettings {
  renderer: 'vulkan' | 'opengl' | 'auto';
  internalResolution: '1x' | '1.5x' | '2x' | '2.5x' | '3x' | '4x' | '5x' | '6x';
  textureFiltering: 'nearest' | 'bilinear' | 'bicubic' | 'anisotropic';
  textureScaling: 'off' | '2x' | '3x' | '4x';
  antiAliasing: 'off' | 'fxaa' | 'msaa-2x' | 'msaa-4x';
  vsync: boolean;
  framePacing: 'standard' | 'smooth' | 'low-latency';
  shaderCache: boolean;
  crtFilter: boolean;
  scanlines: boolean;
  widescreenHack: boolean;
  integerScaling: boolean;
  bloom: boolean;
  colorCorrection: boolean;
  sharpening: number;
}

export interface AudioSettings {
  backend: 'aaudio' | 'opensles' | 'cubeb';
  volume: number;
  latency: 'ultra-low' | 'low' | 'normal' | 'high';
  audioStretching: boolean;
  timeStretching: boolean;
  channels: 'stereo' | 'mono' | 'surround-5.1';
  mute: boolean;
}

export interface PerformanceProfileConfig {
  profile: 'battery' | 'balanced' | 'performance' | 'max';
  adaptivePerformance: boolean;
  dynamicResolution: boolean;
  thermalProtection: boolean;
  backgroundJit: boolean;
  targetFps: 30 | 60 | 90 | 120;
}

export interface MediaCaptureItem {
  id: string;
  gameId: string;
  gameTitle: string;
  consoleId: ConsoleId;
  type: 'screenshot' | 'recording';
  timestamp: string;
  fileSize: string;
  previewGradient: string;
  duration?: string;
}

export interface ToastItem {
  id: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
}
