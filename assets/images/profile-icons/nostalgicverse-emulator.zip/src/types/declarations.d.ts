declare module 'wasmboy' {
  export const WasmBoy: any;
  export default WasmBoy;
}

declare module 'gbajs' {
  const GameBoyAdvance: any;
  export default GameBoyAdvance;
}
