import React, { useState, useEffect } from 'react';
import { useConsoleOS } from '../../context/ConsoleOSContext';
import { DesktopConsoleView } from '../desktop/DesktopConsoleView';
import { ControllerLegend } from '../../components/controller/ControllerLegend';
import { GameDetailsModal } from '../../components/modals/GameDetailsModal';
import { SettingsModal } from '../../components/modals/SettingsModal';
import { SaveStatesModal } from '../../components/modals/SaveStatesModal';
import { ScannerModal } from '../../components/modals/ScannerModal';
import { ControllerMapperModal } from '../../components/modals/ControllerMapperModal';
import { ToastContainer } from '../../components/common/ToastContainer';
import { Smartphone, X } from 'lucide-react';

export const AppShell: React.FC = () => {
  const { uiMode } = useConsoleOS();
  const [isPortrait, setIsPortrait] = useState(false);
  const [dismissRotatePrompt, setDismissRotatePrompt] = useState(false);

  useEffect(() => {
    const checkOrientation = () => {
      if (typeof window !== 'undefined') {
        const portrait = window.innerHeight > window.innerWidth && window.innerWidth < 768;
        setIsPortrait(portrait);
      }
    };

    checkOrientation();
    window.addEventListener('resize', checkOrientation);
    window.addEventListener('orientationchange', checkOrientation);

    return () => {
      window.removeEventListener('resize', checkOrientation);
      window.removeEventListener('orientationchange', checkOrientation);
    };
  }, []);

  // If in GAMEPLAY mode, AppShell renders nothing so zero UI leaks into gameplay
  if (uiMode === 'GAMEPLAY') {
    return null;
  }

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#05070c] text-white font-sans app-shell-root select-none">
      {/* Universal Landscape Console UI */}
      <DesktopConsoleView />

      {/* Minimal Landscape Orientation Advisory for Portrait Mobile */}
      {isPortrait && !dismissRotatePrompt && (
        <div className="fixed top-3 left-4 right-4 z-50 p-3 rounded-2xl bg-cyan-950/90 border border-cyan-500/40 backdrop-blur-xl shadow-2xl flex items-center justify-between gap-3 text-xs animate-in fade-in slide-in-from-top-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0 border border-cyan-500/30">
              <Smartphone className="w-4 h-4 rotate-90" />
            </div>
            <div>
              <p className="font-bold text-white">Rotate Device to Landscape</p>
              <p className="text-[11px] text-cyan-200/80">NostalgicVerse is engineered as a landscape-first console OS</p>
            </div>
          </div>
          <button
            onClick={() => setDismissRotatePrompt(true)}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white shrink-0"
            title="Dismiss advisory"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Global Modals */}
      <GameDetailsModal />
      <SettingsModal />
      <SaveStatesModal />
      <ScannerModal />
      <ControllerMapperModal />
      <ToastContainer />

      {/* Dynamic Contextual Controller Hint Legend */}
      <ControllerLegend />
    </div>
  );
};
