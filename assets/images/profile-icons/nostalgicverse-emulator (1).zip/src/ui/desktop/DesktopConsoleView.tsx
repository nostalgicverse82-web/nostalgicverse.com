import React, { useRef, useEffect } from 'react';
import { useConsoleOS } from '../../context/ConsoleOSContext';
import { MOCK_CONSOLES } from '../../data/mockData';
import { LiveWallpaperCanvas } from '../../core/wallpaper/LiveWallpaperCanvas';
import { ConsoleWallpaperLayer } from '../../core/wallpaper/ConsoleWallpaperLayer';
import { 
  Play, 
  MoreHorizontal, 
  Heart, 
  Search, 
  Settings, 
  Gamepad2, 
  User, 
  FolderSearch,
  Sparkles,
  ChevronRight,
  Clock,
  ShieldCheck,
  Disc3,
  Flame,
  LayoutGrid
} from 'lucide-react';
import { soundFx } from '../../services/soundFx';

export const DesktopConsoleView: React.FC = () => {
  const { 
    games, 
    filteredGames,
    focusedGameIndex, 
    setFocusedGameIndex, 
    libraryFocusedIndex,
    setLibraryFocusedIndex,
    consolesFocusedIndex,
    setConsolesFocusedIndex,
    focusedGame, 
    activeSection, 
    setActiveSection,
    launchGame, 
    openGameDetails,
    openSettings,
    openScanner,
    timeString,
    selectedConsole,
    setSelectedConsole,
    searchQuery,
    setSearchQuery,
    toggleFavorite,
    isControllerConnected,
    activeWallpaper,
    wallpaperSettings
  } = useConsoleOS();

  const carouselRef = useRef<HTMLDivElement>(null);

  // Auto scroll carousel to keep focused game centered
  useEffect(() => {
    if (carouselRef.current) {
      const activeEl = carouselRef.current.children[focusedGameIndex] as HTMLElement;
      if (activeEl) {
        activeEl.scrollIntoView({
          behavior: 'smooth',
          inline: 'center',
          block: 'nearest'
        });
      }
    }
  }, [focusedGameIndex]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#05070c] text-slate-100 flex flex-col justify-between select-none font-sans">
      {/* 1. CINEMATIC BACKGROUND ARTWORK, LIVE PARTICLES & VIDEO WALLPAPER */}
      <ConsoleWallpaperLayer focusedGame={focusedGame} />

      {/* 2. MINIMAL TOP CONSOLE NAVIGATION (PlayStation OS Style) */}
      <header className="relative z-30 px-10 pt-8 pb-4 flex items-center justify-between">
        {/* Left: Section Tabs */}
        <div className="flex items-center gap-10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-cyan-500 to-indigo-600 flex items-center justify-center font-black text-xs shadow-lg shadow-cyan-500/30 text-white">
              NV
            </div>
            <span className="font-black text-sm tracking-wider uppercase text-white hidden sm:inline">
              NOSTALGICVERSE
            </span>
          </div>

          <nav className="flex items-center gap-6 text-sm font-bold">
            <button
              onClick={() => {
                soundFx.playSelect();
                setActiveSection('for-you');
              }}
              className={`transition-all pb-1 ${
                activeSection === 'for-you'
                  ? 'text-white border-b-2 border-cyan-400 drop-shadow-[0_0_12px_rgba(6,182,212,0.6)]'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Games
            </button>

            <button
              onClick={() => {
                soundFx.playSelect();
                setActiveSection('library');
              }}
              className={`transition-all pb-1 ${
                activeSection === 'library'
                  ? 'text-white border-b-2 border-cyan-400 drop-shadow-[0_0_12px_rgba(6,182,212,0.6)]'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Library
            </button>

            <button
              onClick={() => {
                soundFx.playSelect();
                setActiveSection('consoles');
              }}
              className={`transition-all pb-1 ${
                activeSection === 'consoles'
                  ? 'text-white border-b-2 border-cyan-400 drop-shadow-[0_0_12px_rgba(6,182,212,0.6)]'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Consoles
            </button>
          </nav>
        </div>

        {/* Right: Quick Search, Settings, Profile, Clock */}
        <div className="flex items-center gap-4 text-xs font-semibold text-zinc-300">
          <button
            onClick={openScanner}
            className="p-2.5 rounded-full bg-white/5 hover:bg-white/10 hover:text-white transition-all border border-white/10 flex items-center gap-2"
            title="Import / Scan ROMs"
          >
            <FolderSearch className="w-4 h-4 text-cyan-400" />
            <span className="hidden md:inline font-bold">Add ROM</span>
          </button>

          <button
            onClick={openSettings}
            className="p-2.5 rounded-full bg-white/5 hover:bg-white/10 hover:text-white transition-all border border-white/10"
            title="System Settings"
          >
            <Settings className="w-4 h-4 text-zinc-300" />
          </button>

          <div className="flex items-center gap-2 pl-2 border-l border-white/10">
            {isControllerConnected && (
              <span className="p-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40" title="Gamepad Connected">
                <Gamepad2 className="w-3.5 h-3.5" />
              </span>
            )}
            <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-black font-black text-xs shadow-md shadow-cyan-500/20">
              <User className="w-3.5 h-3.5" />
            </div>
            <span className="font-mono font-bold text-white ml-1">{timeString}</span>
          </div>
        </div>
      </header>

      {/* 3. MAIN CONSOLE STAGE CONTENT */}
      {activeSection === 'for-you' && (
        <main className="relative z-20 px-10 flex-1 flex flex-col justify-between pb-24">
          {/* Upper: Horizontal Game Tile Carousel */}
          <div className="pt-2">
            <div 
              ref={carouselRef}
              className="flex items-center gap-5 overflow-x-auto py-6 px-2 no-scrollbar scroll-smooth"
            >
              {filteredGames.map((game, idx) => {
                const isSelected = idx === focusedGameIndex;

                return (
                  <div
                    key={game.id}
                    onClick={() => {
                      setFocusedGameIndex(idx);
                    }}
                    onDoubleClick={() => launchGame(game)}
                    className={`shrink-0 cursor-pointer transition-all duration-300 rounded-2xl overflow-hidden relative group ${
                      isSelected
                        ? 'w-44 h-44 sm:w-48 sm:h-48 ring-4 ring-cyan-400 shadow-[0_0_40px_rgba(6,182,212,0.4)] scale-105 z-20'
                        : 'w-36 h-36 sm:w-40 sm:h-40 opacity-60 hover:opacity-90 hover:scale-100 ring-1 ring-white/10'
                    }`}
                  >
                    {/* Game Tile Cover */}
                    <div className={`w-full h-full bg-gradient-to-br ${game.coverGradient} p-3.5 flex flex-col justify-between relative`}>
                      <span className="self-start px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-[10px] font-black text-cyan-300 border border-white/15 uppercase tracking-wider">
                        {game.consoleId}
                      </span>

                      {game.isFavorite && (
                        <div className="absolute top-3 right-3 text-pink-500 drop-shadow">
                          <Heart className="w-4 h-4 fill-current" />
                        </div>
                      )}

                      <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                        <div className="w-10 h-10 rounded-full bg-cyan-500 text-black flex items-center justify-center shadow-lg">
                          <Play className="w-5 h-5 fill-current ml-0.5" />
                        </div>
                      </div>

                      <div className="mt-auto">
                        <p className={`font-black text-xs sm:text-sm truncate drop-shadow-md ${isSelected ? 'text-white' : 'text-zinc-200'}`}>
                          {game.title}
                        </p>
                        <p className="text-[10px] text-zinc-400 truncate">
                          {game.genre}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Lower: Selected Game Stage */}
          {focusedGame && (
            <div className="max-w-4xl space-y-4 animate-in fade-in slide-in-from-left-3 duration-300">
              {/* Meta pills */}
              <div className="flex items-center gap-3 text-xs">
                <span className="px-3 py-1 rounded-lg bg-cyan-500 text-black font-black uppercase tracking-wider text-[11px] shadow-lg shadow-cyan-500/25">
                  {focusedGame.consoleId.toUpperCase()}
                </span>
                <span className="text-zinc-300 font-semibold">
                  {Math.floor(focusedGame.playtimeMinutes / 60)}h {focusedGame.playtimeMinutes % 60}m PLAYED
                </span>
                <span className="text-zinc-500">•</span>
                <span className="text-zinc-300 font-semibold">
                  {focusedGame.progressPercent || 0}% COMPLETE
                </span>
                <span className="text-zinc-500">•</span>
                <span className="text-emerald-400 font-bold font-mono">
                  ★ 60 FPS CYCLE-ACCURATE
                </span>
              </div>

              {/* Massive Cinematic Title */}
              <h1 className="text-4xl sm:text-6xl font-black text-white tracking-tight leading-none drop-shadow-2xl">
                {focusedGame.title}
              </h1>

              {/* Subtitle / Synopsis */}
              {focusedGame.subtitle && (
                <p className="text-base sm:text-lg font-semibold text-cyan-300/90 drop-shadow">
                  {focusedGame.subtitle}
                </p>
              )}

              <p className="text-xs sm:text-sm text-zinc-300 line-clamp-2 max-w-2xl leading-relaxed">
                {focusedGame.description}
              </p>

              {/* Action Buttons */}
              <div className="flex items-center gap-4 pt-2">
                <button
                  onClick={() => launchGame(focusedGame)}
                  className="px-10 py-4 rounded-2xl bg-gradient-to-r from-cyan-400 via-cyan-500 to-blue-600 hover:from-cyan-300 hover:to-blue-500 text-black font-black text-base uppercase tracking-wider flex items-center gap-3 shadow-[0_0_30px_rgba(6,182,212,0.4)] active:scale-95 transition-all group"
                >
                  <Play className="w-5 h-5 fill-black group-hover:scale-110 transition-transform" />
                  <span>PLAY GAME</span>
                </button>

                <button
                  onClick={() => openGameDetails(focusedGame)}
                  className="p-4 rounded-2xl bg-white/10 hover:bg-white/20 text-white border border-white/15 backdrop-blur-md active:scale-95 transition-all"
                  title="Game Details & Save States"
                >
                  <MoreHorizontal className="w-5 h-5" />
                </button>

                <button
                  onClick={() => toggleFavorite(focusedGame.id)}
                  className={`p-4 rounded-2xl border backdrop-blur-md active:scale-95 transition-all ${
                    focusedGame.isFavorite
                      ? 'bg-pink-500/20 text-pink-400 border-pink-500/50'
                      : 'bg-white/10 text-white border-white/15 hover:bg-white/20'
                  }`}
                  title="Favorite"
                >
                  <Heart className={`w-5 h-5 ${focusedGame.isFavorite ? 'fill-current' : ''}`} />
                </button>
              </div>
            </div>
          )}
        </main>
      )}

      {/* 4. LIBRARY SECTION */}
      {activeSection === 'library' && (
        <main className="relative z-20 px-10 flex-1 flex flex-col pb-24 overflow-y-auto">
          <div className="flex items-center justify-between py-4 border-b border-white/10 shrink-0">
            <div className="flex items-center gap-3">
              <Disc3 className="w-6 h-6 text-cyan-400" />
              <h2 className="text-xl font-black uppercase tracking-wider text-white">
                Game Collection ({filteredGames.length} Titles)
              </h2>
            </div>

            <div className="relative w-72">
              <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search games, genres..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 rounded-xl bg-black/50 border border-white/15 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 py-4 overflow-x-auto no-scrollbar shrink-0">
            <button
              onClick={() => setSelectedConsole('all')}
              className={`px-4 py-1.5 rounded-xl text-xs font-bold uppercase transition-all whitespace-nowrap ${
                selectedConsole === 'all'
                  ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-500/30'
                  : 'bg-white/5 text-zinc-400 hover:text-white hover:bg-white/10'
              }`}
            >
              All Systems
            </button>
            {MOCK_CONSOLES.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedConsole(c.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold uppercase transition-all whitespace-nowrap flex items-center gap-2 ${
                  selectedConsole === c.id
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-md shadow-cyan-500/20'
                    : 'bg-white/5 text-zinc-400 hover:text-white hover:bg-white/10'
                }`}
              >
                <span>{c.name}</span>
                <span className="text-[10px] opacity-60">({c.gameCount})</span>
              </button>
            ))}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-4 py-4">
            {filteredGames.map((game, idx) => {
              const isSelected = idx === libraryFocusedIndex;
              return (
                <div
                  key={game.id}
                  onClick={() => {
                    setLibraryFocusedIndex(idx);
                    launchGame(game);
                  }}
                  className={`p-3 rounded-2xl transition-all flex flex-col gap-2 group cursor-pointer ${
                    isSelected
                      ? 'bg-white/15 border-2 border-cyan-400 ring-4 ring-cyan-400/40 shadow-[0_0_25px_rgba(6,182,212,0.4)] scale-105 z-10'
                      : 'bg-white/5 border border-white/10 hover:border-cyan-500/50 hover:bg-white/10'
                  }`}
                >
                  <div className={`aspect-[4/3] rounded-xl bg-gradient-to-br ${game.coverGradient} p-2 flex flex-col justify-between relative overflow-hidden`}>
                    <span className="self-start px-1.5 py-0.5 rounded bg-black/70 text-[9px] font-black text-cyan-300 uppercase">
                      {game.consoleId}
                    </span>

                    <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                      <div className="w-8 h-8 rounded-full bg-cyan-500 text-black flex items-center justify-center">
                        <Play className="w-4 h-4 fill-current ml-0.5" />
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className={`text-xs font-bold truncate group-hover:text-cyan-300 ${isSelected ? 'text-white' : 'text-zinc-200'}`}>
                      {game.title}
                    </h4>
                    <p className="text-[10px] text-zinc-400 truncate">
                      {game.genre}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </main>
      )}

      {/* 5. CONSOLES SECTION */}
      {activeSection === 'consoles' && (
        <main className="relative z-20 px-10 flex-1 flex flex-col pb-24 overflow-y-auto">
          <div className="py-4 border-b border-white/10 flex items-center justify-between shrink-0">
            <h2 className="text-xl font-black uppercase tracking-wider text-white flex items-center gap-3">
              <LayoutGrid className="w-6 h-6 text-cyan-400" />
              Supported Emulation Platforms
            </h2>
            <span className="text-xs text-zinc-400">12 Multi-Generation Cores</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 py-6">
            {MOCK_CONSOLES.map((c, idx) => {
              const isConsoleSelected = idx === consolesFocusedIndex;
              return (
                <div
                  key={c.id}
                  onClick={() => {
                    setConsolesFocusedIndex(idx);
                    setSelectedConsole(c.id);
                    setActiveSection('library');
                  }}
                  className={`p-5 rounded-3xl transition-all flex flex-col justify-between gap-4 group cursor-pointer ${
                    isConsoleSelected
                      ? 'bg-white/15 border-2 border-cyan-400 ring-4 ring-cyan-400/40 shadow-[0_0_25px_rgba(6,182,212,0.4)] scale-[1.02] z-10'
                      : 'bg-white/5 border border-white/10 hover:border-cyan-500/40 hover:bg-white/10'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="px-3 py-1 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 text-xs font-black uppercase">
                        {c.name}
                      </span>
                      <span className="text-xs font-mono text-zinc-400">
                        {c.releaseYear}
                      </span>
                    </div>

                    <h3 className="text-lg font-black text-white mt-3 group-hover:text-cyan-300">
                      {c.fullName}
                    </h3>
                    <p className="text-xs text-zinc-400 mt-1">
                      {c.generation}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-zinc-300">
                    <span>{c.gameCount} Installed Titles</span>
                    <span className="text-cyan-400 font-bold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                      Browse <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </main>
      )}
    </div>
  );
};
